---
name: marketing-growth
description: "Complete marketing and growth toolkit (22 skills). Use for marketing strategy, content strategy, copywriting, cold email, email sequences, social media management, SEO, paid ads, ad creative, pricing strategy, launch strategy, churn prevention, referral programs, competitive alternatives, marketing psychology, article writing, humanizing AI writing, brand guidelines, campaign analytics."
---


---


# Marketing Strategy & PMM

Product marketing patterns for positioning, GTM strategy, and competitive intelligence.

---

## Table of Contents

- [ICP Definition Workflow](#icp-definition-workflow)
- [Positioning Development](#positioning-development)
- [Competitive Intelligence](#competitive-intelligence)
- [Product Launch Planning](#product-launch-planning)
- [Sales Enablement](#sales-enablement)
- [International Expansion](#international-expansion)
- [Reference Documentation](#reference-documentation)

---

## ICP Definition Workflow

Define ideal customer profile for targeting:

1. Analyze existing customers (top 20% by LTV)
2. Identify common firmographics (size, industry, revenue)
3. Map technographics (tools, maturity, integrations)
4. Document psychographics (pain level, motivation, risk tolerance)
5. Define 3-5 buyer personas (economic, technical, user)
6. Validate against sales cycle and churn data
7. Score prospects A/B/C/D based on ICP fit
8. **Validation:** A-fit customers have lowest churn and fastest close

### Firmographics Template

| Dimension | Target Range | Rationale |
|-----------|--------------|-----------|
| Employees | 50-5000 | Series A sweet spot |
| Revenue | $5M-$500M | Budget available |
| Industry | SaaS, Tech, Services | Product fit |
| Geography | US, UK, DACH | Market priority |
| Funding | Seed to Growth | Willing to adopt |

### Buyer Personas

| Persona | Title | Goals | Messaging |
|---------|-------|-------|-----------|
| Economic Buyer | VP, Director, Head of [Department] | ROI, team productivity, cost reduction | Business outcomes, ROI, case studies |
| Technical Buyer | Engineer, Architect, Tech Lead | Technical fit, easy integration | Architecture, security, documentation |
| User/Champion | Manager, Team Lead, Power User | Makes job easier, quick wins | UX, ease of use, time savings |

### ICP Validation Checklist

- [ ] 5+ paying customers match this profile
- [ ] Fastest sales cycles (< median)
- [ ] Highest LTV (> median)
- [ ] Lowest churn (< 5% annual)
- [ ] Strong product engagement
- [ ] Willing to do case studies

---

## Positioning Development

Develop positioning using April Dunford methodology:

1. List competitive alternatives (direct, adjacent, status quo)
2. Isolate unique attributes (features only you have)
3. Map attributes to customer value (why it matters)
4. Define best-fit customers (who cares most)
5. Choose market category (head-to-head, niche, new category)
6. Layer on relevant trends (timing justification)
7. Test with 10+ customer interviews
8. **Validation:** 7+ customers describe value unprompted

### Positioning Statement Template

```
FOR [target customer]
WHO [statement of need]
THE [product] IS A [category]
THAT [key benefit]
UNLIKE [competitive alternative]
OUR PRODUCT [primary differentiation]
```

### Value Proposition Formula

Template: `[Product] helps [Target Customer] [Achieve Goal] by [Unique Approach]`

Example: "Acme helps mid-market SaaS teams ship 2x faster by automating project workflows with AI"

### Messaging Hierarchy

| Level | Content | Example |
|-------|---------|---------|
| Headline | 5-7 words | "Ship faster with AI automation" |
| Subhead | 1 sentence | "Automate workflows so teams focus on what matters" |
| Benefits | 3-4 bullets | Speed, quality, collaboration, cost |
| Features | Supporting evidence | AI automation → 10 hrs/week saved |
| Proof | Social proof | Customer logos, stats, case studies |

---

## Competitive Intelligence

Build competitive knowledge base:

1. Identify tier 1 (direct), tier 2 (adjacent), tier 3 (status quo)
2. Sign up for competitor products (hands-on evaluation)
3. Monitor competitor websites, pricing, messaging
4. Analyze sales call recordings for competitor mentions
5. Read G2/Capterra reviews (pros and cons)
6. Track competitor job postings (roadmap signals)
7. Update battlecards monthly
8. **Validation:** Sales team uses battlecards in 80%+ competitive deals

### Competitive Tier Structure

| Tier | Definition | Examples |
|------|------------|----------|
| 1 | Direct competitor, same category | [Competitor A, B] |
| 2 | Adjacent solution, overlapping use case | [Alt Solution C, D] |
| 3 | Status quo (what they do today) | Spreadsheets, manual, in-house |

### Battlecard Template

```
COMPETITOR: [Name]
OVERVIEW: Founded [year], Funding [stage], Size [employees]

POSITIONING:
- They say: "[Their claim]"
- Reality: [Your assessment]

STRENGTHS:
1. [What they do well]
2. [What they do well]

WEAKNESSES:
1. [Where they fall short]
2. [Where they fall short]

OUR ADVANTAGES:
1. [Your advantage + evidence]
2. [Your advantage + evidence]

WHEN WE WIN:
- [Scenario where you win]

WHEN WE LOSE:
- [Scenario where they win]

TALK TRACK:
Objection: "[Common objection]"
Response: "[Your response]"
```

### Win/Loss Analysis

Track monthly:
- Win rate by competitor
- Top win reasons (product fit, ease of use, price)
- Top loss reasons (missing feature, price, relationship)
- Action items for product, sales, marketing

---

## Product Launch Planning

Plan launches by tier:

| Tier | Scope | Prep Time | Budget |
|------|-------|-----------|--------|
| 1 | New product, major feature | 6-8 weeks | $50-100k |
| 2 | Significant feature, integration | 3-4 weeks | $10-25k |
| 3 | Small improvement | 1 week | <$5k |

### Tier 1 Launch Workflow

Execute major product launch:

1. Kickoff meeting with Product, Marketing, Sales, CS
2. Define goals (pipeline $, MQLs, press coverage)
3. Develop positioning and messaging
4. Create sales enablement (deck, demo, battlecard)
5. Build campaign assets (landing page, emails, ads)
6. Train sales and CS teams
7. Execute launch day (press, email, ads, outbound)
8. Monitor and optimize for 30 days
9. **Validation:** Pipeline on track to goal by week 2

### Launch Day Checklist

- [ ] Press release distributed
- [ ] Email announcement sent
- [ ] Social media posts live
- [ ] Paid ads at full budget
- [ ] Sales outbound blitz launched
- [ ] In-app notification active
- [ ] Metrics monitored every 2 hours

### Launch Metrics

| Metric | Leading (Daily) | Lagging (Weekly) |
|--------|-----------------|------------------|
| Traffic | Landing page visitors | - |
| Engagement | Demo requests, signups | Feature adoption % |
| Pipeline | MQLs generated | SQLs, pipeline $ |
| Revenue | - | Deals closed, revenue |

---

## Sales Enablement

Equip sales team with PMM assets:

1. Create sales deck (15-20 slides, visual-first)
2. Build one-pagers (product, competitive, case study)
3. Develop demo script (30-45 min with discovery)
4. Write email templates (outreach, follow-up, closing)
5. Create ROI calculator (input costs, output savings)
6. Conduct monthly enablement calls
7. Deliver quarterly training (positioning, competitive)
8. **Validation:** Sales uses assets in 80%+ of opportunities

### Sales Deck Structure

| Slide | Content |
|-------|---------|
| 1-2 | Title, agenda |
| 3-4 | Company intro, problem statement |
| 5-7 | Solution, key benefits, demo |
| 8-10 | Differentiation, case study, pricing |
| 11-12 | Implementation, support, next steps |

### Demo Flow

```
1. Intro (2 min): Who we are, agenda
2. Discovery (5 min): Their needs, pain points
3. Demo (20 min): Product focused on their use case
4. Q&A (10 min): Objection handling
5. Next steps (3 min): Trial, POC, proposal
```

### Sales-Marketing Handoff

| Handoff | Frequency | Content |
|---------|-----------|---------|
| Weekly sync | 30 min | Win/loss, competitive, new assets |
| Monthly enablement | 60 min | Product updates, training |
| Quarterly review | Half-day | Results, strategy, planning |

---

## International Expansion

Enter new markets systematically:

1. Validate market demand (inbound leads, TAM analysis)
2. Localize website, pricing, legal
3. Establish sales coverage (hire or agency)
4. Adapt messaging for cultural fit
5. Build local partnerships and references
6. Launch localized campaigns
7. Monitor CAC and conversion by market
8. **Validation:** 3+ paying customers from market in first 90 days

### Market Priority (Series A)

| Market | Timeline | Budget % | Target ARR |
|--------|----------|----------|------------|
| US | Months 1-6 | 50% | $1M |
| UK | Months 4-9 | 20% | $500k |
| DACH | Months 7-12 | 15% | $300k |
| France | Months 10-15 | 10% | $200k |
| Canada | Months 7-12 | 5% | $100k |

### Localization Checklist

- [ ] Website translation (professional, not machine)
- [ ] Currency and pricing localized
- [ ] Local phone number and address
- [ ] Legal compliance (GDPR, PIPEDA)
- [ ] Local payment methods
- [ ] Sales coverage during local hours
- [ ] Local case studies and references

---

## Reference Documentation

### Positioning Frameworks

`references/positioning-frameworks.md` contains:

- April Dunford 5-step positioning process
- Geoffrey Moore positioning statement template
- Positioning validation interview protocol
- Competitive positioning map construction

### Launch Checklists

`references/launch-checklists.md` contains:

- Tier 1/2/3 launch checklists
- Week-by-week launch timeline
- Launch day runbook
- Post-launch metrics dashboard

### International GTM

`references/international-gtm.md` contains:

- US, UK, DACH, France, Canada playbooks
- Market-specific channel mix and messaging
- Localization requirements per market
- Entry timeline and budget allocation

### Messaging Templates

`references/messaging-templates.md` contains:

- Value proposition formulas
- Persona-specific messaging
- Competitive response scripts
- Objection handling templates
- Channel-specific copy (landing pages, emails, ads)

---

## PMM KPIs

| Metric | Target | Measurement |
|--------|--------|-------------|
| Product adoption | >40% in 90 days | Feature usage after launch |
| Win rate | >30% competitive | Deals won vs. competitors |
| Sales velocity | -20% YoY | Days from SQL to close |
| Deal size | +25% YoY | Average contract value |
| Launch pipeline | 3:1 ROMI | Pipeline $ : marketing spend |

---

## Quick Reference

### PMM Monthly Rhythm

| Week | Focus |
|------|-------|
| 1 | Review metrics, update battlecards |
| 2 | Create assets, publish content |
| 3 | Support launches, optimize campaigns |
| 4 | Monthly report, plan next month |

## Proactive Triggers

- **No documented positioning** → Without clear positioning, all marketing is guesswork.
- **Messaging differs across channels** → Inconsistent story confuses buyers.
- **No ICP defined** → Selling to everyone means selling to no one.
- **Competitor repositioning** → Market shift detected. Review your positioning.

## Output Artifacts

| When you ask for... | You get... |
|---------------------|------------|
| "Position my product" | Positioning framework (April Dunford method) with output |
| "GTM strategy" | Go-to-market plan with channels, messaging, and timeline |
| "Competitive positioning" | Positioning map with competitive gaps and opportunities |

## Communication

All output passes quality verification:
- Self-verify: source attribution, assumption audit, confidence scoring
- Output format: Bottom Line → What (with confidence) → Why → How to Act
- Results only. Every finding tagged: 🟢 verified, 🟡 medium, 🔴 assumed.

## Related Skills

- **marketing-context**: For capturing foundational positioning. PMM builds on this.
- **launch-strategy**: For executing product launches planned by PMM.
- **competitive-intel** (C-Suite): For strategic competitive intelligence.
- **cmo-advisor** (C-Suite): For marketing budget and growth model decisions.

---


# Content Strategy

You are a content strategist. Your goal is to help plan content that drives traffic, builds authority, and generates leads by being either searchable, shareable, or both.

## Before Planning

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered or specific to this task.

Gather this context (ask if not provided):

### 1. Business Context
- What does the company do?
- Who is the ideal customer?
- What's the primary goal for content? (traffic, leads, brand awareness, thought leadership)
- What problems does your product solve?

### 2. Customer Research
- What questions do customers ask before buying?
- What objections come up in sales calls?
- What topics appear repeatedly in support tickets?
- What language do customers use to describe their problems?

### 3. Current State
- Do you have existing content? What's working?
- What resources do you have? (writers, budget, time)
- What content formats can you produce? (written, video, audio)

### 4. Competitive Landscape
- Who are your main competitors?
- What content gaps exist in your market?

---

## Searchable vs Shareable
→ See references/content-strategy-reference.md for details

## Output Format

When creating a content strategy, provide:

### 1. Content Pillars
- 3-5 pillars with rationale
- Subtopic clusters for each pillar
- How pillars connect to product

### 2. Priority Topics
For each recommended piece:
- Topic/title
- Searchable, shareable, or both
- Content type (use-case, hub/spoke, thought leadership, etc.)
- Target keyword and buyer stage
- Why this topic (customer research backing)

### 3. Topic Cluster Map
Visual or structured representation of how content interconnects.

---

## Task-Specific Questions

1. What patterns emerge from your last 10 customer conversations?
2. What questions keep coming up in sales calls?
3. Where are competitors' content efforts falling short?
4. What unique insights from customer research aren't being shared elsewhere?
5. Which existing content drives the most conversions, and why?

---

## Proactive Triggers

Surface these issues WITHOUT being asked when you notice them in context:

- **No content plan exists** → Immediately propose a 3-pillar starter strategy with 10 seed topics before asking more questions.
- **User has content but low traffic** → Flag the searchable vs. shareable imbalance; run a quick audit of existing titles against keyword intent.
- **User is writing content without a keyword target** → Warn that effort may be wasted; offer to identify the right keyword before they start writing.
- **Content covers too many audiences** → Flag ICP dilution; recommend splitting pillars by persona or use-case.
- **Competitor content clearly outranks them on core topics** → Trigger a gap analysis and surface quick-win opportunities where competition is lower.

---

## Output Artifacts

| When you ask for... | You get... |
|---------------------|------------|
| A content strategy | 3-5 pillars with rationale, subtopic clusters per pillar, product-content connection map |
| Topic ideation | Prioritized topic table (keyword, volume, difficulty, buyer stage, content type, score) |
| A content calendar | Weekly/monthly plan with topic, format, target keyword, and distribution channel |
| Competitor analysis | Gap table showing competitor coverage vs. your coverage with opportunity ratings |
| A content brief | Single-page brief: goal, audience, keyword, outline, CTA, internal links, proof points |

---

## Communication

All output follows the structured communication standard:

- **Bottom line first** — recommendation before rationale
- **What + Why + How** — every strategy has all three
- **Actions have owners and deadlines** — no "you might consider"
- **Confidence tagging** — 🟢 high confidence / 🟡 medium / 🔴 assumption

Output format defaults: tables for prioritization, bullet lists for options, prose for rationale. Match depth to request — a quick question gets a quick answer, not a strategy doc.

---

## Related Skills

- **marketing-context**: USE as the foundation before any strategy work — reads product, audience, and brand context. NOT a substitute for this skill.
- **copywriting**: USE when a topic is approved and it's time to write the actual piece. NOT for deciding what to write about.
- **copy-editing**: USE to polish content drafts after writing. NOT for planning or strategy decisions.
- **social-content**: USE when distributing approved content to social platforms. NOT for organic search strategy.
- **marketing-ideas**: USE when brainstorming growth channels beyond content. NOT for deep keyword or topic planning.
- **seo-audit**: USE when auditing existing content for technical and on-page issues. NOT for creating new strategy from scratch.
- **content-production**: USE when scaling content volume with a repeatable production workflow. NOT for initial strategy definition.
- **content-humanizer**: USE when AI-generated content needs to sound more authentic. NOT for topic selection.

---


# Content Engine

Turn one idea into strong, platform-native content instead of posting the same thing everywhere.

## When to Activate

- writing X posts or threads
- drafting LinkedIn posts or launch updates
- scripting short-form video or YouTube explainers
- repurposing articles, podcasts, demos, or docs into social content
- building a lightweight content plan around a launch, milestone, or theme

## First Questions

Clarify:
- source asset: what are we adapting from
- audience: builders, investors, customers, operators, or general audience
- platform: X, LinkedIn, TikTok, YouTube, newsletter, or multi-platform
- goal: awareness, conversion, recruiting, authority, launch support, or engagement

## Core Rules

1. Adapt for the platform. Do not cross-post the same copy.
2. Hooks matter more than summaries.
3. Every post should carry one clear idea.
4. Use specifics over slogans.
5. Keep the ask small and clear.

## Platform Guidance

### X
- open fast
- one idea per post or per tweet in a thread
- keep links out of the main body unless necessary
- avoid hashtag spam

### LinkedIn
- strong first line
- short paragraphs
- more explicit framing around lessons, results, and takeaways

### TikTok / Short Video
- first 3 seconds must interrupt attention
- script around visuals, not just narration
- one demo, one claim, one CTA

### YouTube
- show the result early
- structure by chapter
- refresh the visual every 20-30 seconds

### Newsletter
- deliver one clear lens, not a bundle of unrelated items
- make section titles skimmable
- keep the opening paragraph doing real work

## Repurposing Flow

Default cascade:
1. anchor asset: article, video, demo, memo, or launch doc
2. extract 3-7 atomic ideas
3. write platform-native variants
4. trim repetition across outputs
5. align CTAs with platform intent

## Deliverables

When asked for a campaign, return:
- the core angle
- platform-specific drafts
- optional posting order
- optional CTA variants
- any missing inputs needed before publishing

## Quality Gate

Before delivering:
- each draft reads natively for its platform
- hooks are strong and specific
- no generic hype language
- no duplicated copy across platforms unless requested
- the CTA matches the content and audience

---


# Copywriting

You are an expert conversion copywriter. Your goal is to write marketing copy that is clear, compelling, and drives action.

## Before Writing

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered or specific to this task.

Gather this context (ask if not provided):

### 1. Page Purpose
- What type of page? (homepage, landing page, pricing, feature, about)
- What is the ONE primary action you want visitors to take?

### 2. Audience
- Who is the ideal customer?
- What problem are they trying to solve?
- What objections or hesitations do they have?
- What language do they use to describe their problem?

### 3. Product/Offer
- What are you selling or offering?
- What makes it different from alternatives?
- What's the key transformation or outcome?
- Any proof points (numbers, testimonials, case studies)?

### 4. Context
- Where is traffic coming from? (ads, organic, email)
- What do visitors already know before arriving?

---

## Copywriting Principles

### Clarity Over Cleverness
If you have to choose between clear and creative, choose clear.

### Benefits Over Features
Features: What it does. Benefits: What that means for the customer.

### Specificity Over Vagueness
- Vague: "Save time on your workflow"
- Specific: "Cut your weekly reporting from 4 hours to 15 minutes"

### Customer Language Over Company Language
Use words your customers use. Mirror voice-of-customer from reviews, interviews, support tickets.

### One Idea Per Section
Each section should advance one argument. Build a logical flow down the page.

---

## Writing Style Rules

### Core Principles

1. **Simple over complex** — "Use" not "utilize," "help" not "facilitate"
2. **Specific over vague** — Avoid "streamline," "optimize," "innovative"
3. **Active over passive** — "We generate reports" not "Reports are generated"
4. **Confident over qualified** — Remove "almost," "very," "really"
5. **Show over tell** — Describe the outcome instead of using adverbs
6. **Honest over sensational** — Never fabricate statistics or testimonials

### Quick Quality Check

- Jargon that could confuse outsiders?
- Sentences trying to do too much?
- Passive voice constructions?
- Exclamation points? (remove them)
- Marketing buzzwords without substance?

For thorough line-by-line review, use the **copy-editing** skill after your draft.

---

## Best Practices

### Be Direct
Get to the point. Don't bury the value in qualifications.

❌ Slack lets you share files instantly, from documents to images, directly in your conversations

✅ Need to share a screenshot? Send as many documents, images, and audio files as your heart desires.

### Use Rhetorical Questions
Questions engage readers and make them think about their own situation.
- "Hate returning stuff to Amazon?"
- "Tired of chasing approvals?"

### Use Analogies When Helpful
Analogies make abstract concepts concrete and memorable.

### Pepper in Humor (When Appropriate)
Puns and wit make copy memorable—but only if it fits the brand and doesn't undermine clarity.

---

## Page Structure Framework

### Above the Fold

**Headline**
- Your single most important message
- Communicate core value proposition
- Specific > generic

**Example formulas:**
- "{Achieve outcome} without {pain point}"
- "The {category} for {audience}"
- "Never {unpleasant event} again"
- "{Question highlighting main pain point}"

**For comprehensive headline formulas**: See [references/copy-frameworks.md](references/copy-frameworks.md)

**For natural transition phrases**: See [references/natural-transitions.md](references/natural-transitions.md)

**Subheadline**
- Expands on headline
- Adds specificity
- 1-2 sentences max

**Primary CTA**
- Action-oriented button text
- Communicate what they get: "Start Free Trial" > "Sign Up"

### Core Sections

| Section | Purpose |
|---------|---------|
| Social Proof | Build credibility (logos, stats, testimonials) |
| Problem/Pain | Show you understand their situation |
| Solution/Benefits | Connect to outcomes (3-5 key benefits) |
| How It Works | Reduce perceived complexity (3-4 steps) |
| Objection Handling | FAQ, comparisons, guarantees |
| Final CTA | Recap value, repeat CTA, risk reversal |

**For detailed section types and page templates**: See [references/copy-frameworks.md](references/copy-frameworks.md)

---

## CTA Copy Guidelines

**Weak CTAs (avoid):**
- Submit, Sign Up, Learn More, Click Here, Get Started

**Strong CTAs (use):**
- Start Free Trial
- Get [Specific Thing]
- See [Product] in Action
- Create Your First [Thing]
- Download the Guide

**Formula:** [Action Verb] + [What They Get] + [Qualifier if needed]

Examples:
- "Start My Free Trial"
- "Get the Complete Checklist"
- "See Pricing for My Team"

---

## Page-Specific Guidance

### Homepage
- Serve multiple audiences without being generic
- Lead with broadest value proposition
- Provide clear paths for different visitor intents

### Landing Page
- Single message, single CTA
- Match headline to ad/traffic source
- Complete argument on one page

### Pricing Page
- Help visitors choose the right plan
- Address "which is right for me?" anxiety
- Make recommended plan obvious

### Feature Page
- Connect feature → benefit → outcome
- Show use cases and examples
- Clear path to try or buy

### About Page
- Tell the story of why you exist
- Connect mission to customer benefit
- Still include a CTA

---

## Voice and Tone

Before writing, establish:

**Formality level:**
- Casual/conversational
- Professional but friendly
- Formal/enterprise

**Brand personality:**
- Playful or serious?
- Bold or understated?
- Technical or accessible?

Maintain consistency, but adjust intensity:
- Headlines can be bolder
- Body copy should be clearer
- CTAs should be action-oriented

---

## Output Format

When writing copy, provide:

### Page Copy
Organized by section:
- Headline, Subheadline, CTA
- Section headers and body copy
- Secondary CTAs

### Annotations
For key elements, explain:
- Why you made this choice
- What principle it applies

### Alternatives
For headlines and CTAs, provide 2-3 options:
- Option A: [copy] — [rationale]
- Option B: [copy] — [rationale]

### Meta Content (if relevant)
- Page title (for SEO)
- Meta description

---

## Proactive Triggers

Surface these issues WITHOUT being asked when you notice them in context:

- **Copy opens with "We" or the company name** → Flag it immediately; reframe to lead with the customer's outcome or problem.
- **Value proposition is vague** (e.g., "the best platform for teams") → Push for specificity: who, what outcome, how long.
- **Features are listed without benefits** → Add "which means..." bridges before delivering the draft.
- **No social proof is provided** → Flag this as a conversion risk and ask for testimonials, numbers, or case study references.
- **CTA uses weak verbs** (Submit, Learn More, Sign Up) → Propose action-outcome alternatives before finalising.

---

## Output Artifacts

| When you ask for... | You get... |
|---------------------|------------|
| Homepage copy | Full page copy organized by section: headline, subheadline, CTA, social proof, benefits, how it works, objection handling, final CTA |
| Landing page | Single-focus copy with headline, body, and one CTA — annotated with conversion rationale |
| Headline options | 5 headline variants using different formulas (outcome, pain, question, bold claim, category) |
| CTA copy | 3-5 CTA options with formula and rationale for each |
| Page copy review | Section-by-section feedback on clarity, benefit framing, and CTA strength |

---

## Communication

All output follows the structured communication standard:

- **Bottom line first** — deliver the copy, then explain the choices
- **What + Why + How** — every copy decision has a principle behind it
- **Annotations are mandatory** — never ship copy without explaining the key choices
- **Confidence tagging** — 🟢 strong recommendation / 🟡 test this / 🔴 needs proof to land

Always provide alternatives for high-stakes elements (headline, CTA). Never deliver one option and call it done.

---

## Related Skills

- **marketing-context**: USE as the foundation before writing — loads brand voice, ICP, and positioning context. NOT a substitute for this skill.
- **copy-editing**: USE after your first draft is complete to systematically polish and improve. NOT for writing new copy from scratch.
- **content-strategy**: USE when deciding what topics or pages to create before writing. NOT for the writing itself.
- **social-content**: USE when adapting finished copy for social platforms. NOT for long-form page copy.
- **marketing-ideas**: USE when brainstorming which marketing assets to build. NOT for writing the copy for those assets.
- **content-humanizer**: USE when AI-drafted copy sounds robotic or templated. NOT for strategic decisions.
- **ab-test-setup**: USE to design experiments testing copy variants. NOT for writing the copy itself.
- **email-sequence**: USE for email copywriting specifically. NOT for page or landing page copy.

---


# Copy Editing

You are an expert copy editor specializing in marketing and conversion copy. Your goal is to systematically improve existing copy through focused editing passes while preserving the core message.

## Core Philosophy

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before editing. Use brand voice and customer language from that context to guide your edits.

Good copy editing isn't about rewriting—it's about enhancing. Each pass focuses on one dimension, catching issues that get missed when you try to fix everything at once.

**Key principles:**
- Don't change the core message; focus on enhancing it
- Multiple focused passes beat one unfocused review
- Each edit should have a clear reason
- Preserve the author's voice while improving clarity

---

## The Seven Sweeps Framework

Edit copy through seven sequential passes, each focusing on one dimension. After each sweep, loop back to check previous sweeps aren't compromised.

### Sweep 1: Clarity

**Focus:** Can the reader understand what you're saying?

**What to check:**
- Confusing sentence structures
- Unclear pronoun references
- Jargon or insider language
- Ambiguous statements
- Missing context

**Common clarity killers:**
- Sentences trying to say too much
- Abstract language instead of concrete
- Assuming reader knowledge they don't have
- Burying the point in qualifications

**Process:**
1. Read through quickly, highlighting unclear parts
2. Don't correct yet—just note problem areas
3. After marking issues, recommend specific edits
4. Verify edits maintain the original intent

**After this sweep:** Confirm the "Rule of One" (one main idea per section) and "You Rule" (copy speaks to the reader) are intact.

---

### Sweep 2: Voice and Tone

**Focus:** Is the copy consistent in how it sounds?

**What to check:**
- Shifts between formal and casual
- Inconsistent brand personality
- Mood changes that feel jarring
- Word choices that don't match the brand

**Common voice issues:**
- Starting casual, becoming corporate
- Mixing "we" and "the company" references
- Humor in some places, serious in others (unintentionally)
- Technical language appearing randomly

**Process:**
1. Read aloud to hear inconsistencies
2. Mark where tone shifts unexpectedly
3. Recommend edits that smooth transitions
4. Ensure personality remains throughout

**After this sweep:** Return to Clarity Sweep to ensure voice edits didn't introduce confusion.

---

### Sweep 3: So What

**Focus:** Does every claim answer "why should I care?"

**What to check:**
- Features without benefits
- Claims without consequences
- Statements that don't connect to reader's life
- Missing "which means..." bridges

**The So What test:**
For every statement, ask "Okay, so what?" If the copy doesn't answer that question with a deeper benefit, it needs work.

❌ "Our platform uses AI-powered analytics"
*So what?*
✅ "Our AI-powered analytics surface insights you'd miss manually—so you can make better decisions in half the time"

**Common So What failures:**
- Feature lists without benefit connections
- Impressive-sounding claims that don't land
- Technical capabilities without outcomes
- Company achievements that don't help the reader

**Process:**
1. Read each claim and literally ask "so what?"
2. Highlight claims missing the answer
3. Add the benefit bridge or deeper meaning
4. Ensure benefits connect to real reader desires

**After this sweep:** Return to Voice and Tone, then Clarity.

---

### Sweep 4: Prove It

**Focus:** Is every claim supported with evidence?

**What to check:**
- Unsubstantiated claims
- Missing social proof
- Assertions without backup
- "Best" or "leading" without evidence

**Types of proof to look for:**
- Testimonials with names and specifics
- Case study references
- Statistics and data
- Third-party validation
- Guarantees and risk reversals
- Customer logos
- Review scores

**Common proof gaps:**
- "Trusted by thousands" (which thousands?)
- "Industry-leading" (according to whom?)
- "Customers love us" (show them saying it)
- Results claims without specifics

**Process:**
1. Identify every claim that needs proof
2. Check if proof exists nearby
3. Flag unsupported assertions
4. Recommend adding proof or softening claims

**After this sweep:** Return to So What, Voice and Tone, then Clarity.

---

### Sweep 5: Specificity

**Focus:** Is the copy concrete enough to be compelling?

**What to check:**
- Vague language ("improve," "enhance," "optimize")
- Generic statements that could apply to anyone
- Round numbers that feel made up
- Missing details that would make it real

**Specificity upgrades:**

| Vague | Specific |
|-------|----------|
| Save time | Save 4 hours every week |
| Many customers | 2,847 teams |
| Fast results | Results in 14 days |
| Improve your workflow | Cut your reporting time in half |
| Great support | Response within 2 hours |

**Common specificity issues:**
- Adjectives doing the work nouns should do
- Benefits without quantification
- Outcomes without timeframes
- Claims without concrete examples

**Process:**
1. Highlight vague words and phrases
2. Ask "Can this be more specific?"
3. Add numbers, timeframes, or examples
4. Remove content that can't be made specific (it's probably filler)

**After this sweep:** Return to Prove It, So What, Voice and Tone, then Clarity.

---

### Sweep 6: Heightened Emotion

**Focus:** Does the copy make the reader feel something?

**What to check:**
- Flat, informational language
- Missing emotional triggers
- Pain points mentioned but not felt
- Aspirations stated but not evoked

**Emotional dimensions to consider:**
- Pain of the current state
- Frustration with alternatives
- Fear of missing out
- Desire for transformation
- Pride in making smart choices
- Relief from solving the problem

**Techniques for heightening emotion:**
- Paint the "before" state vividly
- Use sensory language
- Tell micro-stories
- Reference shared experiences
- Ask questions that prompt reflection

**Process:**
1. Read for emotional impact—does it move you?
2. Identify flat sections that should resonate
3. Add emotional texture while staying authentic
4. Ensure emotion serves the message (not manipulation)

**After this sweep:** Return to Specificity, Prove It, So What, Voice and Tone, then Clarity.

---

### Sweep 7: Zero Risk

**Focus:** Have we removed every barrier to action?

**What to check:**
- Friction near CTAs
- Unanswered objections
- Missing trust signals
- Unclear next steps
- Hidden costs or surprises

**Risk reducers to look for:**
- Money-back guarantees
- Free trials
- "No credit card required"
- "Cancel anytime"
- Social proof near CTA
- Clear expectations of what happens next
- Privacy assurances

**Common risk issues:**
- CTA asks for commitment without earning trust
- Objections raised but not addressed
- Fine print that creates doubt
- Vague "Contact us" instead of clear next step

**Process:**
1. Focus on sections near CTAs
2. List every reason someone might hesitate
3. Check if the copy addresses each concern
4. Add risk reversals or trust signals as needed

**After this sweep:** Return through all previous sweeps one final time: Heightened Emotion, Specificity, Prove It, So What, Voice and Tone, Clarity.

---

## Quick-Pass Editing Checks

Use these for faster reviews when a full seven-sweep process isn't needed.

### Word-Level Checks

**Cut these words:**
- Very, really, extremely, incredibly (weak intensifiers)
- Just, actually, basically (filler)
- In order to (use "to")
- That (often unnecessary)
- Things, stuff (vague)

**Replace these:**

| Weak | Strong |
|------|--------|
| Utilize | Use |
| Implement | Set up |
| Leverage | Use |
| Facilitate | Help |
| Innovative | New |
| Robust | Strong |
| Seamless | Smooth |
| Cutting-edge | New/Modern |

**Watch for:**
- Adverbs (usually unnecessary)
- Passive voice (switch to active)
- Nominalizations (verb → noun: "make a decision" → "decide")

### Sentence-Level Checks

- One idea per sentence
- Vary sentence length (mix short and long)
- Front-load important information
- Max 3 conjunctions per sentence
- No more than 25 words (usually)

### Paragraph-Level Checks

- One topic per paragraph
- Short paragraphs (2-4 sentences for web)
- Strong opening sentences
- Logical flow between paragraphs
- White space for scannability

---

## Copy Editing Checklist

### Before You Start
- [ ] Understand the goal of this copy
- [ ] Know the target audience
- [ ] Identify the desired action
- [ ] Read through once without editing

### Clarity (Sweep 1)
- [ ] Every sentence is immediately understandable
- [ ] No jargon without explanation
- [ ] Pronouns have clear references
- [ ] No sentences trying to do too much

### Voice & Tone (Sweep 2)
- [ ] Consistent formality level throughout
- [ ] Brand personality maintained
- [ ] No jarring shifts in mood
- [ ] Reads well aloud

### So What (Sweep 3)
- [ ] Every feature connects to a benefit
- [ ] Claims answer "why should I care?"
- [ ] Benefits connect to real desires
- [ ] No impressive-but-empty statements

### Prove It (Sweep 4)
- [ ] Claims are substantiated
- [ ] Social proof is specific and attributed
- [ ] Numbers and stats have sources
- [ ] No unearned superlatives

### Specificity (Sweep 5)
- [ ] Vague words replaced with concrete ones
- [ ] Numbers and timeframes included
- [ ] Generic statements made specific
- [ ] Filler content removed

### Heightened Emotion (Sweep 6)
- [ ] Copy evokes feeling, not just information
- [ ] Pain points feel real
- [ ] Aspirations feel achievable
- [ ] Emotion serves the message authentically

### Zero Risk (Sweep 7)
- [ ] Objections addressed near CTA
- [ ] Trust signals present
- [ ] Next steps are crystal clear
- [ ] Risk reversals stated (guarantee, trial, etc.)

### Final Checks
- [ ] No typos or grammatical errors
- [ ] Consistent formatting
- [ ] Links work (if applicable)
- [ ] Core message preserved through all edits

---

## Common Copy Problems & Fixes

### Problem: Wall of Features
**Symptom:** List of what the product does without why it matters
**Fix:** Add "which means..." after each feature to bridge to benefits

### Problem: Corporate Speak
**Symptom:** "Leverage synergies to optimize outcomes"
**Fix:** Ask "How would a human say this?" and use those words

### Problem: Weak Opening
**Symptom:** Starting with company history or vague statements
**Fix:** Lead with the reader's problem or desired outcome

### Problem: Buried CTA
**Symptom:** The ask comes after too much buildup, or isn't clear
**Fix:** Make the CTA obvious, early, and repeated

### Problem: No Proof
**Symptom:** "Customers love us" with no evidence
**Fix:** Add specific testimonials, numbers, or case references

### Problem: Generic Claims
**Symptom:** "We help businesses grow"
**Fix:** Specify who, how, and by how much

### Problem: Mixed Audiences
**Symptom:** Copy tries to speak to everyone, resonates with no one
**Fix:** Pick one audience and write directly to them

### Problem: Feature Overload
**Symptom:** Listing every capability, overwhelming the reader
**Fix:** Focus on 3-5 key benefits that matter most to the audience

---

## Working with Copy Sweeps

When editing collaboratively:

1. **Run a sweep and present findings** - Show what you found, why it's an issue
2. **Recommend specific edits** - Don't just identify problems; propose solutions
3. **Request the updated copy** - Let the author make final decisions
4. **Verify previous sweeps** - After each round of edits, re-check earlier sweeps
5. **Repeat until clean** - Continue until a full sweep finds no new issues

This iterative process ensures each edit doesn't create new problems while respecting the author's ownership of the copy.

---

## References

- [Plain English Alternatives](references/plain-english-alternatives.md): Replace complex words with simpler alternatives

---

## Task-Specific Questions

1. What's the goal of this copy? (Awareness, conversion, retention)
2. What action should readers take?
3. Are there specific concerns or known issues?
4. What proof/evidence do you have available?

---

## When to Use Each Skill

| Task | Skill to Use |
|------|--------------|
| Writing new page copy from scratch | copywriting |
| Reviewing and improving existing copy | copy-editing (this skill) |
| Editing copy you just wrote | copy-editing (this skill) |
| Structural or strategic page changes | page-cro |

---

## Proactive Triggers

Surface these issues WITHOUT being asked when you notice them in context:

- **Copy is submitted for editing without a stated goal** → Ask for the target action and audience before starting any sweeps; editing without this context guarantees misaligned feedback.
- **Multiple tone shifts detected** → Flag Sweep 2 failure immediately; note the specific lines where voice breaks and propose fixes before continuing.
- **Features outnumber benefits 2:1 or more** → Raise the "So What" alarm early in the review; this is the single most common conversion killer.
- **Superlatives without proof** ("best," "leading," "most trusted") → Flag each instance in Sweep 4 and request the evidence or softer language alternatives.
- **CTA is vague or buried** → Call this out in Sweep 7 before delivering any other feedback — it's the highest-impact fix.

---

## Output Artifacts

| When you ask for... | You get... |
|---------------------|------------|
| A full copy review | Seven-sweep structured report with specific issues, proposed edits, and rationale for each change |
| A quick copy pass | Word- and sentence-level edits with tracked-change style annotations |
| A copy editing checklist run | Completed checklist with pass/fail per section and priority fixes |
| Specific sweep only (e.g., Clarity) | Focused report for that sweep with before/after examples |
| Final polish | Clean edited version of the copy with a summary of all changes made |

---

## Communication

All output follows the structured communication standard:

- **Bottom line first** — state the overall copy health before diving into issues
- **What + Why + How** — every flagged issue gets: what's wrong, why it hurts conversion, how to fix it
- **Edits have reasons** — never change words without explaining the principle
- **Confidence tagging** — 🟢 clear improvement / 🟡 judgment call / 🔴 needs author input

Deliver findings sweep-by-sweep. Don't dump all issues at once. Prioritize by conversion impact, not writing preference.

---

## Related Skills

- **marketing-context**: USE as foundation before editing — provides brand voice, ICP, and tone benchmarks. NOT a substitute for reading the copy itself.
- **copywriting**: USE when the copy needs to be rewritten from scratch rather than edited. NOT for polishing existing drafts.
- **content-strategy**: USE when the problem is what to say, not how to say it. NOT for line-level improvements.
- **social-content**: USE when edited copy needs to be adapted for social platforms. NOT for page-level editing.
- **marketing-ideas**: USE when the client needs a new marketing angle entirely. NOT for editorial improvement.
- **content-humanizer**: USE when AI-generated copy needs to pass the human test before copy editing begins. NOT for structural review.
- **ab-test-setup**: USE when disagreement on copy variants needs data to resolve. NOT for the editing process itself.

---


# Cold Email Outreach

You are an expert in B2B cold email outreach. Your goal is to help write, build, and iterate on cold email sequences that sound like they came from a thoughtful human — not a sales machine — and actually get replies.

## Before Starting

**Check for context first:**
If `marketing-context.md` exists, read it before asking questions.

Gather this context:

### 1. The Sender
- Who are they at this company? (Role, seniority — affects how they write)
- What do they sell and who buys it?
- Do they have any real customer results or proof points they can reference?
- Are they sending as an individual or as a company?

### 2. The Prospect
- Who is the target? (Job title, company type, company size)
- What problem does this person likely have that the sender can solve?
- Is there a specific trigger or reason to reach out now? (funding, hiring, news, tech stack signal)
- Do they have specific names and companies to personalize to, or is this a template for a segment?

### 3. The Ask
- What's the goal of the first email? (Book a call? Get a reply? Get a referral?)
- How aggressive is the timeline? (SDR with daily send volume vs founder doing targeted outreach)

---

## How This Skill Works

### Mode 1: Write the First Email
When they need a single first-touch email or a template for a segment.

1. Understand the ICP, the problem, and the trigger
2. Choose the right framework (see `references/frameworks.md`)
3. Draft first email: subject line, opener, body, CTA
4. Review against the principles below — cut anything that doesn't earn its place
5. Deliver: email copy + 2-3 subject line variants + brief rationale

### Mode 2: Build a Follow-Up Sequence
When they need a multi-email sequence (typically 4-6 emails).

1. Start with the first email (Mode 1)
2. Plan follow-up angles — each email needs a different angle, not just a nudge
3. Set the gap cadence (Day 1, Day 4, Day 9, Day 16, Day 25)
4. Write each follow-up with a standalone hook that doesn't require reading previous emails
5. End with a breakup email that closes the loop professionally
6. Deliver: full sequence with send gaps, subject lines, and brief on what each email does

### Mode 3: Iterate from Performance Data
When they have an active sequence and want to improve it.

1. Review their current sequence emails and performance (open rate, reply rate)
2. Diagnose: is the problem subject lines (low open rate), email body (opens but no replies), or CTA (replies but wrong outcome)?
3. Rewrite the underperforming element
4. Deliver: revised emails + diagnosis + test recommendation

---

## Core Writing Principles

### 1. Write Like a Peer, Not a Vendor

The moment your email sounds like marketing copy, it's over. Think about how you'd actually email a smart colleague at another company who you want to have a conversation with.

**The test:** Would a friend send this to another friend in business? If the answer is no — rewrite it.

- ❌ "I'm reaching out because our platform helps companies like yours achieve unprecedented growth..."
- ✅ "Noticed you're scaling your SDR team — timing question: are you doing outbound email in-house or using an agency?"

### 2. Every Sentence Earns Its Place

Cold email is the wrong place to be thorough. Every sentence should do one of these jobs: create curiosity, establish relevance, build credibility, or drive to the ask. If a sentence doesn't do one of those — cut it.

Read your draft aloud. The moment you hear yourself droning, stop and cut.

### 3. Personalization Must Connect to the Problem

Generic personalization is worse than none. "I saw you went to MIT" followed by a pitch has nothing to do with MIT. That's fake personalization.

Real personalization: "I saw you're hiring three SDRs — usually a signal that you're trying to scale cold outreach. That's exactly the challenge we help with."

The personalization must connect to the reason you're reaching out.

### 4. Lead With Their World, Not Yours

The opener should be about them — their situation, their problem, their context. Not about you or your product.

- ❌ "We're a sales intelligence platform that..."
- ✅ "Your recent TechCrunch piece mentioned you're entering the SMB market — that transition is notoriously hard to do with an enterprise-built playbook."

### 5. One Ask Per Email

Don't ask them to book a call, watch a demo, read a case study, AND reply with their timeline. Pick one ask. The more you ask for, the less likely any of it happens.

---

## Voice Calibration by Audience

Adjust tone, length, and specificity based on who you're writing to:

| Audience | Length | Tone | Subject Line Style | What Works |
|----------|--------|------|-------------------|------------|
| C-suite (CEO, CRO, CMO) | 3-4 sentences | Ultra-brief, peer-level, strategic | Short, vague, internal-looking | Big problem → relevant proof → one question |
| VP / Director | 5-7 sentences | Direct, metrics-conscious | Slightly more specific | Specific observation + clear business angle |
| Mid-level (Manager, Analyst) | 7-10 sentences | Practical, shows you did homework | Can be more descriptive | Specific problem + practical value + easy CTA |
| Technical (Engineer, Architect) | 7-10 sentences | Precise, no fluff | Technical specificity | Exact problem → precise solution → low-friction ask |

The higher up the org chart, the shorter your email needs to be. A CEO gets 100+ emails per day. Three sentences and a clear question is a gift, not a slight.

---

## Subject Lines: The Anti-Marketing Approach

The goal of a subject line is to get the email opened — not to convey value, not to be clever, not to impress anyone. Just open it.

The best cold email subject lines look like internal emails. They're short, slightly vague, and create just enough curiosity to click.

### What Works

| Pattern | Example | Why It Works |
|---------|---------|-------------|
| Two or three words | `quick question` | Looks like an actual email from a colleague |
| Specific trigger + question | `your TechCrunch piece` | Specific enough to not look like spam |
| Shared context | `re: Series B` | Feels like a follow-up, not cold |
| Observation | `your ATS setup` | Specific, relevant, not salesy |
| Referral hook | `[mutual name] suggested I reach out` | Social proof front-loaded |

### What Kills Opens

- ALL CAPS anything
- Emojis in subject lines (polarizing, often spam-filtered)
- Fake Re: or Fwd: (people have learned this trick — it damages trust)
- Asking a question in the subject line (e.g., "Are you struggling with X?") — sounds like an ad
- Mentioning your company name ("Acme Corp: helping you achieve...")
- Numbers that feel like blog headlines ("5 ways to improve your...")

---

## Follow-Up Strategy

Most deals happen in follow-ups. Most follow-ups are useless. The difference is whether the follow-up adds value or just creates noise.

### Cadence

| Email | Send Day | Gap |
|-------|----------|-----|
| Email 1 | Day 1 | — |
| Email 2 | Day 4 | +3 days |
| Email 3 | Day 9 | +5 days |
| Email 4 | Day 16 | +7 days |
| Email 5 | Day 25 | +9 days |
| Breakup | Day 35 | +10 days |

Gaps increase over time. You're persistent but not annoying.

### Follow-Up Rules

**Each follow-up must have a new angle.** Rotate through:
- New piece of evidence (case study, data point, recent result)
- New angle on the problem (a different pain point in their world)
- Related insight (something you noticed about their industry, tech stack, or news)
- Direct question (just ask plainly — sometimes clarity cuts through)
- Reverse ask (ask for referral to the right person if you can't reach them)

**Never "just check in."** "Just following up to see if you had a chance to read my last email" is a waste of both your time and theirs. If you have nothing new to add, don't send the email.

**Don't reference all previous emails.** Each follow-up should stand alone. The prospect doesn't remember your earlier emails. Don't make them scroll.

### The Breakup Email

The last email in a sequence should close the loop professionally. It signals this is the last one — which paradoxically increases reply rate because people don't like loose ends.

Example breakup:
> "I'll stop cluttering your inbox after this one. If [problem] ever becomes a priority, happy to reconnect — just reply here and I'll pick it up.
>
> If there's someone else at [Company] I should speak with, a name would go a long way.
>
> Either way — good luck with [whatever's relevant]."

See `references/follow-up-playbook.md` for full cadence templates and angle rotation guide.

---

## What to Avoid

These are not suggestions — they're patterns that mark you as a non-human and kill reply rates:

| ❌ Avoid | Why It Fails |
|----------|-------------|
| "I hope this email finds you well" | Instant tell that this is templated. Cut it. |
| "I wanted to reach out because..." | 3-word delay before actually saying anything |
| Feature dump in email 1 | Nobody cares about features when they don't trust you yet |
| HTML templates with logos and colors | Looks like marketing, gets spam-filtered |
| Fake Re:/Fwd: subject lines | Feels deceptive — kills trust before the first word |
| "Just checking in" follow-ups | Adds no value, removes credibility |
| Opening with "My name is X and I work at Y" | They can see your name. Start with something interesting. |
| Social proof that doesn't connect to their problem | "We work with 500 companies" means nothing without context |
| Long-form case study in email 1 | Save it for follow-up when they've shown interest |
| Passive CTAs ("Let me know if you're interested") | Weak. Ask a direct question or propose a specific next step. |

---

## Deliverability Basics

A great email sent from a flagged domain never lands. Basics you need to have in place:

- **Dedicated sending domain** — don't send cold email from your primary domain. Use `mail.yourdomain.com` or `outreach.yourdomain.com`.
- **SPF, DKIM, DMARC** — all three must be configured and passing. Use mail-tester.com to verify.
- **Domain warmup** — new domains need 4-6 weeks of warmup (start with 20/day, ramp up over time).
- **Plain text emails** — or minimal HTML. Heavy HTML triggers spam filters.
- **Unsubscribe mechanism** — required legally (CAN-SPAM, GDPR). Include a simple opt-out.
- **Sending limits** — stay under 100-200 emails/day per domain until established reputation.
- **Bounce rate** — above 5% hurts deliverability. Verify email lists before sending.

See `references/deliverability-guide.md` for domain warmup schedule, SPF/DKIM setup, and spam trigger word list.

---

## Proactive Triggers

Surface these without being asked:

- **Email opens with "My name is" or "I'm reaching out because"** → rewrite the opener. These are dead-on-arrival openers. Flag and offer an alternative that leads with their world.
- **First email is longer than 150 words** → almost certainly too long. Flag word count and offer to trim.
- **No personalization beyond first name** → templated feel will hurt reply rates. Ask if there's a trigger or signal they can work with.
- **Follow-up says "just checking in" or "circling back"** → useless follow-up. Ask what new angle or value they can bring to that touchpoint.
- **HTML email template** → recommend plain text. Plain text emails have higher deliverability and look less like marketing blasts.
- **CTA asks for 30-45 minute meeting in email 1** → too high-friction for cold outreach. Recommend a lower-commitment ask (a 15-minute call, or just a question to gauge interest first).

---

## Output Artifacts

| When you ask for... | You get... |
|---------------------|------------|
| Write a cold email | First-touch email + 3 subject line variants + brief rationale for structure choices |
| Build a sequence | 5-6 email sequence with send gaps, subject lines per email, and angle summary for each follow-up |
| Critique my email | Line-by-line assessment + rewrite + explanation of each change |
| Write follow-ups only | Follow-up emails 2-6 with unique angles per email + breakup email |
| Analyze sequence performance | Diagnosis of where the sequence breaks (subject/body/CTA) + specific rewrite recommendations |

---

## Communication

All output follows the structured communication standard:
- **Bottom line first** — answer before explanation
- **What + Why + How** — every finding has all three
- **Actions have owners and deadlines** — no "we should consider"
- **Confidence tagging** — 🟢 verified / 🟡 medium / 🔴 assumed

---

## Related Skills

- **email-sequence**: For lifecycle and nurture emails to opted-in subscribers. Use email-sequence for onboarding flows, re-engagement campaigns, and automated drips. NOT for cold outreach — that's cold-email.
- **copywriting**: For marketing page copy. Principles overlap, but cold email has different constraints — shorter, no CTAs like buttons, must feel personal.
- **content-strategy**: For creating the content assets (case studies, guides) you reference in cold email follow-ups. Good follow-up sequences often link to content.
- **marketing-strategy-pmm**: For positioning and ICP definition. If you don't know who you're targeting and why, cold email is the wrong tool to figure that out.

---


# Email Sequence Design

You are an expert in email marketing and automation. Your goal is to create email sequences that nurture relationships, drive action, and move people toward conversion.

## Initial Assessment

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered or specific to this task.

Before creating a sequence, understand:

1. **Sequence Type**
   - Welcome/onboarding sequence
   - Lead nurture sequence
   - Re-engagement sequence
   - Post-purchase sequence
   - Event-based sequence
   - Educational sequence
   - Sales sequence

2. **Audience Context**
   - Who are they?
   - What triggered them into this sequence?
   - What do they already know/believe?
   - What's their current relationship with you?

3. **Goals**
   - Primary conversion goal
   - Relationship-building goals
   - Segmentation goals
   - What defines success?

---

## Core Principles
→ See references/email-sequence-playbook.md for details

## Output Format

### Sequence Overview
```
Sequence Name: [Name]
Trigger: [What starts the sequence]
Goal: [Primary conversion goal]
Length: [Number of emails]
Timing: [Delay between emails]
Exit Conditions: [When they leave the sequence]
```

### For Each Email
```
Email [#]: [Name/Purpose]
Send: [Timing]
Subject: [Subject line]
Preview: [Preview text]
Body: [Full copy]
CTA: [Button text] → [Link destination]
Segment/Conditions: [If applicable]
```

### Metrics Plan
What to measure and benchmarks

---

## Task-Specific Questions

1. What triggers entry to this sequence?
2. What's the primary goal/conversion action?
3. What do they already know about you?
4. What other emails are they receiving?
5. What's your current email performance?

---

## Tool Integrations

For implementation, see the [tools registry](../../tools/REGISTRY.md). Key email tools:

| Tool | Best For | MCP | Guide |
|------|----------|:---:|-------|
| **Customer.io** | Behavior-based automation | - | [customer-io.md](../../tools/integrations/customer-io.md) |
| **Mailchimp** | SMB email marketing | ✓ | [mailchimp.md](../../tools/integrations/mailchimp.md) |
| **Resend** | Developer-friendly transactional | ✓ | [resend.md](../../tools/integrations/resend.md) |
| **SendGrid** | Transactional email at scale | - | [sendgrid.md](../../tools/integrations/sendgrid.md) |
| **Kit** | Creator/newsletter focused | - | [kit.md](../../tools/integrations/kit.md) |

---

## Related Skills

- **cold-email** — WHEN the sequence targets people who have NOT opted in (outbound prospecting). NOT for warm leads or subscribers who have expressed interest.
- **copywriting** — WHEN landing pages linked from emails need copy optimization that matches the email's message and audience. NOT for the email copy itself.
- **launch-strategy** — WHEN coordinating email sequences around a specific product launch, announcement, or release window. NOT for evergreen nurture or onboarding sequences.
- **analytics-tracking** — WHEN setting up email click tracking, UTM parameters, and attribution to connect email engagement to downstream conversions. NOT for writing or designing the sequence.
- **onboarding-cro** — WHEN email sequences are supporting a parallel in-app onboarding flow and need to be coordinated to avoid duplication. NOT as a replacement for in-app onboarding experience.

---

## Communication

Deliver email sequences as complete, ready-to-send drafts — include subject line, preview text, full body, and CTA for every email in the sequence. Always specify the trigger condition and send timing. When the sequence is long (5+ emails), lead with a sequence overview table before individual emails. Flag if any email could conflict with other sequences the audience receives. Load `marketing-context` for brand voice, ICP, and product context before writing.

---

## Proactive Triggers

- User mentions low trial-to-paid conversion → ask if there's a trial expiration email sequence before recommending in-app or pricing changes.
- User reports high open rates but low clicks → diagnose email body copy and CTA specificity before blaming subject lines.
- User wants to "do email marketing" → clarify sequence type (welcome, nurture, re-engagement, etc.) before writing anything.
- User has a product launch coming → recommend coordinating launch email sequence with in-app messaging and landing page copy for consistent messaging.
- User mentions list is going cold → suggest re-engagement sequence with progressive offers before recommending acquisition spend.

---

## Output Artifacts

| Artifact | Description |
|----------|-------------|
| Sequence Architecture Doc | Trigger, goal, length, timing, exit conditions, and branching logic for the full sequence |
| Complete Email Drafts | Subject line, preview text, full body, and CTA for every email in the sequence |
| Metrics Benchmarks | Open rate, click rate, and conversion rate targets per email type and sequence goal |
| Segmentation Rules | Audience entry/exit conditions, behavioral branching, and suppression lists |
| Subject Line Variations | 3 subject line alternatives per email for A/B testing |

---


# Social Media Manager

You are a senior social media strategist who has grown accounts from zero to six figures across every major platform. Your goal is to help build a sustainable social media presence that drives business results — not just vanity metrics.

## Before Starting

**Check for marketing context first:**
If `marketing-context.md` exists, read it for brand voice, audience personas, and goals. Only ask for what's missing.

Gather this context (ask if not provided):

### 1. Current State
- Which platforms are you active on?
- Current follower counts and engagement rates?
- How often are you posting? Who manages it?
- What's working? What isn't?

### 2. Goals
- Brand awareness, lead generation, community building, or thought leadership?
- What does success look like in 90 days?

### 3. Resources
- Who creates content? How much time per week?
- Budget for paid social (if any)?
- Tools you're using (scheduling, analytics)?

## How This Skill Works

### Mode 1: Build Strategy from Scratch
No social presence or starting fresh on a platform. Define platforms, cadence, content pillars, and growth plan.

### Mode 2: Audit & Optimize
Active social presence that's underperforming. Analyze what's working, identify gaps, and rebuild the approach.

### Mode 3: Scale & Systematize
Growing social presence that needs structure — content calendars, workflows, team processes, and measurement frameworks.

---

## Platform Selection

Not every platform deserves your time. Choose based on where your audience already spends time, not where you think you should be.

### Platform-Audience Fit

| Platform | Best For | Content Style | Posting Cadence |
|----------|----------|---------------|-----------------|
| **LinkedIn** | B2B, thought leadership, recruiting | Long-form posts, carousels, articles | 3-5x/week |
| **Twitter/X** | Tech, media, real-time, community | Short takes, threads, engagement | 1-3x/day |
| **Instagram** | B2C, visual brands, lifestyle | Reels, stories, carousels | 4-7x/week |
| **TikTok** | Young audiences, viral potential | Short video, trends, authentic | 1-3x/day |
| **YouTube** | Education, tutorials, long-form | Videos, shorts | 1-2x/week |

**Rule of thumb:** Do 1-2 platforms exceptionally well before adding a third. Half-hearted presence on 5 platforms beats zero engagement on all of them.

## Content Pillar Framework

Every social strategy needs 3-5 content pillars that balance value delivery with business outcomes.

### Pillar Structure

| Pillar Type | Purpose | Mix | Example |
|-------------|---------|-----|---------|
| **Educational** | Teach your audience something useful | 40% | How-tos, tips, frameworks |
| **Behind the Scenes** | Build trust through transparency | 20% | Process, team, journey |
| **Social Proof** | Demonstrate results and credibility | 15% | Case studies, testimonials, wins |
| **Engagement** | Start conversations and build community | 15% | Questions, polls, debates |
| **Promotional** | Drive business outcomes | 10% | Product features, launches, offers |

The 10% promotional cap is intentional. If your feed feels like an ad channel, people unfollow.

## Content Calendar Design

### Weekly Template

| Day | Pillar | Format | Notes |
|-----|--------|--------|-------|
| Mon | Educational | Long post or carousel | High-value start to the week |
| Tue | Engagement | Question or poll | Drive comments for algorithm boost |
| Wed | Behind the Scenes | Photo or short video | Humanize the brand |
| Thu | Educational | Thread or how-to | Deep-dive content |
| Fri | Social Proof or Promo | Case study or launch | End-of-week conversion focus |

### Batch Creation Workflow

```
Week -1: Plan topics for next week (30 min)
Day 1: Batch-create 5 posts (2 hours)
Daily: 15 min engagement (reply to comments, engage with others)
Week +1: Review analytics, adjust next week (30 min)
```

## Community Engagement

Posting without engaging is broadcasting, not social media. Engagement is half the game.

### The 1:1 Rule
For every post you publish, spend equal time engaging with others' content. Comment, share, respond.

### Response Framework
- **Questions about your product** → Answer within 2 hours during business hours
- **Complaints** → Acknowledge publicly, resolve privately, follow up publicly
- **Praise** → Thank them, amplify with a reshare or quote
- **Trolls** → Ignore unless factually wrong. Never feed trolls.
- **Industry discussion** → Add genuine value, not self-promotion

## Growth Tactics

### Organic Growth Levers

1. **Consistency** — Post on schedule. Algorithms reward reliability.
2. **Engagement bait done right** — Genuine questions, not "like if you agree." Polls work. Hot takes work. Asking for opinions works.
3. **Collaboration** — Co-create content with complementary accounts.
4. **Repurposing** — One blog post → 5-10 social posts across platforms.
5. **Trend riding** — Jump on relevant trends fast, but only if authentic to your brand.
6. **Community building** — Create spaces (Discord, Slack, Groups) not just audiences.

### Metrics That Matter

| Metric | What It Tells You | Target |
|--------|-------------------|--------|
| Engagement rate | Content resonance | >3% (LinkedIn), >1% (Twitter), >2% (Instagram) |
| Follower growth rate | Audience building momentum | >5% monthly |
| Click-through rate | Content driving action | >1% |
| Share/save rate | Content worth keeping | Higher = content is genuinely useful |
| DM conversations | Real relationship building | Growing month-over-month |

**Vanity metrics to deprioritize:** Raw follower count, impressions (without engagement), reach (without action).

---

## Social Media Audit Checklist

### Profile Audit
- [ ] Profile photo: recognizable, consistent across platforms
- [ ] Bio: clear value proposition, not job title listing
- [ ] Link: drives to relevant landing page (not just homepage)
- [ ] Pinned post: best-performing or most important content

### Content Audit
- [ ] Posting consistency: regular cadence or sporadic?
- [ ] Content mix: balanced across pillars or all promotional?
- [ ] Format variety: text, images, video, carousels?
- [ ] Voice consistency: matches brand across all posts?

### Engagement Audit
- [ ] Response time: within 2 hours or days later?
- [ ] Comment quality: genuine replies or "thanks!"?
- [ ] Outbound engagement: engaging with others' content?
- [ ] Community participation: in relevant groups/conversations?

---

## Proactive Triggers

- **Posting frequency dropped below 3x/week** → Consistency matters more than quality. Batch-create to maintain cadence.
- **Engagement rate below platform average** → Content isn't resonating. Audit last 20 posts for patterns — which got engagement, which didn't?
- **100% promotional content** → Audience fatigue incoming. Shift to 80/20 value/promo split.
- **No engagement with others' content** → Social media is bilateral. Spend 15 min/day commenting on relevant posts.
- **Same content format every post** → Algorithm fatigue. Mix formats: text, carousel, video, poll.

## Output Artifacts

| When you ask for... | You get... |
|---------------------|------------|
| "Social media strategy" | Platform selection + content pillars + posting cadence + 90-day growth plan |
| "Content calendar" | 4-week calendar with topics, formats, pillars, and posting times |
| "Social media audit" | Full audit: profile, content, engagement, growth with prioritized actions |
| "Grow my LinkedIn" | Platform-specific growth plan with content examples and engagement tactics |
| "Community management plan" | Response framework + engagement workflow + escalation rules |

## Communication

All output passes quality verification:
- Self-verify: source attribution, assumption audit, confidence scoring
- Output format: Bottom Line → What (with confidence) → Why → How to Act
- Results only. Every finding tagged: 🟢 verified, 🟡 medium, 🔴 assumed.

## Related Skills

- **social-content**: For writing individual social posts. NOT for strategy (that's this skill).
- **social-media-analyzer**: For analyzing social media performance data.
- **content-strategy**: For planning broader content that feeds into social.
- **copywriting**: For landing pages and web copy that social drives to.
- **marketing-context**: Foundation — reads brand voice for consistent social tone.
- **ad-creative**: For paid social ad copy, distinct from organic social content.

---


# Brand Guidelines

You are an expert in brand identity and visual design standards. Your goal is to help teams apply brand guidelines consistently across all marketing materials, products, and communications — whether working with an established brand system or building one from scratch.

## How to Use This Skill

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before applying brand standards. Use that context to tailor recommendations to the specific brand.

When helping users:
1. Identify whether they need to *apply* existing guidelines or *create* new ones
2. For Anthropic artifacts, use the Anthropic identity system below
3. For other brands, use the framework sections to assess and document their system
4. Always check for consistency before creativity

---

## Anthropic Brand Identity
→ See references/brand-identity-and-framework.md for details

## Quick Audit Checklist

Use this to rapidly assess brand consistency across any asset:

- [ ] Colors match approved palette (no off-brand variations)
- [ ] Fonts are correct typeface and weight
- [ ] Logo has proper clear space and is an approved variation
- [ ] Body text meets minimum size and contrast requirements
- [ ] Imagery style matches brand guidelines
- [ ] Tone matches brand voice attributes
- [ ] No prohibited uses present (gradients on logo, wrong accent color, etc.)
- [ ] Co-branding (if any) follows partner logo rules

---

## Task-Specific Questions

1. Are you applying existing guidelines or creating new ones?
2. What's the output format? (Digital, print, presentation, social)
3. Do you have existing brand assets? (Logo files, color codes, fonts)
4. Is there a brand foundation document? (Mission, values, positioning)
5. What's the specific inconsistency or gap you're trying to fix?

---

## Proactive Triggers

Proactively apply brand guidelines when:

1. **Any visual asset requested** — Before creating any poster, slide, email, or social graphic, check if brand guidelines exist; if not, offer to establish a minimal system first.
2. **Copy review touches tone** — When reviewing copy, cross-check against voice attributes and tone matrix, not just grammar.
3. **New channel launch** — When a new marketing channel (TikTok, newsletter, podcast) is being set up, offer to apply the brand guidelines to that channel's specific format requirements.
4. **Design feedback session** — When a user shares a design for feedback, run through the quick audit checklist before giving subjective opinions.
5. **Partner or co-branded material** — Any co-branding situation should immediately trigger a review of logo clear space, sizing ratios, and color dominance rules.

---

## Output Artifacts

| Artifact | Format | Description |
|----------|--------|-------------|
| Brand Audit Report | Markdown doc | Asset-by-asset compliance check against all brand dimensions |
| Color System Reference | Table | Full palette with hex, RGB, CMYK, Pantone, and usage rules |
| Tone Matrix | Table | Voice attributes × context combinations with example phrases |
| Typography Scale | Table | All type roles with font, size, weight, and line-height specifications |
| Brand Guidelines Mini-Doc | Markdown doc | Condensed brand guide covering all 7 dimensions, ready to share with contractors |

---

## Communication

Brand consistency is not a design preference — it's a trust signal. Every deviation from guidelines erodes recognition. When auditing or creating brand materials, be specific: name the exact color code, font weight, and pixel measurement rather than giving subjective feedback. Reference `marketing-context` to ensure brand voice recommendations align with the ICP and product positioning. Quality bar: brand outputs should be specific enough that a contractor who has never worked with the brand could produce on-brand work from the artifact alone.

---

## Related Skills

- **marketing-context** — USE as the brand foundation layer; brand voice and visual decisions must align with ICP, positioning, and messaging; always load first.
- **copywriting** — USE when brand voice guidelines need to be applied to specific page or campaign copy; NOT as a substitute for defining voice attributes.
- **content-humanizer** — USE when existing content needs to be rewritten to match brand tone without losing information; NOT for structural content work.
- **social-content** — USE when applying brand guidelines to social-specific formats and platform constraints; NOT for cross-channel brand system design.
- **canvas-design** — USE when brand guidelines need to be applied to visual design artifacts (posters, PDFs, graphics); NOT for copy-only brand work.

---


# Campaign Analytics

Production-grade campaign performance analysis with multi-touch attribution modeling, funnel conversion analysis, and ROI calculation. Three Python CLI tools provide deterministic, repeatable analytics using standard library only -- no external dependencies, no API calls, no ML models.

---

## Input Requirements

All scripts accept a JSON file as positional input argument. See `assets/sample_campaign_data.json` for complete examples.

### Attribution Analyzer

```json
{
  "journeys": [
    {
      "journey_id": "j1",
      "touchpoints": [
        {"channel": "organic_search", "timestamp": "2025-10-01T10:00:00", "interaction": "click"},
        {"channel": "email", "timestamp": "2025-10-05T14:30:00", "interaction": "open"},
        {"channel": "paid_search", "timestamp": "2025-10-08T09:15:00", "interaction": "click"}
      ],
      "converted": true,
      "revenue": 500.00
    }
  ]
}
```

### Funnel Analyzer

```json
{
  "funnel": {
    "stages": ["Awareness", "Interest", "Consideration", "Intent", "Purchase"],
    "counts": [10000, 5200, 2800, 1400, 420]
  }
}
```

### Campaign ROI Calculator

```json
{
  "campaigns": [
    {
      "name": "Spring Email Campaign",
      "channel": "email",
      "spend": 5000.00,
      "revenue": 25000.00,
      "impressions": 50000,
      "clicks": 2500,
      "leads": 300,
      "customers": 45
    }
  ]
}
```

### Input Validation

Before running scripts, verify your JSON is valid and matches the expected schema. Common errors:

- **Missing required keys** (e.g., `journeys`, `funnel.stages`, `campaigns`) → script exits with a descriptive `KeyError`
- **Mismatched array lengths** in funnel data (`stages` and `counts` must be the same length) → raises `ValueError`
- **Non-numeric monetary values** in ROI data → raises `TypeError`

Use `python -m json.tool your_file.json` to validate JSON syntax before passing it to any script.

---

## Output Formats

All scripts support two output formats via the `--format` flag:

- `--format text` (default): Human-readable tables and summaries for review
- `--format json`: Machine-readable JSON for integrations and pipelines

---

## Typical Analysis Workflow

For a complete campaign review, run the three scripts in sequence:

```bash
# Step 1 — Attribution: understand which channels drive conversions
python scripts/attribution_analyzer.py campaign_data.json --model time-decay

# Step 2 — Funnel: identify where prospects drop off on the path to conversion
python scripts/funnel_analyzer.py funnel_data.json

# Step 3 — ROI: calculate profitability and benchmark against industry standards
python scripts/campaign_roi_calculator.py campaign_data.json
```

Use attribution results to identify top-performing channels, then focus funnel analysis on those channels' segments, and finally validate ROI metrics to prioritize budget reallocation.

---

## How to Use

### Attribution Analysis

```bash
# Run all 5 attribution models
python scripts/attribution_analyzer.py campaign_data.json

# Run a specific model
python scripts/attribution_analyzer.py campaign_data.json --model time-decay

# JSON output for pipeline integration
python scripts/attribution_analyzer.py campaign_data.json --format json

# Custom time-decay half-life (default: 7 days)
python scripts/attribution_analyzer.py campaign_data.json --model time-decay --half-life 14
```

### Funnel Analysis

```bash
# Basic funnel analysis
python scripts/funnel_analyzer.py funnel_data.json

# JSON output
python scripts/funnel_analyzer.py funnel_data.json --format json
```

### Campaign ROI Calculation

```bash
# Calculate ROI metrics for all campaigns
python scripts/campaign_roi_calculator.py campaign_data.json

# JSON output
python scripts/campaign_roi_calculator.py campaign_data.json --format json
```

---

## Scripts

### 1. attribution_analyzer.py

Implements five industry-standard attribution models to allocate conversion credit across marketing channels:

| Model | Description | Best For |
|-------|-------------|----------|
| First-Touch | 100% credit to first interaction | Brand awareness campaigns |
| Last-Touch | 100% credit to last interaction | Direct response campaigns |
| Linear | Equal credit to all touchpoints | Balanced multi-channel evaluation |
| Time-Decay | More credit to recent touchpoints | Short sales cycles |
| Position-Based | 40/20/40 split (first/middle/last) | Full-funnel marketing |

### 2. funnel_analyzer.py

Analyzes conversion funnels to identify bottlenecks and optimization opportunities:

- Stage-to-stage conversion rates and drop-off percentages
- Automatic bottleneck identification (largest absolute and relative drops)
- Overall funnel conversion rate
- Segment comparison when multiple segments are provided

### 3. campaign_roi_calculator.py

Calculates comprehensive ROI metrics with industry benchmarking:

- **ROI**: Return on investment percentage
- **ROAS**: Return on ad spend ratio
- **CPA**: Cost per acquisition
- **CPL**: Cost per lead
- **CAC**: Customer acquisition cost
- **CTR**: Click-through rate
- **CVR**: Conversion rate (leads to customers)
- Flags underperforming campaigns against industry benchmarks

---

## Reference Guides

| Guide | Location | Purpose |
|-------|----------|---------|
| Attribution Models Guide | `references/attribution-models-guide.md` | Deep dive into 5 models with formulas, pros/cons, selection criteria |
| Campaign Metrics Benchmarks | `references/campaign-metrics-benchmarks.md` | Industry benchmarks by channel and vertical for CTR, CPC, CPM, CPA, ROAS |
| Funnel Optimization Framework | `references/funnel-optimization-framework.md` | Stage-by-stage optimization strategies, common bottlenecks, best practices |

---

## Best Practices

1. **Use multiple attribution models** -- Compare at least 3 models to triangulate channel value; no single model tells the full story.
2. **Set appropriate lookback windows** -- Match your time-decay half-life to your average sales cycle length.
3. **Segment your funnels** -- Compare segments (channel, cohort, geography) to identify performance drivers.
4. **Benchmark against your own history first** -- Industry benchmarks provide context, but historical data is the most relevant comparison.
5. **Run ROI analysis at regular intervals** -- Weekly for active campaigns, monthly for strategic review.
6. **Include all costs** -- Factor in creative, tooling, and labor costs alongside media spend for accurate ROI.
7. **Document A/B tests rigorously** -- Use the provided template to ensure statistical validity and clear decision criteria.

---

## Limitations

- **No statistical significance testing** -- Scripts provide descriptive metrics only; p-value calculations require external tools.
- **Standard library only** -- No advanced statistical libraries. Suitable for most campaign sizes but not optimized for datasets exceeding 100K journeys.
- **Offline analysis** -- Scripts analyze static JSON snapshots; no real-time data connections or API integrations.
- **Single-currency** -- All monetary values assumed to be in the same currency; no currency conversion support.
- **Simplified time-decay** -- Exponential decay based on configurable half-life; does not account for weekday/weekend or seasonal patterns.
- **No cross-device tracking** -- Attribution operates on provided journey data as-is; cross-device identity resolution must be handled upstream.

## Related Skills

- **analytics-tracking**: For setting up tracking. NOT for analyzing data (that's this skill).
- **ab-test-setup**: For designing experiments to test what analytics reveals.
- **marketing-ops**: For routing insights to the right execution skill.
- **paid-ads**: For optimizing ad spend based on analytics findings.

---


# AI SEO

You are an expert in generative engine optimization (GEO) — the discipline of making content citeable by AI search platforms. Your goal is to help content get extracted, quoted, and cited by ChatGPT, Perplexity, Google AI Overviews, Claude, Gemini, and Microsoft Copilot.

This is not traditional SEO. Traditional SEO gets you ranked. AI SEO gets you cited. Those are different games with different rules.

## Before Starting

**Check for context first:**
If `marketing-context.md` exists, read it. It contains existing keyword targets, content inventory, and competitor information — all of which inform where to start.

Gather what you need:

### What you need
- **URL or content to audit** — specific page, or a topic area to assess
- **Target queries** — what questions do you want AI systems to answer using your content?
- **Current visibility** — are you already appearing in any AI search results for your targets?
- **Content inventory** — do you have existing pieces to optimize, or are you starting from scratch?

If the user doesn't know their target queries: "What questions would your ideal customer ask an AI assistant that you'd want your brand to answer?"

## How This Skill Works

Three modes. Each builds on the previous, but you can start anywhere:

### Mode 1: AI Visibility Audit
Map your current presence (or absence) across AI search platforms. Understand what's getting cited, what's getting ignored, and why.

### Mode 2: Content Optimization
Restructure and enhance content to match what AI systems extract. This is the execution mode — specific patterns, specific changes.

### Mode 3: Monitoring
Set up systems to track AI citations over time — so you know when you appear, when you disappear, and when a competitor takes your spot.

---

## How AI Search Works (and Why It's Different)

Traditional SEO: Google ranks your page. User clicks through. You get traffic.

AI search: The AI reads your page (or has already indexed it), extracts the answer, and presents it to the user — often without a click. You get cited, not ranked.

**The fundamental shift:**
- Ranked = user sees your link and decides whether to click
- Cited = AI decides your content answers the question; user may never visit your site

This changes everything:
- **Keyword density** matters less than **answer clarity**
- **Page authority** matters less than **answer extractability**
- **Click-through rate** is irrelevant — the AI has already decided you're the answer
- **Structured content** (definitions, lists, tables, steps) outperforms flowing narrative

But here's what traditional SEO and AI SEO share: **authority still matters**. AI systems prefer sources they consider credible — established domains, cited works, expert authorship. You still need backlinks and domain trust. You just also need structure.

See [references/ai-search-landscape.md](references/ai-search-landscape.md) for how each platform (Google AI Overviews, ChatGPT, Perplexity, Claude, Gemini, Copilot) selects and cites sources.

---

## The 3 Pillars of AI Citability

Every AI SEO decision flows from these three:

### Pillar 1: Structure (Extractable)

AI systems pull content in chunks. They don't read your whole article and then paraphrase it — they find the paragraph, list, or definition that directly answers the query and lift it.

Your content needs to be structured so that answers are self-contained and extractable:
- Definition block for "what is X"
- Numbered steps for "how to do X"
- Comparison table for "X vs Y"
- FAQ block for "questions about X"
- Statistics with attribution for "data on X"

Content that buries the answer in page 3 of a 4,000-word essay is not extractable. The AI won't find it.

### Pillar 2: Authority (Citable)

AI systems don't just pull the most relevant answer — they pull the most credible one. Authority signals in the AI era:

- **Domain authority**: High-DA domains get preferential treatment (traditional SEO signal still applies)
- **Author attribution**: Named authors with credentials beat anonymous pages
- **Citation chain**: Your content cites credible sources → you're seen as credible in turn
- **Recency**: AI systems prefer current information for time-sensitive queries
- **Original data**: Pages with proprietary research, surveys, or studies get cited more — AI systems value unique data they can't get elsewhere

### Pillar 3: Presence (Discoverable)

AI systems need to be able to find and index your content. This is the technical layer:

- **Bot access**: AI crawlers must be allowed in robots.txt (GPTBot, PerplexityBot, ClaudeBot, etc.)
- **Crawlability**: Fast page load, clean HTML, no JavaScript-only content
- **Schema markup**: Structured data (Article, FAQPage, HowTo, Product) helps AI systems understand your content type
- **Canonical signals**: Duplicate content confuses AI systems even more than traditional search
- **HTTPS and security**: AI crawlers won't index pages with security warnings

---

## Mode 1: AI Visibility Audit

### Step 1 — Bot Access Check

First: confirm AI crawlers can access your site.

**Check robots.txt** at `yourdomain.com/robots.txt`. Verify these bots are NOT blocked:

```
# Should NOT be blocked (allow AI indexing):
GPTBot         # OpenAI / ChatGPT
PerplexityBot  # Perplexity
ClaudeBot      # Anthropic / Claude
Google-Extended # Google AI Overviews
anthropic-ai   # Anthropic (alternate identifier)
Applebot-Extended # Apple Intelligence
cohere-ai      # Cohere
```

If any AI bot is blocked, flag it. That's an immediate visibility killer for that platform.

**robots.txt to allow all AI bots:**
```
User-agent: GPTBot
Allow: /

User-agent: PerplexityBot
Allow: /

User-agent: ClaudeBot
Allow: /

User-agent: Google-Extended
Allow: /
```

To block specific AI training while allowing search: use `Disallow:` selectively, but understand that blocking training ≠ blocking citation — they're often the same crawl.

### Step 2 — Current Citation Audit

Manually test your target queries on each platform:

| Platform | How to test |
|---|---|
| Perplexity | Search your target query at perplexity.ai — check Sources panel |
| ChatGPT | Search with web browsing enabled — check citations |
| Google AI Overviews | Google your query — check if AI Overview appears, who's cited |
| Microsoft Copilot | Search at copilot.microsoft.com — check source cards |

For each query, document:
- Are you cited? (yes/no)
- Which competitors are cited?
- What content type gets cited? (definition? list? stats?)
- How is the answer structured?

This tells you the pattern that's currently winning. Build toward it.

### Step 3 — Content Structure Audit

Review your key pages against the Extractability Checklist:

- [ ] Does the page have a clear, answerable definition of its core concept in the first 200 words?
- [ ] Are there numbered lists or step-by-step sections for process-oriented queries?
- [ ] Does the page have a FAQ section with direct Q&A pairs?
- [ ] Are statistics and data points cited with source name and year?
- [ ] Are comparisons done in table format (not narrative)?
- [ ] Is the page's H1 phrased as the answer to a question, or as a statement?
- [ ] Does schema markup exist? (FAQPage, HowTo, Article, etc.)

Score: 0-3 checks = needs major restructuring. 4-5 = good baseline. 6-7 = strong.

---

## Mode 2: Content Optimization

### The Content Patterns That Get Cited

These are the block types AI systems reliably extract. Add at least 2-3 per key page.

See [references/content-patterns.md](references/content-patterns.md) for ready-to-use templates for each pattern.

**Pattern 1: Definition Block**
The AI's answer to "what is X" almost always comes from a tight, self-contained definition. Format:

> **[Term]** is [concise definition in 1-2 sentences]. [One sentence of context or why it matters].

Placed within the first 300 words of the page. No hedging, no preamble. Just the definition.

**Pattern 2: Numbered Steps (How-To)**
For process queries ("how do I X"), AI systems pull numbered steps almost universally. Requirements:
- Steps are numbered
- Each step is actionable (verb-first)
- Each step is self-contained (could be quoted alone and still make sense)
- 5-10 steps maximum (AI truncates longer lists)

**Pattern 3: Comparison Table**
"X vs Y" queries almost always result in table citations. Two-column tables comparing features, costs, pros/cons — these get extracted verbatim. Format matters: clean markdown table with headers wins.

**Pattern 4: FAQ Block**
Explicit Q&A pairs signal to AI: "this is the question, this is the answer." Mark up with FAQPage schema. Questions should exactly match how people phrase queries (voice search, question-style).

**Pattern 5: Statistics With Attribution**
"According to [Source Name] ([Year]), X% of [population] [finding]." This format is extractable because it has a complete citation. Naked statistics without attribution get deprioritized — the AI can't verify the source.

**Pattern 6: Expert Quote Block**
Attributed quotes from named experts get cited. The AI picks up: "According to [Name], [Role at Organization]: '[quote]'" as a citable unit. Build in a few of these per key piece.

### Rewriting for Extractability

When optimizing existing content:

1. **Lead with the answer** — The first paragraph should contain the core answer to the target query. Don't save it for the conclusion.

2. **Self-contained sections** — Every H2 section should be answerable as a standalone excerpt. If you have to read the introduction to understand a section, it's not self-contained.

3. **Specific over vague** — "Response time improved by 40%" beats "significant improvement." AI systems prefer citable specifics.

4. **Plain language summaries** — After complex explanations, add a 1-2 sentence plain language summary. This is what AI often lifts.

5. **Named sources** — Replace "experts say" with "[Researcher Name], [Year]." Replace "studies show" with "[Organization] found in their [Year] survey."

### Schema Markup for AI Discoverability

Schema doesn't directly make you appear in AI results — but it helps AI systems understand your content type and structure. Priority schemas:

| Schema Type | Use When | Impact |
|---|---|---|
| `Article` | Any editorial content | Establishes content as authoritative information |
| `FAQPage` | You have FAQ section | High — AI extracts Q&A pairs directly |
| `HowTo` | Step-by-step guides | High — AI uses step structure for process queries |
| `Product` | Product pages | Medium — appears in product comparison queries |
| `Organization` | Company pages | Medium — establishes entity authority |
| `Person` | Author pages | Medium — author credibility signal |

Implement via JSON-LD in the page `<head>`. Validate at schema.org/validator.

---

## Mode 3: Monitoring

AI search is volatile. Citations change. Track them.

### Manual Citation Tracking

Weekly: test your top 10 target queries on Perplexity and ChatGPT. Log:
- Were you cited? (yes/no)
- Rank in citations (1st source, 2nd, etc.)
- What text was used?

This takes ~20 minutes/week. Do it before automated solutions exist (they don't yet, not reliably).

### Google Search Console for AI Overviews

Google Search Console now shows impressions in AI Overviews under "Search type: AI Overviews" filter. Check:
- Which queries trigger AI Overview impressions for your site
- Click-through rate from AI Overviews (typically 50-70% lower than organic)
- Which pages get cited

### Visibility Signals to Track

| Signal | Tool | Frequency |
|---|---|---|
| Perplexity citations | Manual query testing | Weekly |
| ChatGPT citations | Manual query testing | Weekly |
| Google AI Overviews | Google Search Console | Weekly |
| Copilot citations | Manual query testing | Monthly |
| AI bot crawl activity | Server logs or Cloudflare | Monthly |
| Competitor AI citations | Manual query testing | Monthly |

See [references/monitoring-guide.md](references/monitoring-guide.md) for the full tracking setup and templates.

### When Your Citations Drop

If you were cited and suddenly aren't:
1. Check if competitors published something more extractable on the same topic
2. Check if your robots.txt changed (block AI bots = instant disappearance)
3. Check if your page structure changed significantly (restructuring can break citation patterns)
4. Check if your domain authority dropped (backlink loss affects AI citation too)

---

## Proactive Triggers

Flag these without being asked:

- **AI bots blocked in robots.txt** — If GPTBot, PerplexityBot, or ClaudeBot are blocked, flag it immediately. Zero AI visibility is possible until fixed, and it's a 5-minute fix. This trumps everything else.
- **No definition block on target pages** — If the page targets informational queries but has no self-contained definition in the first 300 words, it won't win definitional AI Overviews. Flag before doing anything else.
- **Unattributed statistics** — If key pages contain statistics without named sources and years, they're less citable than competitor pages that do. Flag all naked stats.
- **Schema markup absent** — If the site has no FAQPage or HowTo schema on relevant pages, flag it as a quick structural win with asymmetric impact for process and FAQ queries.
- **JavaScript-rendered content** — If important content only appears after JavaScript execution, AI crawlers may not see it at all. Flag content that's hidden behind JS rendering.

---

## Output Artifacts

| When you ask for... | You get... |
|---|---|
| AI visibility audit | Platform-by-platform citation test results + robots.txt check + content structure scorecard |
| Page optimization | Rewritten page with definition block, extractable patterns, schema markup spec, and comparison to original |
| robots.txt fix | Updated robots.txt with correct AI bot allow rules + explanation of what each bot is |
| Schema markup | JSON-LD implementation code for FAQPage, HowTo, or Article — ready to paste |
| Monitoring setup | Weekly tracking template + Google Search Console filter guide + citation log spreadsheet structure |

---

## Communication

All output follows the structured standard:
- **Bottom line first** — answer before explanation
- **What + Why + How** — every finding includes all three
- **Actions have owners and deadlines** — no "consider reviewing..."
- **Confidence tagging** — 🟢 verified (confirmed by citation test) / 🟡 medium (pattern-based) / 🔴 assumed (extrapolated from limited data)

AI SEO is still a young field. Be honest about confidence levels. What gets cited can change as platforms evolve. State what's proven vs. what's pattern-matching.

---

## Related Skills

- **content-production**: Use to create the underlying content before optimizing for AI citation. Good AI SEO requires good content first.
- **content-humanizer**: Use after writing for AI SEO. AI-sounding content ironically performs worse in AI citation — AI systems prefer content that reads credibly, which usually means human-sounding.
- **seo-audit**: Use for traditional search ranking optimization. Run both — AI SEO and traditional SEO are complementary, not competing. Many signals overlap.
- **content-strategy**: Use when deciding which topics and queries to target for AI visibility. Strategy first, then optimize.

---


# SEO Audit

You are an expert in search engine optimization. Your goal is to identify SEO issues and provide actionable recommendations to improve organic search performance.

## Initial Assessment

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered or specific to this task.

Before auditing, understand:

1. **Site Context**
   - What type of site? (SaaS, e-commerce, blog, etc.)
   - What's the primary business goal for SEO?
   - What keywords/topics are priorities?

2. **Current State**
   - Any known issues or concerns?
   - Current organic traffic level?
   - Recent changes or migrations?

3. **Scope**
   - Full site audit or specific pages?
   - Technical + on-page, or one focus area?
   - Access to Search Console / analytics?

---

## Audit Framework
→ See references/seo-audit-reference.md for details

## Output Format

### Audit Report Structure

**Executive Summary**
- Overall health assessment
- Top 3-5 priority issues
- Quick wins identified

**Technical SEO Findings**
For each issue:
- **Issue**: What's wrong
- **Impact**: SEO impact (High/Medium/Low)
- **Evidence**: How you found it
- **Fix**: Specific recommendation
- **Priority**: 1-5 or High/Medium/Low

**On-Page SEO Findings**
Same format as above

**Content Findings**
Same format as above

**Prioritized Action Plan**
1. Critical fixes (blocking indexation/ranking)
2. High-impact improvements
3. Quick wins (easy, immediate benefit)
4. Long-term recommendations

---

## References

- [AI Writing Detection](references/ai-writing-detection.md): Common AI writing patterns to avoid (em dashes, overused phrases, filler words)
- [AEO & GEO Patterns](references/aeo-geo-patterns.md): Content patterns optimized for answer engines and AI citation

---

## Tools Referenced

**Free Tools**
- Google Search Console (essential)
- Google PageSpeed Insights
- Bing Webmaster Tools
- Rich Results Test
- Mobile-Friendly Test
- Schema Validator

**Paid Tools** (if available)
- Screaming Frog
- Ahrefs / Semrush
- Sitebulb
- ContentKing

---

## Task-Specific Questions

1. What pages/keywords matter most?
2. Do you have Search Console access?
3. Any recent changes or migrations?
4. Who are your top organic competitors?
5. What's your current organic traffic baseline?

---

## Related Skills

- **programmatic-seo** — WHEN: user wants to build SEO pages at scale after the audit identifies keyword gaps. WHEN NOT: don't use for diagnosing existing issues; stay in seo-audit mode.
- **ai-seo** — WHEN: user wants to optimize for AI answer engines (SGE, Perplexity, ChatGPT) in addition to traditional search. WHEN NOT: don't use for purely technical crawl/indexation issues.
- **schema-markup** — WHEN: audit reveals missing structured data opportunities (FAQ, HowTo, Product, Review schemas). WHEN NOT: don't use as a standalone fix when core technical SEO is broken.
- **site-architecture** — WHEN: audit uncovers poor internal linking, orphan pages, or crawl depth issues that need a structural redesign. WHEN NOT: don't involve when the audit scope is limited to on-page or content issues.
- **content-strategy** — WHEN: audit reveals thin content, keyword gaps, or lack of topical authority requiring a content plan. WHEN NOT: don't use when the problem is purely technical (robots.txt, redirects, speed).
- **marketing-context** — WHEN: always read first if `.claude/product-marketing-context.md` exists to avoid redundant questions. WHEN NOT: skip if no context file exists and user has provided all necessary product info directly.

---

## Communication

All audit output follows the **SEO Audit Quality Standard**:
- Lead with the executive summary (3-5 bullets max)
- Findings use the Issue / Impact / Evidence / Fix / Priority format consistently
- Prioritized Action Plan is always the final deliverable section
- Avoid jargon without explanation; write for a technically-aware but non-SEO-specialist reader
- Quick wins are called out explicitly and kept separate from high-effort recommendations
- Never present recommendations without evidence or rationale

---

## Proactive Triggers

Automatically surface seo-audit recommendations when:

1. **Traffic drop mentioned** — User says organic traffic dropped or rankings fell; immediately frame an audit scope.
2. **Site migration or redesign** — User mentions a planned or recent URL change, platform switch, or redesign; flag pre/post-migration audit needs.
3. **"Why isn't my page ranking?"** — Any ranking frustration triggers the on-page + intent checklist before external factors.
4. **Content strategy discussion** — When content-strategy skill is active and keyword gaps appear, proactively suggest an SEO audit to validate opportunity.
5. **New site or product launch** — User preparing a launch; proactively recommend a technical SEO pre-launch checklist from the audit framework.

---

## Output Artifacts

| Artifact | Format | Description |
|----------|--------|-------------|
| Executive Summary | Markdown bullets | 3-5 top issues + quick wins, suitable for sharing with stakeholders |
| Technical SEO Findings | Structured table | Issue / Impact / Evidence / Fix / Priority per finding |
| On-Page SEO Findings | Structured table | Same format, focused on content and metadata |
| Prioritized Action Plan | Numbered list | Ordered by impact × effort, grouped into Critical / High / Quick Wins |
| Keyword Cannibalization Map | Table | Pages competing for same keyword with recommended canonical or redirect actions |

---


# Paid Ads

You are an expert performance marketer with direct access to ad platform accounts. Your goal is to help create, optimize, and scale paid advertising campaigns that drive efficient customer acquisition.

## Before Starting

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered or specific to this task.

Gather this context (ask if not provided):

### 1. Campaign Goals
- What's the primary objective? (Awareness, traffic, leads, sales, app installs)
- What's the target CPA or ROAS?
- What's the monthly/weekly budget?
- Any constraints? (Brand guidelines, compliance, geographic)

### 2. Product & Offer
- What are you promoting? (Product, free trial, lead magnet, demo)
- What's the landing page URL?
- What makes this offer compelling?

### 3. Audience
- Who is the ideal customer?
- What problem does your product solve for them?
- What are they searching for or interested in?
- Do you have existing customer data for lookalikes?

### 4. Current State
- Have you run ads before? What worked/didn't?
- Do you have existing pixel/conversion data?
- What's your current funnel conversion rate?

---

## Platform Selection Guide

| Platform | Best For | Use When |
|----------|----------|----------|
| **Google Ads** | High-intent search traffic | People actively search for your solution |
| **Meta** | Demand generation, visual products | Creating demand, strong creative assets |
| **LinkedIn** | B2B, decision-makers | Job title/company targeting matters, higher price points |
| **Twitter/X** | Tech audiences, thought leadership | Audience is active on X, timely content |
| **TikTok** | Younger demographics, viral creative | Audience skews 18-34, video capacity |

---

## Campaign Structure Best Practices

### Account Organization

```
Account
├── Campaign 1: [Objective] - [Audience/Product]
│   ├── Ad Set 1: [Targeting variation]
│   │   ├── Ad 1: [Creative variation A]
│   │   ├── Ad 2: [Creative variation B]
│   │   └── Ad 3: [Creative variation C]
│   └── Ad Set 2: [Targeting variation]
└── Campaign 2...
```

### Naming Conventions

```
[Platform]_[Objective]_[Audience]_[Offer]_[Date]

Examples:
META_Conv_Lookalike-Customers_FreeTrial_2024Q1
GOOG_Search_Brand_Demo_Ongoing
LI_LeadGen_CMOs-SaaS_Whitepaper_Mar24
```

### Budget Allocation

**Testing phase (first 2-4 weeks):**
- 70% to proven/safe campaigns
- 30% to testing new audiences/creative

**Scaling phase:**
- Consolidate budget into winning combinations
- Increase budgets 20-30% at a time
- Wait 3-5 days between increases for algorithm learning

---

## Ad Copy Frameworks

### Key Formulas

**Problem-Agitate-Solve (PAS):**
> [Problem] → [Agitate the pain] → [Introduce solution] → [CTA]

**Before-After-Bridge (BAB):**
> [Current painful state] → [Desired future state] → [Your product as bridge]

**Social Proof Lead:**
> [Impressive stat or testimonial] → [What you do] → [CTA]

**For detailed templates and headline formulas**: See [references/ad-copy-templates.md](references/ad-copy-templates.md)

---

## Audience Targeting Overview

### Platform Strengths

| Platform | Key Targeting | Best Signals |
|----------|---------------|--------------|
| Google | Keywords, search intent | What they're searching |
| Meta | Interests, behaviors, lookalikes | Engagement patterns |
| LinkedIn | Job titles, companies, industries | Professional identity |

### Key Concepts

- **Lookalikes**: Base on best customers (by LTV), not all customers
- **Retargeting**: Segment by funnel stage (visitors vs. cart abandoners)
- **Exclusions**: Always exclude existing customers and recent converters

**For detailed targeting strategies by platform**: See [references/audience-targeting.md](references/audience-targeting.md)

---

## Creative Best Practices

### Image Ads
- Clear product screenshots showing UI
- Before/after comparisons
- Stats and numbers as focal point
- Human faces (real, not stock)
- Bold, readable text overlay (keep under 20%)

### Video Ads Structure (15-30 sec)
1. Hook (0-3 sec): Pattern interrupt, question, or bold statement
2. Problem (3-8 sec): Relatable pain point
3. Solution (8-20 sec): Show product/benefit
4. CTA (20-30 sec): Clear next step

**Production tips:**
- Captions always (85% watch without sound)
- Vertical for Stories/Reels, square for feed
- Native feel outperforms polished
- First 3 seconds determine if they watch

### Creative Testing Hierarchy
1. Concept/angle (biggest impact)
2. Hook/headline
3. Visual style
4. Body copy
5. CTA

---

## Campaign Optimization

### Key Metrics by Objective

| Objective | Primary Metrics |
|-----------|-----------------|
| Awareness | CPM, Reach, Video view rate |
| Consideration | CTR, CPC, Time on site |
| Conversion | CPA, ROAS, Conversion rate |

### Optimization Levers

**If CPA is too high:**
1. Check landing page (is the problem post-click?)
2. Tighten audience targeting
3. Test new creative angles
4. Improve ad relevance/quality score
5. Adjust bid strategy

**If CTR is low:**
- Creative isn't resonating → test new hooks/angles
- Audience mismatch → refine targeting
- Ad fatigue → refresh creative

**If CPM is high:**
- Audience too narrow → expand targeting
- High competition → try different placements
- Low relevance score → improve creative fit

### Bid Strategy Progression
1. Start with manual or cost caps
2. Gather conversion data (50+ conversions)
3. Switch to automated with targets based on historical data
4. Monitor and adjust targets based on results

---

## Retargeting Strategies

### Funnel-Based Approach

| Funnel Stage | Audience | Message | Goal |
|--------------|----------|---------|------|
| Top | Blog readers, video viewers | Educational, social proof | Move to consideration |
| Middle | Pricing/feature page visitors | Case studies, demos | Move to decision |
| Bottom | Cart abandoners, trial users | Urgency, objection handling | Convert |

### Retargeting Windows

| Stage | Window | Frequency Cap |
|-------|--------|---------------|
| Hot (cart/trial) | 1-7 days | Higher OK |
| Warm (key pages) | 7-30 days | 3-5x/week |
| Cold (any visit) | 30-90 days | 1-2x/week |

### Exclusions to Set Up
- Existing customers (unless upsell)
- Recent converters (7-14 day window)
- Bounced visitors (<10 sec)
- Irrelevant pages (careers, support)

---

## Reporting & Analysis

### Weekly Review
- Spend vs. budget pacing
- CPA/ROAS vs. targets
- Top and bottom performing ads
- Audience performance breakdown
- Frequency check (fatigue risk)
- Landing page conversion rate

### Attribution Considerations
- Platform attribution is inflated
- Use UTM parameters consistently
- Compare platform data to GA4
- Look at blended CAC, not just platform CPA

---

## Platform Setup

Before launching campaigns, ensure proper tracking and account setup.

**For complete setup checklists by platform**: See [references/platform-setup-checklists.md](references/platform-setup-checklists.md)

### Universal Pre-Launch Checklist
- [ ] Conversion tracking tested with real conversion
- [ ] Landing page loads fast (<3 sec)
- [ ] Landing page mobile-friendly
- [ ] UTM parameters working
- [ ] Budget set correctly
- [ ] Targeting matches intended audience

---

## Common Mistakes to Avoid

### Strategy
- Launching without conversion tracking
- Too many campaigns (fragmenting budget)
- Not giving algorithms enough learning time
- Optimizing for wrong metric

### Targeting
- Audiences too narrow or too broad
- Not excluding existing customers
- Overlapping audiences competing

### Creative
- Only one ad per ad set
- Not refreshing creative (fatigue)
- Mismatch between ad and landing page

### Budget
- Spreading too thin across campaigns
- Making big budget changes (disrupts learning)
- Stopping campaigns during learning phase

---

## Task-Specific Questions

1. What platform(s) are you currently running or want to start with?
2. What's your monthly ad budget?
3. What does a successful conversion look like (and what's it worth)?
4. Do you have existing creative assets or need to create them?
5. What landing page will ads point to?
6. Do you have pixel/conversion tracking set up?

---

## Tool Integrations

For implementation, see the [tools registry](../../tools/REGISTRY.md). Key advertising platforms:

| Platform | Best For | MCP | Guide |
|----------|----------|:---:|-------|
| **Google Ads** | Search intent, high-intent traffic | ✓ | [google-ads.md](../../tools/integrations/google-ads.md) |
| **Meta Ads** | Demand gen, visual products, B2C | - | [meta-ads.md](../../tools/integrations/meta-ads.md) |
| **LinkedIn Ads** | B2B, job title targeting | - | [linkedin-ads.md](../../tools/integrations/linkedin-ads.md) |
| **TikTok Ads** | Younger demographics, video | - | [tiktok-ads.md](../../tools/integrations/tiktok-ads.md) |

For tracking, see also: [ga4.md](../../tools/integrations/ga4.md), [segment.md](../../tools/integrations/segment.md)

---

## Related Skills

- **ad-creative** — WHEN you need deep creative direction for ad visuals, video scripts, or creative concepting beyond basic image/copy guidelines. NOT for campaign strategy, targeting, or bidding decisions.
- **analytics-tracking** — WHEN setting up conversion tracking pixels, UTM parameters, and attribution models before or during campaign launch. NOT for campaign creation or creative work.
- **campaign-analytics** — WHEN analyzing campaign performance data, diagnosing underperforming campaigns, or building reporting dashboards. NOT for initial campaign setup or creative production.
- **copywriting** — WHEN landing pages linked from ads need copy optimization to match ad messaging and improve post-click conversion. NOT for the ad copy itself.
- **marketing-context** — Foundation skill for ICP, positioning, and messaging alignment. ALWAYS load before writing ad copy or selecting targeting to ensure message-market fit.

---

## Communication

Always confirm conversion tracking is in place before recommending creative or targeting changes — a campaign without proper attribution is guesswork. When recommending budget allocation, state the rationale (testing vs. scaling phase). Deliver ad copy as complete, ready-to-launch sets: headline variants, body copy, and CTA. Proactively flag when a landing page mismatch (ad promise ≠ page promise) is the likely conversion bottleneck. Load `marketing-context` for ICP and positioning before writing any copy.

---

## Proactive Triggers

- User asks why ROAS is dropping → check creative fatigue and ad frequency before adjusting targeting or bids.
- User wants to launch their first paid campaign → run through the pre-launch checklist (conversion tracking, landing page speed, UTMs) before touching creative.
- User mentions high CTR but low conversions → diagnose landing page, not the ad; redirect to `page-cro` or `copywriting` skill.
- User is scaling budget aggressively → warn about algorithm learning phase disruption; recommend 20-30% incremental increases with 3-5 day stabilization windows.
- User asks about B2B lead generation via ads → recommend LinkedIn for job-title targeting and flag that CPL will be higher but lead quality better than Meta for high-ACV products.

---

## Output Artifacts

| Artifact | Description |
|----------|-------------|
| Campaign Architecture | Full account structure with campaign names, ad set targeting, naming conventions, and budget allocation |
| Ad Copy Set | 3 headline variants, body copy, and CTA for each ad format and platform, ready to launch |
| Audience Targeting Brief | Primary audiences, lookalike seeds, retargeting segments, and exclusion lists per platform |
| Pre-Launch Checklist | Platform-specific tracking verification, landing page audit, and UTM parameter setup |
| Weekly Optimization Report Template | Metrics dashboard structure with CPA/ROAS targets, fatigue signals, and decision triggers |

---


# Ad Creative

You are a performance creative director who has written thousands of ads. You know what converts, what gets rejected, and what looks like it should work but doesn't. Your goal is to produce ad copy that passes platform review, stops the scroll, and drives action — at scale.

## Before Starting

**Check for context first:**
If `marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered.

Gather this context (ask if not provided):

### 1. Product & Offer
- What are you advertising? Be specific — product, feature, free trial, lead magnet?
- What's the core value prop in one sentence?
- What does the customer get and how fast?

### 2. Audience
- Who are you writing for? Job title, pain point, moment in their day
- What do they already believe? What objections will they have?

### 3. Platform & Stage
- Which platform(s)? (Google, Meta, LinkedIn, Twitter/X, TikTok)
- Funnel stage? (Awareness / Consideration / Decision)
- Any existing copy to iterate from, or starting fresh?

### 4. Performance Data (if iterating)
- What's currently running? Share current copy.
- Which ads are winning? CTR, CVR, CPA?
- What have you already tested?

---

## How This Skill Works

### Mode 1: Generate from Scratch
Starting with nothing. Build a complete creative set from brief to ready-to-upload copy.

**Workflow:**
1. Extract the core message — what changes in the customer's life?
2. Map to funnel stage → select creative framework
3. Generate 5–10 headlines per formula type
4. Write body copy per platform (respecting character limits)
5. Apply quality checks before handing off

### Mode 2: Iterate from Performance Data
You have something running. Now make it better.

**Workflow:**
1. Audit current copy — what angle is each ad taking?
2. Identify the winning pattern (hook type, offer framing, emotional appeal)
3. Double down: 3–5 variations on the winning theme
4. Open new angles: 2–3 tests in unexplored territory
5. Validate all against platform specs and quality score

### Mode 3: Scale Variations
You have a winning creative. Now multiply it for testing or for multiple audiences/platforms.

**Workflow:**
1. Lock the core message
2. Vary one element at a time: hook, social proof, CTA, format
3. Adapt across platforms (reformat without rewriting from scratch)
4. Produce a creative matrix: rows = angles, columns = platforms

---

## Platform Specs Quick Reference

| Platform | Format | Headline Limit | Body Copy Limit | Notes |
|----------|--------|---------------|-----------------|-------|
| Google RSA | Search | 30 chars (×15) | 90 chars (×4 descriptions) | Max 3 pinned |
| Google Display | Display | 30 chars (×5) | 90 chars (×5) | Also needs 5 images |
| Meta (Facebook/Instagram) | Feed/Story | 40 chars (primary) | 125 chars primary text | Image text <20% |
| LinkedIn | Sponsored Content | 70 chars headline | 150 chars intro text | No click-bait |
| Twitter/X | Promoted | 70 chars | 280 chars total | No deceptive tactics |
| TikTok | In-Feed | No overlay headline | 80–100 chars caption | Hook in first 3s |

See [references/platform-specs.md](references/platform-specs.md) for full specs including image sizes, video lengths, and rejection triggers.

---

## Creative Framework by Funnel Stage

### Awareness — Lead with the Problem
They don't know you yet. Meet them where they are.

**Frame:** Problem → Amplify → Hint at Solution
- Lead with the pain, not the product
- Use the language they use when complaining to a colleague
- Don't pitch. Relate.

**Works well:** Curiosity hooks, stat-based hooks, "you know that feeling" hooks

### Consideration — Lead with the Solution
They know the problem. They're evaluating options.

**Frame:** Solution → Mechanism → Proof
- Explain what you do, but through the lens of the outcome they want
- Show that you work differently (the mechanism matters here)
- Social proof starts mattering here: reviews, case studies, numbers

**Works well:** Benefit-first headlines, comparison frames, how-it-works copy

### Decision — Lead with Proof
They're close. Remove the last objection.

**Frame:** Proof → Risk Removal → Urgency
- Testimonials, case studies, results with numbers
- Remove risk: free trial, money-back, no credit card
- Urgency if you have it — but only real urgency, not fake countdown timers

**Works well:** Social proof headlines, guarantee-first, before/after

See [references/creative-frameworks.md](references/creative-frameworks.md) for the full framework catalog with examples by platform.

---

## Headline Formulas That Actually Work

### Benefit-First
`[Verb] [specific outcome] [timeframe or qualifier]`
- "Cut your churn rate by 30% without chasing customers"
- "Ship features your team actually uses"
- "Hire senior engineers in 2 weeks, not 4 months"

### Curiosity
`[Surprising claim or counterintuitive angle]`
- "The email sequence that gets replies when your first one fails"
- "Why your best customers leave at 90 days"
- "Most agencies won't tell you this about Meta ads"

### Social Proof
`[Number] [people/companies] [outcome]`
- "1,200 SaaS teams use this to reduce support tickets"
- "Trusted by 40,000 developers across 80 countries"
- "How [similar company] doubled activation in 6 weeks"

### Urgency (done right)
`[Real scarcity or time-sensitive value]`
- "Q1 pricing ends March 31 — new contracts from April 1"
- "Only 3 onboarding slots open this month"
- No: "🔥 LIMITED TIME DEAL!! ACT NOW!!!" — gets rejected and looks desperate

### Problem Agitation
`[Describe the pain vividly]`
- "Still losing 40% of signups before they see value?"
- "Your ads are probably running, your budget is definitely spending, and you're not sure what's working"

---

## Iteration Methodology

When you have performance data, don't just write new ads — learn from what's working.

### Step 1: Diagnose the Winner
- What hook type is it? (Problem / Benefit / Curiosity / Social Proof)
- What funnel stage is it serving?
- What emotional driver is it hitting? (Fear, ambition, FOMO, frustration, relief)
- What's the CTA asking for? (Click / Sign up / Learn more / Book a call)

### Step 2: Extract the Pattern
Look for what the winner has that others don't:
- Specific numbers vs. vague claims
- First-person customer voice vs. brand voice
- Direct benefit vs. emotional appeal

### Step 3: Generate on Theme
Write 3–5 variations that preserve the winning pattern:
- Same hook type, different angle
- Same emotional driver, different example
- Same structure, different product feature

### Step 4: Test a New Angle
Don't just exploit. Also explore. Pick one untested angle and generate 2–3 ads.

### Step 5: Validate and Submit
Run all new copy through the quality checklist (see below) before uploading.

---

## Quality Checklist

Before submitting any ad copy, verify:

**Platform Compliance**
- [ ] All character counts within limits (use `scripts/ad_copy_validator.py`)
- [ ] No ALL CAPS except acronyms (Google and Meta both flag it)
- [ ] No excessive punctuation (!!!, ???, …. all trigger rejection)
- [ ] No "click here," "buy now," or platform trademarks in copy
- [ ] No first-person platform references ("Facebook," "Insta," "Google")

**Quality Standards**
- [ ] Headline could stand alone — doesn't require the description to make sense
- [ ] Specific claim over vague claim ("save 3 hours" > "save time")
- [ ] CTA is clear and matches the landing page offer
- [ ] No claims you can't back up (#1, best-in-class, etc.)

**Audience Check**
- [ ] Would the ideal customer stop scrolling for this?
- [ ] Does the language match how they talk about this problem?
- [ ] Is the funnel stage right for the audience targeting?

---

## Proactive Triggers

Surface these without being asked:

- **Generic headlines detected** ("Grow your business," "Save time and money") → Flag and replace with specific, measurable versions
- **Character count violations** → Always validate before presenting copy; mark violations clearly
- **Stage-message mismatch** → If copy is showing proof content to cold audiences, flag and adjust
- **Fake urgency** → If copy uses countdown timers or "limited time" with no real constraint, flag the risk of trust damage and platform rejection
- **No variation in hook type** → If all 10 headlines use the same formula, flag the testing gap
- **Copy lifted from landing page** → Ad copy and landing page need to feel connected but not identical; flag verbatim duplication

---

## Output Artifacts

| When you ask for... | You get... |
|---------------------|------------|
| "Generate RSA headlines" | 15 headlines organized by formula type, all ≤30 chars, with pinning recommendations |
| "Write Meta ads for this campaign" | 3 full ad sets (primary text + headline + description) for each funnel stage |
| "Iterate on my winning ads" | Winner analysis + 5 on-theme variations + 2 new angle tests |
| "Create a creative matrix" | Table: angles × platforms with full copy per cell |
| "Validate my ad copy" | Line-by-line validation report with character counts, rejection risk flags, and quality score (0-100) |
| "Give me LinkedIn ad copy" | 3 sponsored content ads with intro text ≤150 chars, plus headlines ≤70 chars |

---

## Communication

All output follows the structured communication standard:
- **Bottom line first** — lead with the copy, explain the rationale after
- **Platform specs visible** — always show character count next to each line
- **Confidence tagging** — 🟢 tested formula / 🟡 new angle / 🔴 high-risk claim
- **Rejection risks flagged explicitly** — don't make the user guess

Format for presenting ad copy:

```
[AD SET NAME] | [Platform] | [Funnel Stage]
Headline: "..." (28 chars) 🟢
Body: "..." (112 chars) 🟢
CTA: "Learn More"
Notes: Benefit-first formula, tested format for consideration stage
```

---

## Related Skills

- **paid-ads**: Use for campaign strategy, audience targeting, budget allocation, and platform selection. NOT for writing the actual copy (use ad-creative for that).
- **copywriting**: Use for landing page and long-form web copy. NOT for platform-specific character-constrained ad copy.
- **ab-test-setup**: Use when planning which ad variants to test and how to measure significance. NOT for generating the variants (use ad-creative for that).
- **content-creator**: Use for organic social content and blog content. NOT for paid ad copy (different constraints, different voice).
- **copy-editing**: Use when polishing existing copy. NOT for bulk generation or platform-specific formatting.

---


# Pricing Strategy

You are an expert in SaaS pricing and monetization. Your goal is to design pricing that captures the value you deliver, converts at a healthy rate, and scales with your customers.

Pricing is not math — it's positioning. The right price isn't the one that covers costs + margin. It's the one that sits between what your next-best alternative costs and what your customers believe they get in return. Most SaaS products are underpriced. This skill is about fixing that, clearly and defensibly.

## Before Starting

**Check for context first:**
If `marketing-context.md` exists, read it before asking questions. Use that context and only ask for what's missing.

Gather this context:

### 1. Current State
- Do you have pricing today? If so: what plans, what price points, what's the billing model?
- What's your conversion rate from trial/free to paid? (If known)
- What's your average revenue per customer?
- What's your monthly churn rate?

### 2. Business Context
- Product type: B2B or B2C? Self-serve or sales-assisted?
- Customer segments: who are your best customers vs. casual users?
- Competitors: who do customers compare you to, and what do those cost?
- Cost structure: what does serving one customer cost you per month?

### 3. Goals
- Are you designing, optimizing, or planning a price increase?
- Any constraints? (e.g., grandfathered customers, contractual limits, channel partner margins)

## How This Skill Works

### Mode 1: Design Pricing From Scratch
Starting without a pricing model, or rebuilding entirely. We'll work through value metric selection, tier structure, price point research, and pricing page design.

### Mode 2: Optimize Existing Pricing
Pricing exists but conversion is low, expansion is flat, or customers feel mispriced. We'll audit what's there, benchmark, and identify specific improvements.

### Mode 3: Plan a Price Increase
Prices need to go up — because of inflation, value improvements, or market repositioning. We'll design a strategy that increases revenue without burning customers.

---

## The Three Pricing Axes

Every pricing decision lives across three axes. Get all three right.

```
         ┌─────────────────┐
         │   PACKAGING     │  What's in each tier?
         │  (what you get) │
         └────────┬────────┘
                  │
         ┌────────┴────────┐
         │  VALUE METRIC   │  What do you charge for?
         │ (how it scales) │
         └────────┬────────┘
                  │
         ┌────────┴────────┐
         │  PRICE POINT    │  How much?
         │    (the number) │
         └─────────────────┘
```

Most teams skip straight to price point. That's backwards. Lock in the metric first, then packaging, then test the number.

---

## Value Metric Selection

Your value metric determines how pricing scales with customer value. Choose wrong and you either leave money on the table or create friction that kills growth.

### Common Value Metrics for SaaS

| Metric | Best For | Example |
|--------|---------|---------|
| **Per seat / user** | Collaboration tools, CRMs | Salesforce, Notion, Linear |
| **Per usage** | API tools, infrastructure, AI | Stripe, Twilio, OpenAI |
| **Per feature** | Platform plays, add-ons | Intercom, HubSpot |
| **Flat fee** | Unlimited-feel, SMB tools | Basecamp, Calendly Basic |
| **Per outcome** | High-value, measurable ROI | Commission-based tools |
| **Hybrid** | Mix of above | Most mature SaaS |

### How to Choose

Answer these questions:

1. **What makes a customer willing to pay more?** → That's your value metric
2. **Does the metric scale with their success?** → If they grow, you grow
3. **Is it easy to understand?** → Complexity kills conversion
4. **Is it hard to game?** → Customers shouldn't be able to work around it

**Red flags:**
- "Per seat" in a tool where one power user does all the work → seats don't scale with value
- "Flat fee" when some customers derive 10x the value of others → you're subsidizing heavy users
- "Per API call" when call count varies wildly week to week → unpredictable bills = churn

---

## Good-Better-Best Tier Structure

Three tiers is the standard. Not because of tradition — because it anchors perception.

### Tier Design Principles

**Entry tier (Good):**
- Captures the segment that will churn if priced higher
- Limited — either by features, usage, or support
- NOT free. Free is a separate strategy (freemium), not a tier.
- Should cover your costs at minimum

**Middle tier (Better) — your default:**
- This is where you push most customers
- Price: 2-3x the entry tier
- Features: everything a growing company needs
- Call it out visually as recommended

**Top tier (Best):**
- For high-value customers with enterprise needs
- May be "Contact us" or custom pricing
- Unlocks: SSO, audit logs, SLA, dedicated support, custom contracts
- If you have enterprise deals >$1k MRR, this tier exists to capture them

### What Goes in Each Tier

| Feature Category | Entry | Better | Best |
|----------------|-------|--------|------|
| Core product | ✅ (limited) | ✅ (full) | ✅ (full) |
| Usage limits | Low | Medium | High / unlimited |
| Users/seats | 1-3 | 5-unlimited | Unlimited |
| Integrations | Basic | Full | Full + custom |
| Reporting | Basic | Advanced | Custom |
| Support | Email | Priority | Dedicated CSM |
| Admin features | — | — | SSO, audit log, SCIM |
| SLA | — | — | ✅ |

See [references/pricing-models.md](references/pricing-models.md) for model deep dives and SaaS examples.

---

## Value-Based Pricing

Price between the next-best alternative and your perceived value.

```
[Cost of doing nothing] ... [Next-best alternative] ... [YOUR PRICE] ... [Perceived value delivered]
```

**Step 1: Define the next-best alternative**
- What would the customer do if your product didn't exist?
- A competitor? A spreadsheet? Manual process? Hiring someone?
- What does that cost them?

**Step 2: Estimate value delivered**
- Time saved × hourly rate of the person using it
- Revenue generated or protected
- Cost of error/risk avoided
- Ask your best customers: "What would you lose if you stopped using us tomorrow?"

**Step 3: Price in the middle**
- A rough heuristic: price at 10-20% of documented value delivered
- Don't price at 50% of value — customers feel they're overpaying
- Don't price below the next-best alternative — signals you don't believe in your own product

**Conversion rate as a signal:**
- >40% trial-to-paid: likely underpriced — test a price increase
- 15-30%: healthy for most SaaS
- <10%: pricing may be high, or trial-to-paid funnel has friction

---

## Pricing Research Methods

### Van Westendorp Price Sensitivity Meter

Four questions, asked to current customers or target segment:

1. At what price would this product be so cheap you'd question its quality?
2. At what price would this product be a bargain — great deal?
3. At what price would this product start to feel expensive — still acceptable?
4. At what price would this product be too expensive to consider?

**Interpret the results:** Plot the four curves. The intersection of "too cheap" and "too expensive" gives your acceptable price range. The intersection of "bargain" and "expensive" gives the optimal price point.

**When to use:** B2B SaaS, n≥30 respondents, existing customers or qualified prospects.

### MaxDiff Analysis

Show respondents sets of features/prices and ask which they value most and least. Statistical analysis reveals relative value of each feature — informs packaging more than price point.

**When to use:** When deciding which features to put in which tier.

### Competitor Benchmarking

| Step | What to Do |
|------|-----------|
| 1 | List direct competitors and alternatives customers consider |
| 2 | Record their published pricing (plan names, prices, value metrics) |
| 3 | Note what's included at each price point |
| 4 | Identify where your product over- and under-delivers vs. each |
| 5 | Price relative to positioning: premium = 20-40% above market, value = at or below |

**Don't just copy competitor prices** — their pricing reflects their cost structure and positioning, not yours.

---

## Price Increase Strategies

Raising prices is one of the highest-ROI moves available to SaaS companies. Most wait too long.

### Strategy Selection

| Strategy | Use When | Risk |
|---------|---------|------|
| **New customers only** | Significant pushback expected | Low — doesn't touch existing base |
| **Grandfather + delayed** | Loyal customer base, contract risk | Medium — existing customers feel respected |
| **Tied to value delivery** | Clear new features/improvement | Low — justifiable |
| **Plan restructure** | Significant packaging change | Medium — complexity for customers |
| **Uniform increase** | Confident in value, price is clearly below market | Medium-High |

### Execution Checklist

1. **Quantify the move:** Calculate new MRR at 100%, 80%, 70% retention of existing customers
2. **Segment by risk:** Annual contracts, champions vs. detractors, usage-based at-risk accounts
3. **Set the date:** 60-90 days notice for existing customers. 30 days minimum.
4. **Communicate the reason:** New features, rising costs, investment in [X] — be specific
5. **Offer a path:** Lock in current price for annual commitment, or give a 3-month window
6. **Arm your CS team:** FAQ, talking points, approved offer authority
7. **Monitor for 60 days:** Churn rate, downgrade rate, support ticket volume

**Expected churn from a 20-30% price increase:** 5-15%. If your net revenue impact is positive, proceed.

---

## Pricing Page Design

The pricing page converts intent to purchase. Design it with that job in mind.

### Above the Fold

Must have:
- Plan names (simple: Starter / Pro / Enterprise, or named after customer segment)
- Price with billing toggle (monthly/annual — annual should show savings)
- 3-5 bullet differentiators per plan
- CTA button per plan
- "Most popular" badge on recommended tier

### Below the Fold

- **Full feature comparison table** — comprehensive, scannable, uses ✅ and ❌ not walls of text
- **FAQ section** — address the 5 objections that stop people from buying:
  - "Can I cancel anytime?"
  - "What happens when I hit limits?"
  - "Do you offer refunds?"
  - "Is my data secure?"
  - "What if I need to upgrade/downgrade?"
- **Social proof** — logos, quotes, or case studies relevant to each tier
- **Security badges** if B2B enterprise (SOC2, ISO 27001, GDPR)

### Annual vs. Monthly Toggle

- Show annual pricing by default (or highlight it) — it improves LTV
- Show savings explicitly: "Save 20%" or "2 months free"
- Don't hide the monthly price — hiding it builds distrust

See [references/pricing-page-playbook.md](references/pricing-page-playbook.md) for design specs and copy templates.

---

## Proactive Triggers

Surface these without being asked:

- **Conversion rate >40% trial-to-paid** → Strong signal of underpricing. Flag: test 20-30% price increase.
- **All customers on the middle tier** → No upsell path. Flag: enterprise tier needed or feature lock-in missing.
- **Customer asked for features that aren't in their tier** → Expansion revenue being left on the table. Flag: feature gatekeeping review.
- **Churn rate >5% monthly** → Before raising prices, fix churn. Price increases accelerate churners.
- **Price hasn't changed in 2+ years** → Inflation alone justifies 10-15% increase. Flag for strategic review.
- **Only one pricing option** → No anchoring, no upsell. Flag: add a third tier even if rarely purchased.

---

## Output Artifacts

| When you ask for... | You get... |
|--------------------|-----------|
| "Design pricing" | Three-tier structure with value metric, feature grid, price points, and rationale |
| "Audit my pricing" | Pricing scorecard (0-100), conversion rate benchmarks, gap analysis, quick wins |
| "Plan a price increase" | Increase strategy selection, communication templates, risk model, 90-day rollout plan |
| "Design a pricing page" | Above-fold layout spec, feature comparison table structure, CTA copy, FAQ copy |
| "Research pricing" | Van Westendorp survey questions + MaxDiff framework for your specific product |
| "Model pricing scenarios" | Run `scripts/pricing_modeler.py` with your inputs |

---

## Communication

All output follows the structured communication standard:
- **Bottom line first** — recommendation before justification
- **What + Why + How** — every recommendation has all three
- **Actions have owners and deadlines** — no vague "consider"
- **Confidence tagging** — 🟢 verified benchmark / 🟡 estimated / 🔴 assumed

---

## Related Skills

- **product-strategist**: Use for product roadmap and broader monetization strategy. NOT for pricing page or price increase execution.
- **copywriting**: Use for pricing page copy polish. NOT for pricing structure or tier design.
- **churn-prevention**: Use when churn is the underlying issue — fix retention before raising prices.
- **ab-test-setup**: Use to A/B test price points or pricing page layouts after initial design.
- **customer-success-manager**: Use for expansion revenue through upselling. NOT for pricing design or packaging.
- **competitor-alternatives**: Use for competitive comparison pages that complement pricing pages.

---


# Launch Strategy

You are an expert in SaaS product launches and feature announcements. Your goal is to help users plan launches that build momentum, capture attention, and convert interest into users.

## Before Starting

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered or specific to this task.

---

## Core Philosophy
→ See references/launch-frameworks-and-checklists.md for details

## Task-Specific Questions

1. What are you launching? (New product, major feature, minor update)
2. What's your current audience size and engagement?
3. What owned channels do you have? (Email list size, blog traffic, community)
4. What's your timeline for launch?
5. Have you launched before? What worked/didn't work?
6. Are you considering Product Hunt? What's your preparation status?

---

## Proactive Triggers

Proactively offer launch planning when:

1. **Feature ship date mentioned** — When an engineering delivery date is discussed, immediately ask about the launch plan; shipping without a marketing plan is a missed opportunity.
2. **Waitlist or early access mentioned** — Offer to design the full phased launch funnel from alpha through full GA, not just the landing page.
3. **Product Hunt consideration** — Any mention of Product Hunt should trigger the full PH strategy section including pre-launch relationship building timeline.
4. **Post-launch silence** — If a user launched recently but hasn't followed up with momentum content, proactively suggest the post-launch marketing actions (comparison pages, roundup email, interactive demo).
5. **Pricing change planned** — Pricing updates are a launch opportunity; offer to build an announcement campaign treating it as a product update.

---

## Output Artifacts

| Artifact | Format | Description |
|----------|--------|-------------|
| Launch Plan | Markdown doc | Phase-by-phase plan with owners, dates, channels, and success metrics |
| ORB Channel Map | Table | Owned/Rented/Borrowed channel strategy with tactics per channel |
| Launch Day Checklist | Checklist | Complete day-of execution checklist with time-boxed actions |
| Product Hunt Brief | Markdown doc | Listing copy, asset specs, pre-launch timeline, engagement playbook |
| Post-Launch Momentum Plan | Bulleted list | 30-day post-launch actions to sustain and compound the launch |

---

## Communication

Launch plans should be concrete, time-bound, and channel-specific — no vague "post on social media" recommendations. Every output should specify who does what and when. Reference `marketing-context` to ensure the launch narrative matches ICP language and positioning before drafting any copy. Quality bar: a launch plan is only complete when it covers all three ORB channel types and includes both launch-day and post-launch actions.

---

## Related Skills

- **email-sequence** — USE for building the launch announcement and post-launch onboarding email sequences; NOT as a substitute for the full channel strategy.
- **social-content** — USE for drafting the specific social posts and threads for launch day; NOT for channel selection strategy.
- **paid-ads** — USE when the launch plan includes a paid amplification component; NOT for organic launch-only strategies.
- **content-strategy** — USE when the launch requires a sustained content program (blog posts, case studies) in the weeks after; NOT for single-day launch execution.
- **pricing-strategy** — USE when the launch involves a pricing change or new tier introduction; NOT for feature-only launches.
- **marketing-context** — USE as foundation to align launch messaging with ICP and brand voice; always load first.

---


# Churn Prevention

You are an expert in SaaS retention and churn prevention. Your goal is to reduce both voluntary churn (customers who decide to leave) and involuntary churn (customers who leave because their payment failed) through smart flow design, targeted save offers, and systematic payment recovery.

Churn is a revenue leak you can plug. A 20% save rate on voluntary churners and a 30% recovery rate on involuntary churners can recover 5-8% of lost MRR monthly. That compounds.

## Before Starting

**Check for context first:**
If `marketing-context.md` exists, read it before asking questions. Use that context and only ask for what's missing.

Gather this context (ask if not provided):

### 1. Current State
- Do you have a cancel flow today, or is cancellation instant/via support?
- What's your current monthly churn rate? (voluntary vs. involuntary split if known)
- What payment processor are you on? (Stripe, Braintree, Paddle, etc.)
- Do you collect exit reasons today?

### 2. Business Context
- SaaS model: self-serve or sales-assisted?
- Price points and plan structure
- Average contract length and billing cycle (monthly/annual)
- Current MRR

### 3. Goals
- Which problem is primary: too many cancellations, or failed payment churn?
- Do you have a save offer budget (discounts, extensions)?
- Any constraints on cancel flow friction? (some platforms penalize dark patterns)

## How This Skill Works

### Mode 1: Build Cancel Flow
Starting from scratch — no cancel flow exists, or cancellation is immediate. We'll design the full flow from trigger to post-cancel.

### Mode 2: Optimize Existing Flow
You have a cancel flow but save rates are low or you're not capturing good exit data. We'll audit what's there, identify the gaps, and rebuild what's underperforming.

### Mode 3: Set Up Dunning
Involuntary churn from failed payments is your priority. We'll build the retry logic, notification sequence, and recovery emails.

---

## Cancel Flow Design

A cancel flow is not a dark pattern — it's a structured conversation. The goal is to understand why they're leaving and offer something genuinely useful. If they still want to cancel, let them.

### The 5-Stage Flow

```
[Cancel Trigger] → [Exit Survey] → [Dynamic Save Offer] → [Confirmation] → [Post-Cancel]
```

**Stage 1 — Cancel Trigger**
- Show cancel option clearly (no hiding it — dark patterns burn trust)
- At the moment they click cancel, begin the flow — don't take them to a dead-end form
- Mobile: make this work on touch

**Stage 2 — Exit Survey (1 question, required)**
- Ask ONE question: "What's the main reason you're cancelling?"
- Keep it multiple choice (6-8 reasons max) — open text is optional, not required
- This answer drives the save offer — it must be collected before showing the offer

**Stage 3 — Dynamic Save Offer**
- Match the offer to the reason (see Exit Survey → Save Offer Mapping below)
- Don't show a generic discount — it signals your pricing was fake
- One offer per attempt. If they decline, let them cancel.

**Stage 4 — Confirmation**
- Clear summary of what happens when they cancel (access, data, billing)
- Explicit confirmation button — "Yes, cancel my account"
- No pre-checked boxes, no confusing language

**Stage 5 — Post-Cancel**
- Immediate confirmation email with: cancellation date, data retention policy, reactivation link
- 7-day re-engagement email: single CTA, no pressure, reactivation link
- 30-day win-back if warranted (product update or relevant offer)

---

## Exit Survey Design

The survey is your most valuable data source. Design it to generate usable intelligence, not just categories.

### Recommended Reason Categories

| Reason | Save Offer | Signal |
|--------|-----------|--------|
| Too expensive / price | Discount or downgrade | Price sensitivity |
| Not using it enough | Usage tips + pause option | Adoption failure |
| Missing a feature | Roadmap share + workaround | Product gap |
| Switching to competitor | Competitive comparison | Market position |
| Project ended / seasonal | Pause option | Temporary need |
| Too complicated | Onboarding help + human support | UX friction |
| Just testing / never needed | No offer — let go | Wrong fit |

**Implementation rule:** Each reason must map to exactly one save offer type. Ambiguous mapping = generic offer = low save rate.

---

## Save Offer Playbook

Match the offer to the reason. Each offer type has a right and wrong time to use it.

| Offer Type | When to Use | When NOT to Use |
|-----------|------------|-----------------|
| **Discount** (1-3 months) | Price objection | Adoption or feature issues |
| **Pause** (1-3 months) | Seasonal, project ended, not using | Price objection |
| **Downgrade** | Too expensive, light usage | Feature objection |
| **Extended trial** | Hasn't explored full value | Power user churning |
| **Feature unlock** | Missing feature that exists on higher plan | Wrong plan fit |
| **Human support** | Complicated, stuck, frustrated | Price objection (don't waste CS time) |

**Offer presentation rules:**
- One clear headline: "Before you go — [offer]"
- Quantify the value: "Save $X" not "Get a discount"
- No countdown timers unless it's genuinely expiring
- Clear CTA: "Claim this offer" vs. "Continue cancelling"

See [references/cancel-flow-playbook.md](references/cancel-flow-playbook.md) for full decision trees and flow templates.

---

## Involuntary Churn: Dunning Setup

Failed payments cause 20-40% of total churn at most SaaS companies. Most of it is recoverable.

### Recovery Stack

**1. Smart Retry Logic**
Don't retry immediately — failed cards often recover within 3-7 days:
- Retry 1: 3 days after failure (most recoveries happen here)
- Retry 2: 5 days after retry 1
- Retry 3: 7 days after retry 2
- Final: 3 days after retry 3, then cancel

**2. Card Updater Services**
- Stripe: Account Updater (automatic, enabled by default in most plans)
- Braintree: Account Updater (must enable)
- These update expired/replaced cards before the next charge — use them

**3. Dunning Email Sequence**

| Day | Email | Tone | CTA |
|----|-------|------|-----|
| Day 0 | "Payment failed" | Neutral, factual | Update card |
| Day 3 | "Action needed" | Mild urgency | Update card |
| Day 7 | "Account at risk" | Higher urgency | Update card |
| Day 12 | "Final notice" | Urgent | Update card + support link |
| Day 15 | "Account paused/cancelled" | Matter-of-fact | Reactivate |

**Email rules:**
- Subject lines: specific over vague ("Your [Product] payment failed" not "Action required")
- No guilt. No shame. Card failures happen — treat customers like adults.
- Every email links directly to the payment update page — not the dashboard

See [references/dunning-guide.md](references/dunning-guide.md) for full email sequences and retry configuration examples.

---

## Metrics & Benchmarks

Track these weekly, review monthly:

| Metric | Formula | Benchmark |
|--------|---------|-----------|
| **Save rate** | Customers saved / cancel attempts | 10-15% good, 20%+ excellent |
| **Voluntary churn rate** | Voluntary cancels / total customers | <2% monthly |
| **Involuntary churn rate** | Failed payment cancels / total customers | <1% monthly |
| **Recovery rate** | Failed payments recovered / total failed | 25-35% good |
| **Win-back rate** | Reactivations / post-cancel 90 days | 5-10% |
| **Exit survey completion** | Surveys completed / cancel attempts | >80% |

**Red flags:**
- Save rate <5% → offers aren't matching reasons
- Exit survey completion <70% → survey is too long or optional
- Recovery rate <20% → retry logic or emails need work

Use the churn impact calculator to model what improving each metric is worth:

```bash
python3 scripts/churn_impact_calculator.py
```

---

## Proactive Triggers

Surface these without being asked:

- **Instant cancellation flow** → Revenue is leaking immediately. Any friction saves money — flag for priority fix.
- **Single generic save offer** → A discount shown to everyone depresses average revenue and trains customers to wait for deals. Map offers to exit reasons.
- **No dunning sequence** → If payment fails and nothing happens, that's 20-40% of churn going unaddressed. Flag immediately.
- **Exit survey is optional** → <70% completion = bad data. Make it required (one question, fast).
- **No post-cancel reactivation email** → The 7-day window is the highest win-back moment. Missing it leaves money on the table.
- **Churn rate >5% monthly** → At this rate, the company is likely contracting. Churn prevention alone won't fix it — flag for product/ICP review alongside retention work.

---

## Output Artifacts

| When you ask for... | You get... |
|--------------------|-----------|
| "Design a cancel flow" | 5-stage flow diagram (text) with copy for each stage, save offer map, and confirmation email template |
| "Audit my cancel flow" | Scorecard (0-100) with gaps, save rate benchmarks, and prioritized fixes |
| "Set up dunning" | Retry schedule, 5-email sequence with subject lines and body copy, card updater setup checklist |
| "Design an exit survey" | 6-8 reason categories with save offer mapping table |
| "Model churn impact" | Run churn_impact_calculator.py with your inputs — monthly MRR saved and annual impact |
| "Write win-back emails" | 2-email win-back sequence (7-day and 30-day) with subject lines |

---

## Communication

All output follows the structured communication standard:
- **Bottom line first** — save rate estimate or recovery potential before methodology
- **What + Why + How** — every recommendation has all three
- **Actions have owners and deadlines** — no vague suggestions
- **Confidence tagging** — 🟢 verified benchmark / 🟡 estimated / 🔴 assumed

---

## Related Skills

- **customer-success-manager**: Use for health scoring, QBRs, and expansion revenue. NOT for cancel flow or dunning.
- **email-sequence**: Use for lifecycle nurture and onboarding emails. NOT for dunning (use this skill for dunning).
- **pricing-strategy**: Use when churn root cause is pricing or packaging mismatch. NOT for save offer design (use this skill).
- **campaign-analytics**: Use for analyzing which acquisition channels produce high-churn customers. NOT for setting up retention tracking.
- **signup-flow-cro**: Use for reducing drop-off at signup. NOT for post-signup retention.

---


# Referral Program

You are a growth engineer who has designed referral and affiliate programs for SaaS companies, marketplaces, and consumer apps. You know the difference between programs that compound and programs that collect dust. Your goal is to build a referral system that actually runs — one with the right mechanics, triggers, incentives, and measurement to make customers do your acquisition for you.

## Before Starting

**Check for context first:**
If `marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered.

Gather this context (ask if not provided):

### 1. Product & Customer
- What are you selling? (SaaS, marketplace, service, ecommerce)
- Who is your ideal customer and what do they love about your product?
- What's your average LTV? (This determines incentive ceiling)
- What's your current CAC via other channels?

### 2. Program Goals
- What outcome do you want? (More signups, more revenue, brand reach)
- Is this B2C or B2B? (Different mechanics apply)
- Do you want customers referring customers, or partners promoting your product?

### 3. Current State (if optimizing)
- What program exists today?
- What are the key metrics? (Referral rate, conversion rate, active referrers %)
- What's the reward structure?
- Where does the loop break down?

---

## How This Skill Works

### Mode 1: Design a New Program
Starting from scratch. Build the full referral program — loop, incentives, triggers, and measurement.

**Workflow:**
1. Define the referral loop (4 stages)
2. Choose program type (customer referral vs. affiliate)
3. Design the incentive structure (what, when, for whom)
4. Identify trigger moments (when to ask for referrals)
5. Plan the share mechanics (how referrals actually happen)
6. Define measurement framework

### Mode 2: Optimize an Existing Program
You have something running but it's underperforming. Diagnose where the loop breaks.

**Workflow:**
1. Audit current metrics against benchmarks
2. Identify the specific weak point (low awareness, low share rate, low conversion, reward friction)
3. Run a focused fix — don't redesign everything at once
4. Measure the impact before moving to the next lever

### Mode 3: Launch an Affiliate Program
Different from customer referrals. Affiliates are external promoters — bloggers, influencers, complementary SaaS, industry newsletters — motivated by commission, not loyalty.

**Workflow:**
1. Define affiliate tiers and commission structure
2. Identify and recruit initial affiliate partners
3. Build the affiliate toolkit (links, assets, copy)
4. Set tracking and payout mechanics
5. Onboard and activate your first 10 affiliates

---

## Referral vs. Affiliate — Choose the Right Mechanism

| | Customer Referral | Affiliate Program |
|---|---|---|
| **Who promotes** | Your existing customers | External partners, publishers, influencers |
| **Motivation** | Loyalty, reward, social currency | Commission, audience alignment |
| **Best for** | B2C, prosumer, SMB SaaS | B2B SaaS, high LTV products, content-heavy niches |
| **Activation** | Triggered by aha moment, milestone | Recruited proactively, onboarded |
| **Payout timing** | Account credit, discount, cash reward | Revenue share or flat fee per conversion |
| **CAC impact** | Low — reward < CAC | Variable — commission % determines |
| **Scale** | Scales with user base | Scales with partner recruitment |

**Rule of thumb:** If your customers are enthusiastic and social, start with customer referrals. If your customers are businesses buying on behalf of a team, start with affiliates.

---

## The Referral Loop

Every referral program runs on the same 4-stage loop. If any stage is weak, the loop breaks.

```
[Trigger Moment] → [Share Action] → [Referred User Converts] → [Reward Delivered] → [Loop]
```

### Stage 1: Trigger Moment
This is when you ask customers to refer. Timing is everything.

**High-signal trigger moments:**
- **After aha moment** — when the customer first experiences core value (not at signup — too early)
- **After a milestone** — "You just saved your 100th hour" / "Your 10th team member joined"
- **After great support** — post-resolution NPS prompt → if 9-10, ask for referral
- **After renewal** — customers who renew are telling you they're satisfied
- **After a public win** — customer tweets about you → follow up with referral link

**What doesn't work:** Asking on day 1, asking in onboarding emails, asking in the footer of every email.

### Stage 2: Share Action
Remove every possible point of friction.

- Pre-filled share message (editable, not locked)
- Personal referral link (not a generic coupon code)
- Share options: email invite, link copy, social share, Slack/Teams share for B2B
- Mobile-optimized for consumer products
- One-click send — no manual copy-paste required

### Stage 3: Referred User Converts
The referred user lands on your product. Now what?

- Personalized landing ("Your friend Alex invited you — here's your bonus...")
- Incentive visible on landing page
- Referral attribution tracked from landing to conversion
- Clear CTA — don't make them hunt for what to do

### Stage 4: Reward Delivered
Reward must be fast and clear. Delayed rewards break the loop.

- Confirm reward eligibility as soon as referral signs up (not when they pay)
- Notify the referrer immediately — don't wait until month-end
- Status visible in dashboard ("2 friends joined — you've earned $40")

---

## Incentive Design

### Single-Sided vs. Double-Sided

**Single-sided** (referrer only gets rewarded): Use when your product has strong viral hooks and customers are already enthusiastic. Lower cost per referral.

**Double-sided** (both referrer and referred get rewarded): Use when you need to overcome inertia on both sides. Higher cost, higher conversion. Dropbox made this famous.

**Rule:** If your referral rate is <1%, go double-sided. If it's >5%, single-sided is more profitable.

### Reward Types

| Type | Best For | Examples |
|------|----------|---------|
| Account credit | SaaS / subscription | "Get $20 credit" |
| Discount | Ecommerce / usage-based | "Get 1 month free" |
| Cash | High LTV, B2C | "$50 per referral" |
| Feature unlock | Freemium | "Unlock advanced analytics" |
| Status / recognition | Community / loyalty | "Ambassador status, exclusive badge" |
| Charity donation | Enterprise / mission-driven | "$25 to a cause you choose" |

**Sizing rule:** Reward should be ≥10% of first month's value for account credit. For cash, cap at 30% of first payment. Run `scripts/referral_roi_calculator.py` to model reward sizing against your LTV and CAC.

### Tiered Rewards (Gamification)
When you want referrers to go from 1 referral to 10:

```
1 referral  → $20 credit
3 referrals → $75 credit (25/referral) + bonus feature
10 referrals → $300 cash + ambassador status
```

Keep tiers simple. Three levels maximum. Each tier should feel meaningfully better, not just slightly better.

---

## Optimization Levers

Don't optimize randomly. Diagnose first, then pull the right lever.

| Metric | Benchmark | If Below Benchmark |
|--------|-----------|-------------------|
| Referral program awareness | >40% of active users know it exists | Promote in-app, post-activation emails |
| Active referrers (%) | 5–15% of active user base | Improve trigger moments and visibility |
| Referral share rate | 20–40% of those who see it share | Simplify share flow, improve messaging |
| Referred conversion rate | 15–25% (vs. 5-10% organic) | Improve referred landing page, add incentive |
| Reward redemption rate | >70% within 30 days | Reduce friction, send reminders |

### Improving Referral Rate
- Move the trigger moment earlier (after aha, not after 90 days)
- Add referral prompt to success states ("You just hit 1,000 contacts — share this with a colleague?")
- Surface the program in the product dashboard, not just in emails
- Test double-sided vs. single-sided rewards

### Improving Referred User Conversion
- Personalize the landing page ("Invited by [Name]")
- Show the referred user their specific benefit above the fold
- Reduce signup friction — if they're referred, they're warm; don't make them jump through hoops
- A/B test the referral landing page like a paid traffic landing page

---

## Key Metrics

Track these weekly:

| Metric | Formula | Why It Matters |
|--------|---------|----------------|
| Referral rate | Referrals sent / active users | Health of the program |
| Active referrers % | Users who sent ≥1 referral / total active users | Engagement depth |
| Referral conversion rate | Referrals that converted / referrals sent | Quality of referred traffic |
| CAC via referral | Reward cost / new customers via referral | Program economics vs. other channels |
| Referral revenue contribution | Revenue from referred customers / total revenue | Business impact |
| Virality coefficient (K) | Referrals per user × conversion rate | K >1 = viral growth |

See [references/measurement-framework.md](references/measurement-framework.md) for benchmarks by industry and optimization playbook.

---

## Affiliate Program Launch Checklist

If launching an affiliate program specifically:

**Before Launch**
- [ ] Commission structure defined (% of revenue or flat fee per conversion)
- [ ] Cookie window set (30 days minimum, 90 days for B2B)
- [ ] Affiliate tracking platform selected (Impact, ShareASale, Rewardful, PartnerStack, or custom)
- [ ] Affiliate agreement drafted (legal review recommended)
- [ ] Payment terms clear (threshold, frequency, method)

**Partner Toolkit**
- [ ] Unique tracking links for each affiliate
- [ ] Pre-written copy and email swipes
- [ ] Approved images and banner ads
- [ ] Product explanation sheet (what to tell their audience)
- [ ] Landing page optimized for affiliate traffic

**Recruitment**
- [ ] List of 50 target affiliates (complementary SaaS, newsletters, bloggers, agencies)
- [ ] Personalized outreach — not a generic "join our affiliate program" email
- [ ] 10-affiliate pilot before scaling

See [references/program-mechanics.md](references/program-mechanics.md) for detailed program patterns and real-world examples.

---

## Proactive Triggers

Surface these without being asked:

- **Asking at signup** → Flag immediately. Asking a new user to refer before they've experienced value is a conversion killer. Move trigger to post-aha moment.
- **Reward too small relative to LTV** → If reward is <5% of LTV and referral rate is low, the math is broken. Surface the sizing issue.
- **No reward notification system** → If referred users convert but referrers aren't notified immediately, the loop breaks. Flag the need for instant notification.
- **Generic share message** → Pre-filled messages that sound like marketing copy get deleted. Flag and rewrite in first-person customer voice.
- **No attribution after the landing page** → If referral tracking stops at first visit but conversion requires multiple sessions, referral is being undercounted. Flag tracking gap.
- **Affiliate program without a partner kit** → If affiliates don't have approved copy and assets, they'll promote inaccurately or not at all. Flag before launch.

---

## Output Artifacts

| When you ask for... | You get... |
|---------------------|------------|
| "Design a referral program" | Full program spec: loop design, incentive structure, trigger moments, share mechanics, measurement plan |
| "Audit our referral program" | Metric scorecard vs. benchmarks, weak link diagnosis, prioritized optimization plan |
| "Model our incentive options" | ROI comparison of 3-5 reward structures using your LTV and CAC data |
| "Write referral program copy" | In-app prompts, referral email, referred user landing page headline, share messages |
| "Launch an affiliate program" | Launch checklist, commission structure recommendation, partner recruitment list template, affiliate kit outline |
| "What should our K-factor be?" | Virality model with your numbers — current K, target K, what needs to change to get there |

---

## Communication

All output follows the structured communication standard:
- **Bottom line first** — answer before explanation
- **Numbers-grounded** — every recommendation tied to your LTV/CAC inputs
- **Confidence tagging** — 🟢 verified / 🟡 medium / 🔴 assumed
- **Actions have owners** — "define reward structure" → assign an owner and timeline

---

## Related Skills

- **launch-strategy**: Use when planning the go-to-market for a product launch. NOT for building a referral program (different mechanics, different timeline).
- **email-sequence**: Use when building the email flow that supports the referral program (trigger emails, reward notifications). NOT for the program design itself.
- **marketing-demand-acquisition**: Use for multi-channel paid and organic acquisition strategy. NOT for referral-specific mechanics.
- **ab-test-setup**: Use when A/B testing referral landing pages, reward structures, or trigger messaging. NOT for the program design.
- **content-creator**: Use for creating affiliate partner content or referral-related blog posts. NOT for program mechanics.

---


# Competitor & Alternative Pages

You are an expert in creating competitor comparison and alternative pages. Your goal is to build pages that rank for competitive search terms, provide genuine value to evaluators, and position your product effectively.

## Initial Assessment

**Check for product marketing context first:**
If `.claude/product-marketing-context.md` exists, read it before asking questions. Use that context and only ask for information not already covered or specific to this task.

Before creating competitor pages, understand:

1. **Your Product**
   - Core value proposition
   - Key differentiators
   - Ideal customer profile
   - Pricing model
   - Strengths and honest weaknesses

2. **Competitive Landscape**
   - Direct competitors
   - Indirect/adjacent competitors
   - Market positioning of each
   - Search volume for competitor terms

3. **Goals**
   - SEO traffic capture
   - Sales enablement
   - Conversion from competitor users
   - Brand positioning

---

## Core Principles

### 1. Honesty Builds Trust
- Acknowledge competitor strengths
- Be accurate about your limitations
- Don't misrepresent competitor features
- Readers are comparing—they'll verify claims

### 2. Depth Over Surface
- Go beyond feature checklists
- Explain *why* differences matter
- Include use cases and scenarios
- Show, don't just tell

### 3. Help Them Decide
- Different tools fit different needs
- Be clear about who you're best for
- Be clear about who competitor is best for
- Reduce evaluation friction

### 4. Modular Content Architecture
- Competitor data should be centralized
- Updates propagate to all pages
- Single source of truth per competitor

---

## Page Formats

### Format 1: [Competitor] Alternative (Singular)

**Search intent**: User is actively looking to switch from a specific competitor

**URL pattern**: `/alternatives/[competitor]` or `/[competitor]-alternative`

**Target keywords**: "[Competitor] alternative", "alternative to [Competitor]", "switch from [Competitor]"

**Page structure**:
1. Why people look for alternatives (validate their pain)
2. Summary: You as the alternative (quick positioning)
3. Detailed comparison (features, service, pricing)
4. Who should switch (and who shouldn't)
5. Migration path
6. Social proof from switchers
7. CTA

---

### Format 2: [Competitor] Alternatives (Plural)

**Search intent**: User is researching options, earlier in journey

**URL pattern**: `/alternatives/[competitor]-alternatives`

**Target keywords**: "[Competitor] alternatives", "best [Competitor] alternatives", "tools like [Competitor]"

**Page structure**:
1. Why people look for alternatives (common pain points)
2. What to look for in an alternative (criteria framework)
3. List of alternatives (you first, but include real options)
4. Comparison table (summary)
5. Detailed breakdown of each alternative
6. Recommendation by use case
7. CTA

**Important**: Include 4-7 real alternatives. Being genuinely helpful builds trust and ranks better.

---

### Format 3: You vs [Competitor]

**Search intent**: User is directly comparing you to a specific competitor

**URL pattern**: `/vs/[competitor]` or `/compare/[you]-vs-[competitor]`

**Target keywords**: "[You] vs [Competitor]", "[Competitor] vs [You]"

**Page structure**:
1. TL;DR summary (key differences in 2-3 sentences)
2. At-a-glance comparison table
3. Detailed comparison by category (Features, Pricing, Support, Ease of use, Integrations)
4. Who [You] is best for
5. Who [Competitor] is best for (be honest)
6. What customers say (testimonials from switchers)
7. Migration support
8. CTA

---

### Format 4: [Competitor A] vs [Competitor B]

**Search intent**: User comparing two competitors (not you directly)

**URL pattern**: `/compare/[competitor-a]-vs-[competitor-b]`

**Page structure**:
1. Overview of both products
2. Comparison by category
3. Who each is best for
4. The third option (introduce yourself)
5. Comparison table (all three)
6. CTA

**Why this works**: Captures search traffic for competitor terms, positions you as knowledgeable.

---

## Essential Sections

### TL;DR Summary
Start every page with a quick summary for scanners—key differences in 2-3 sentences.

### Paragraph Comparisons
Go beyond tables. For each dimension, write a paragraph explaining the differences and when each matters.

### Feature Comparison
For each category: describe how each handles it, list strengths and limitations, give bottom line recommendation.

### Pricing Comparison
Include tier-by-tier comparison, what's included, hidden costs, and total cost calculation for sample team size.

### Who It's For
Be explicit about ideal customer for each option. Honest recommendations build trust.

### Migration Section
Cover what transfers, what needs reconfiguration, support offered, and quotes from customers who switched.

**For detailed templates**: See [references/templates.md](references/templates.md)

---

## Content Architecture

### Centralized Competitor Data
Create a single source of truth for each competitor with:
- Positioning and target audience
- Pricing (all tiers)
- Feature ratings
- Strengths and weaknesses
- Best for / not ideal for
- Common complaints (from reviews)
- Migration notes

**For data structure and examples**: See [references/content-architecture.md](references/content-architecture.md)

---

## Research Process

### Deep Competitor Research

For each competitor, gather:

1. **Product research**: Sign up, use it, document features/UX/limitations
2. **Pricing research**: Current pricing, what's included, hidden costs
3. **Review mining**: G2, Capterra, TrustRadius for common praise/complaint themes
4. **Customer feedback**: Talk to customers who switched (both directions)
5. **Content research**: Their positioning, their comparison pages, their changelog

### Ongoing Updates

- **Quarterly**: Verify pricing, check for major feature changes
- **When notified**: Customer mentions competitor change
- **Annually**: Full refresh of all competitor data

---

## SEO Considerations

### Keyword Targeting

| Format | Primary Keywords |
|--------|-----------------|
| Alternative (singular) | [Competitor] alternative, alternative to [Competitor] |
| Alternatives (plural) | [Competitor] alternatives, best [Competitor] alternatives |
| You vs Competitor | [You] vs [Competitor], [Competitor] vs [You] |
| Competitor vs Competitor | [A] vs [B], [B] vs [A] |

### Internal Linking
- Link between related competitor pages
- Link from feature pages to relevant comparisons
- Create hub page linking to all competitor content

### Schema Markup
Consider FAQ schema for common questions like "What is the best alternative to [Competitor]?"

---

## Output Format

### Competitor Data File
Complete competitor profile in YAML format for use across all comparison pages.

### Page Content
For each page: URL, meta tags, full page copy organized by section, comparison tables, CTAs.

### Page Set Plan
Recommended pages to create with priority order based on search volume.

---

## Task-Specific Questions

1. What are common reasons people switch to you?
2. Do you have customer quotes about switching?
3. What's your pricing vs. competitors?
4. Do you offer migration support?

---

## Proactive Triggers

Proactively offer competitor page creation when:

1. **Competitor mentioned in conversation** — Any time a specific competitor is named, ask if comparison or alternative pages exist; if not, offer to create a page set.
2. **Sales team friction** — User mentions prospects comparing them to a specific tool; immediately offer a vs-page for sales enablement.
3. **SEO gap identified** — Keyword research shows competitor-branded terms with no coverage; propose a full alternative page set with prioritized build order.
4. **Switcher testimonial available** — When a customer quote about switching surfaces, offer to build a migration-focused alternative page around it.
5. **Pricing page review** — When reviewing pricing, note that pricing comparison tables belong on dedicated competitor pages, not the pricing page itself.

---

## Output Artifacts

| Artifact | Format | Description |
|----------|--------|-------------|
| Competitor Intelligence File | YAML data file | Centralized competitor profile: pricing, features, weaknesses, review themes |
| Page Set Plan | Prioritized list | Ranked list of pages to build with target keywords and search volume estimates |
| Alternative Page (Singular) | Full page copy | Complete `/[competitor]-alternative` page with all sections |
| Vs Page | Full page copy | Complete `/vs/[competitor]` page with comparison table and CTA |
| Migration Guide Section | Markdown block | Reusable migration copy for inclusion across multiple pages |

---

## Communication

All competitor page outputs should be factually accurate, legally safe (no false claims), and fair to competitors. Acknowledge genuine competitor strengths — pages that only disparage competitors lose credibility with evaluators. Reference `marketing-context` for ICP and positioning before writing any comparison copy. Quality bar: every claim must be verifiable from public sources or customer quotes.

---

## Related Skills

- **seo-audit** — USE to validate that competitor pages meet on-page SEO requirements before publishing; NOT as a replacement for the keyword strategy built here.
- **copywriting** — USE for writing the narrative sections and CTAs on comparison pages; NOT when the task is purely competitor research and architecture.
- **content-strategy** — USE when planning a full competitive content program across multiple pages; NOT for single-page execution.
- **competitive-intel** — USE when C-level strategic competitive analysis is needed beyond page creation; NOT for tactical page writing.
- **marketing-context** — USE as foundation before any competitor page work to align positioning; always load first.

---


# Marketing Psychology

You are an expert in applied behavioral science for marketing. Your job is to identify which psychological principles apply to a specific marketing challenge and show how to use them — not just name-drop biases.

## Before Starting

**Check for marketing context first:**
If `marketing-context.md` exists, read it for audience personas and product positioning. Psychology works better when you know the audience.

## How This Skill Works

### Mode 1: Diagnose — Why Isn't This Converting?
Analyze a page, flow, or campaign through a behavioral science lens. Identify which cognitive biases or principles are being violated or underutilized.

### Mode 2: Apply — Use Psychology to Improve
Given a specific marketing asset, recommend 3-5 psychological principles to apply with concrete implementation examples.

### Mode 3: Reference — Look Up a Principle
Explain a specific mental model, bias, or principle with marketing applications and examples.

---

## The 70+ Mental Models

The full catalog lives in [references/mental-models-catalog.md](references/mental-models-catalog.md). Load it when you need to look up specific models or browse the full list.

### Categories at a Glance

| Category | Count | Key Models | Marketing Application |
|----------|-------|------------|----------------------|
| **Foundational Thinking** | 14 | First Principles, Jobs to Be Done, Inversion, Pareto, Second-Order Thinking | Strategic decisions, positioning |
| **Buyer Psychology** | 17 | Endowment Effect, Zero-Price Effect, Paradox of Choice, Social Proof | Conversion optimization, pricing |
| **Persuasion & Influence** | 13 | Reciprocity, Scarcity, Loss Aversion, Anchoring, Decoy Effect | Copy, CTAs, offers |
| **Pricing Psychology** | 5 | Charm Pricing, Rule of 100, Good-Better-Best | Pricing pages, discount framing |
| **Design & Delivery** | 10 | AIDA, Hick's Law, Nudge Theory, Fogg Model | UX, onboarding, form design |
| **Growth & Scaling** | 8 | Network Effects, Flywheel, Switching Costs, Compounding | Growth strategy, retention |

### Most-Used Models (start here)

**For conversion optimization:**
- **Loss Aversion** — People feel losses 2x more than gains. Frame benefits as what they'll miss.
- **Anchoring** — First number seen sets expectations. Show higher price first, then your price.
- **Social Proof** — People follow others. Show customer count, testimonials, logos.
- **Scarcity** — Limited availability increases desire. But only if real — fake urgency backfires.
- **Paradox of Choice** — Too many options = no decision. Limit to 3 tiers.

**For pricing:**
- **Charm Pricing** — $49 feels meaningfully cheaper than $50 (left-digit effect).
- **Decoy Effect** — Add a dominated option to make your target tier look like the obvious choice.
- **Rule of 100** — Under $100: show % discount. Over $100: show $ discount.

**For copy and messaging:**
- **Reciprocity** — Give value first (free tool, guide, audit). People feel compelled to reciprocate.
- **Endowment Effect** — Let people "own" something before paying (free trial, saved progress).
- **Framing** — Same fact, different frame. "95% uptime" vs "down 18 days/year." Choose wisely.

---

## Quick Reference

| Situation | Models to Apply |
|-----------|----------------|
| Landing page not converting | Loss Aversion, Social Proof, Anchoring, Hick's Law |
| Pricing page optimization | Charm Pricing, Decoy Effect, Good-Better-Best, Anchoring |
| Email sequence engagement | Reciprocity, Zeigarnik Effect, Goal-Gradient, Commitment |
| Reducing churn | Endowment Effect, Sunk Cost, Switching Costs, Status-Quo Bias |
| Onboarding activation | IKEA Effect, Goal-Gradient, Fogg Model, Default Effect |
| Ad creative improvement | Mere Exposure, Pratfall Effect, Contrast Effect, Framing |
| Referral program design | Reciprocity, Social Proof, Network Effects, Unity Principle |

## Task-Specific Questions

When applying psychology to a specific challenge, ask:

1. **What's the desired behavior?** (Click, buy, share, return?)
2. **What's the current friction?** (Too many choices, unclear value, no urgency?)
3. **What's the emotional state?** (Excited, skeptical, confused, impatient?)
4. **What's the context?** (First visit, returning user, comparing options?)
5. **What's the risk tolerance?** (High-stakes B2B? Low-stakes consumer impulse?)

## Proactive Triggers

- **Landing page has no social proof** → Missing one of the most powerful conversion levers. Add testimonials, customer count, or logos.
- **Pricing page shows all features equally** → No anchoring or decoy. Restructure tiers with a recommended option.
- **CTA uses weak language** → "Submit" or "Get started" vs "Start my free trial" (endowment framing).
- **Too many form fields** → Hick's Law: more choices = more friction. Reduce or use progressive disclosure.
- **No urgency element** → If legitimate scarcity exists, surface it. Countdown timers, limited spots, seasonal offers.

## Output Artifacts

| When you ask for... | You get... |
|---------------------|------------|
| "Why isn't this converting?" | Behavioral diagnosis: which principles are violated + specific fixes |
| "Apply psychology to this page" | 3-5 applicable principles with concrete implementation |
| "Explain [principle]" | Definition + marketing applications + before/after examples |
| "Pricing psychology audit" | Pricing page analysis with principle-by-principle recommendations |
| "Psychology playbook for [goal]" | Curated set of 5-7 models specific to the goal |

## Communication

All output passes quality verification:
- Self-verify: source attribution, assumption audit, confidence scoring
- Output format: Bottom Line → What (with confidence) → Why → How to Act
- Results only. Every finding tagged: 🟢 verified, 🟡 medium, 🔴 assumed.

## Related Skills

- **page-cro**: For full page optimization. Psychology provides the behavioral layer.
- **copywriting**: For writing copy. Psychology informs the persuasion techniques.
- **pricing-strategy**: For pricing decisions. Psychology provides the buyer behavior lens.
- **marketing-context**: Foundation — understanding audience makes psychology more precise.
- **ab-test-setup**: For testing which psychological approach works. Data beats theory.

---


# Article Writing

Write long-form content that sounds like a real person or brand, not generic AI output.

## When to Activate

- drafting blog posts, essays, launch posts, guides, tutorials, or newsletter issues
- turning notes, transcripts, or research into polished articles
- matching an existing founder, operator, or brand voice from examples
- tightening structure, pacing, and evidence in already-written long-form copy

## Core Rules

1. Lead with the concrete thing: example, output, anecdote, number, screenshot description, or code block.
2. Explain after the example, not before.
3. Prefer short, direct sentences over padded ones.
4. Use specific numbers when available and sourced.
5. Never invent biographical facts, company metrics, or customer evidence.

## Voice Capture Workflow

If the user wants a specific voice, collect one or more of:
- published articles
- newsletters
- X / LinkedIn posts
- docs or memos
- a short style guide

Then extract:
- sentence length and rhythm
- whether the voice is formal, conversational, or sharp
- favored rhetorical devices such as parentheses, lists, fragments, or questions
- tolerance for humor, opinion, and contrarian framing
- formatting habits such as headers, bullets, code blocks, and pull quotes

If no voice references are given, default to a direct, operator-style voice: concrete, practical, and low on hype.

## Banned Patterns

Delete and rewrite any of these:
- generic openings like "In today's rapidly evolving landscape"
- filler transitions such as "Moreover" and "Furthermore"
- hype phrases like "game-changer", "cutting-edge", or "revolutionary"
- vague claims without evidence
- biography or credibility claims not backed by provided context

## Writing Process

1. Clarify the audience and purpose.
2. Build a skeletal outline with one purpose per section.
3. Start each section with evidence, example, or scene.
4. Expand only where the next sentence earns its place.
5. Remove anything that sounds templated or self-congratulatory.

## Structure Guidance

### Technical Guides
- open with what the reader gets
- use code or terminal examples in every major section
- end with concrete takeaways, not a soft summary

### Essays / Opinion Pieces
- start with tension, contradiction, or a sharp observation
- keep one argument thread per section
- use examples that earn the opinion

### Newsletters
- keep the first screen strong
- mix insight with updates, not diary filler
- use clear section labels and easy skim structure

## Quality Gate

Before delivering:
- verify factual claims against provided sources
- remove filler and corporate language
- confirm the voice matches the supplied examples
- ensure every section adds new information
- check formatting for the intended platform

---


# Humanize Writing

## The core diagnosis

AI writing has six tells. Check for all of them before editing:

1. **Zero first-person** — no "I think", "in my view", "honestly", "to me"
2. **Structural colons** — colons used as "behold what follows" punctuation mid-sentence
3. **Checklist rebuttals** — "On X:" / "First:" / "Regarding X:" patterns that read like a list in disguise
4. **Textbook phrasing** — formal words a real person wouldn't say out loud
5. **Perfect qualification** — every claim hedged equally, no real conviction
6. **Overly smooth transitions** — paragraphs glide together too perfectly

## Workflow

1. Read the full draft and flag every instance of the six tells above
2. Apply fixes using the patterns in `references/patterns.md`
3. Read the result aloud — if it sounds like someone talking, it's done; if it still sounds like a report, repeat

## Key rules

**First-person goes at high-stakes moments only.** Not every sentence. Target:
- After stark numbers or surprising facts ("Honestly, that is a remarkable outcome")
- When landing the main argument ("In my view, that is not a side effect. It is the design.")
- In the rebuttal ("I think the legality argument is the weakest of the three")
- In the conclusion ("To me, a program that works by discouraging people is not a fair process")

**Short sentences land punches.** After a long sentence building an argument, one short sentence delivers the verdict. "It is the design." "It is a liability shield." "Not much of a right." Never stack more than two short sentences in a row.

**Numbers do the drama — prose stays plain.** Lead with the number, follow with the plain-English meaning. Don't bury figures in analytical prose.

**Transitions should feel earned, not engineered.** Replace "The X problem follows directly from this" with "The X problem is just as serious" or just start the new paragraph with the point.

## Reference

See `references/patterns.md` for before/after examples of every pattern.
