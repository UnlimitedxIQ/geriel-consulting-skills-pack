---
name: web-design-deliverables
description: "Client deliverables and web design toolkit (5 skills). Use for HTML presentations, polished websites, 3D immersive sites, video hero landing pages, landing page generation, overkill web design, frontend slides."
---


---


# Frontend Slides

Create zero-dependency, animation-rich HTML presentations that run entirely in the browser.

Inspired by the visual exploration approach showcased in work by [zarazhangrui](https://github.com/zarazhangrui).

## When to Activate

- Creating a talk deck, pitch deck, workshop deck, or internal presentation
- Converting `.ppt` or `.pptx` slides into an HTML presentation
- Improving an existing HTML presentation's layout, motion, or typography
- Exploring presentation styles with a user who does not know their design preference yet

## Non-Negotiables

1. **Zero dependencies**: default to one self-contained HTML file with inline CSS and JS.
2. **Viewport fit is mandatory**: every slide must fit inside one viewport with no internal scrolling.
3. **Show, don't tell**: use visual previews instead of abstract style questionnaires.
4. **Distinctive design**: avoid generic purple-gradient, Inter-on-white, template-looking decks.
5. **Production quality**: keep code commented, accessible, responsive, and performant.

Before generating, read `STYLE_PRESETS.md` for the viewport-safe CSS base, density limits, preset catalog, and CSS gotchas.

## Workflow

### 1. Detect Mode

Choose one path:
- **New presentation**: user has a topic, notes, or full draft
- **PPT conversion**: user has `.ppt` or `.pptx`
- **Enhancement**: user already has HTML slides and wants improvements

### 2. Discover Content

Ask only the minimum needed:
- purpose: pitch, teaching, conference talk, internal update
- length: short (5-10), medium (10-20), long (20+)
- content state: finished copy, rough notes, topic only

If the user has content, ask them to paste it before styling.

### 3. Discover Style

Default to visual exploration.

If the user already knows the desired preset, skip previews and use it directly.

Otherwise:
1. Ask what feeling the deck should create: impressed, energized, focused, inspired.
2. Generate **3 single-slide preview files** in `.ecc-design/slide-previews/`.
3. Each preview must be self-contained, show typography/color/motion clearly, and stay under roughly 100 lines of slide content.
4. Ask the user which preview to keep or what elements to mix.

Use the preset guide in `STYLE_PRESETS.md` when mapping mood to style.

### 4. Build the Presentation

Output either:
- `presentation.html`
- `[presentation-name].html`

Use an `assets/` folder only when the deck contains extracted or user-supplied images.

Required structure:
- semantic slide sections
- a viewport-safe CSS base from `STYLE_PRESETS.md`
- CSS custom properties for theme values
- a presentation controller class for keyboard, wheel, and touch navigation
- Intersection Observer for reveal animations
- reduced-motion support

### 5. Enforce Viewport Fit

Treat this as a hard gate.

Rules:
- every `.slide` must use `height: 100vh; height: 100dvh; overflow: hidden;`
- all type and spacing must scale with `clamp()`
- when content does not fit, split into multiple slides
- never solve overflow by shrinking text below readable sizes
- never allow scrollbars inside a slide

Use the density limits and mandatory CSS block in `STYLE_PRESETS.md`.

### 6. Validate

Check the finished deck at these sizes:
- 1920x1080
- 1280x720
- 768x1024
- 375x667
- 667x375

If browser automation is available, use it to verify no slide overflows and that keyboard navigation works.

### 7. Deliver

At handoff:
- delete temporary preview files unless the user wants to keep them
- open the deck with the platform-appropriate opener when useful
- summarize file path, preset used, slide count, and easy theme customization points

Use the correct opener for the current OS:
- macOS: `open file.html`
- Linux: `xdg-open file.html`
- Windows: `start "" file.html`

## PPT / PPTX Conversion

For PowerPoint conversion:
1. Prefer `python3` with `python-pptx` to extract text, images, and notes.
2. If `python-pptx` is unavailable, ask whether to install it or fall back to a manual/export-based workflow.
3. Preserve slide order, speaker notes, and extracted assets.
4. After extraction, run the same style-selection workflow as a new presentation.

Keep conversion cross-platform. Do not rely on macOS-only tools when Python can do the job.

## Implementation Requirements

### HTML / CSS

- Use inline CSS and JS unless the user explicitly wants a multi-file project.
- Fonts may come from Google Fonts or Fontshare.
- Prefer atmospheric backgrounds, strong type hierarchy, and a clear visual direction.
- Use abstract shapes, gradients, grids, noise, and geometry rather than illustrations.

### JavaScript

Include:
- keyboard navigation
- touch / swipe navigation
- mouse wheel navigation
- progress indicator or slide index
- reveal-on-enter animation triggers

### Accessibility

- use semantic structure (`main`, `section`, `nav`)
- keep contrast readable
- support keyboard-only navigation
- respect `prefers-reduced-motion`

## Content Density Limits

Use these maxima unless the user explicitly asks for denser slides and readability still holds:

| Slide type | Limit |
|------------|-------|
| Title | 1 heading + 1 subtitle + optional tagline |
| Content | 1 heading + 4-6 bullets or 2 short paragraphs |
| Feature grid | 6 cards max |
| Code | 8-10 lines max |
| Quote | 1 quote + attribution |
| Image | 1 image constrained by viewport |

## Anti-Patterns

- generic startup gradients with no visual identity
- system-font decks unless intentionally editorial
- long bullet walls
- code blocks that need scrolling
- fixed-height content boxes that break on short screens
- invalid negated CSS functions like `-clamp(...)`

## Related ECC Skills

- `frontend-patterns` for component and interaction patterns around the deck
- `liquid-glass-design` when a presentation intentionally borrows Apple glass aesthetics
- `e2e-testing` if you need automated browser verification for the final deck

## Deliverable Checklist

- presentation runs from a local file in a browser
- every slide fits the viewport without scrolling
- style is distinctive and intentional
- animation is meaningful, not noisy
- reduced motion is respected
- file paths and customization points are explained at handoff

---


# OverkillWEBDESIGN — The Design Obsession Engine

> "The difference between a $5k website and a $50k website is 10,000 details nobody can name but everybody can feel."

This skill is the **design brain** — the voice that says "you missed the nav button", "those colors aren't on-brand", "there's nothing to scroll." It tells you WHAT to do and WHY. For HOW (code templates, component implementations), see `3d-immersive`.

**Dependency:** All code templates, component patterns, and implementation details live in `3d-immersive`. This skill is pure design philosophy, audit process, and checklists.

**When to activate:**
- User says "overkill", "make it beautiful", "award-winning", "next level", "premium", "$50k"
- Transforming an existing site into something extraordinary
- Building a showcase, portfolio, or marketing site that needs to impress
- Any project where craft and polish are the primary goal

**When NOT to activate:**
- Admin panels, CRUD apps, documentation sites, internal tools
- Performance-critical dashboards where every KB matters
- User explicitly asks for simple/minimal implementation

---

## 1. The Overkill Mandate

**Every pixel sells the brand. Every interaction reinforces quality. NOTHING gets skipped.**

A glass-morphism nav bar tells the user this site was built by someone who cares. A magnetic button says: we thought about the 0.3 seconds you spend hovering. An on-brand 404 page says: we considered everything, even failure. A preloader that draws the logo says: the wait is part of the experience.

The difference between a student project and a $50K site isn't a single feature — it's the compounding effect of 10,000 micro-decisions. Each one is small. Together, they're the gap between "nice" and "how did you make this?"

### The Completeness Principle

Nothing gets skipped. Not the nav button hover state. Not the empty state. Not the 404. Not the loading skeleton. Not the error boundary. If a user can see it, it should look intentional. If they can interact with it, it should respond.

**The zero dead-spot rule:** if a user can hover, click, scroll, or tab to it, it responds. Every interactive element has at least three states: default, hover/focus, and active.

### On-Brand Discipline

Every color, every gradient, every subtle tone derives from the palette. If the brand is crimson + gold on dark, then the subtle background gradient is dark crimson tones, not arbitrary purple. The glass overlay is tinted warm, not cool blue. The hover glow matches the CTA color. Even the scrollbar thumb picks up the brand accent.

This applies to EVERYTHING:
- Error pages use brand colors
- Loading states use brand typography
- Empty states use brand illustration style
- Skeleton screens match the brand's visual language
- Even the cursor glow color is on-brand

---

## 2. Design Invariants (Zero-Tolerance Rules)

These are non-negotiable. Violating any produces obviously broken output.

### Every toggle must have visible impact
If a feature toggle exists, it MUST produce a visible change when flipped. A toggle that does nothing is a wasted feature and confuses users. Before shipping, flip every toggle and verify it changes something on screen. If a toggle's state doesn't alter the rendered output, either wire it to a real visual change or remove it.

### Zero dead buttons
After implementing any page, enumerate EVERY interactive element (buttons, links, nav items, cards) and verify that ALL applicable effects (magnetic, glass, focus-rings, tilt, hover states) are wired to ALL of them. Not just the "main" CTAs — every single clickable element. The nav "Contact Us" button is just as important as the hero CTA.

**Post-implementation audit (MANDATORY):**
1. List every `<button>`, `<a>`, clickable `<span>`, and interactive element on the page
2. For each one, verify: magnetic, glass, focus-ring, tilt (where applicable)
3. Any element missing treatment = bug, not a nice-to-have

### Brand palette discipline
ALL colors — including background gradients, subtle tones, overlays, and muted surfaces — MUST derive from the brand's defined color palette. Never use arbitrary colors that aren't in the brand's palette. If the brand is red + black, the subtle background is dark red/charcoal tones, not dark green. This applies to every surface: hero backgrounds, section gradients, card backgrounds, overlay tints.

### Typography scale follows background complexity
- **Minimal/no background** (solid color, subtle gradient): Text is the hero — use largest scale, centered, bold, single line if possible. The words must carry the entire visual weight.
- **Static image background**: Medium scale, positioned to avoid competing with image subject
- **Video/3D background**: Smaller scale, positioned in safe zones with enough contrast overlay

### Every feature needs a surface
If scroll-based features exist (smooth-scroll, scroll-progress, parallax, back-to-top), the page MUST have enough content to scroll. If tilt features exist, there must be cards to tilt. Every feature toggle must have at least one element it visibly affects.

### Font consistency across animation states
Animated text (scramble, typewriter, split-reveal) MUST use the same `font-family` as its final resting state. Never use a monospace font for scramble animation if the heading is a sans-serif like Rubik or Inter. The font-swap on animation completion creates a jarring visual jump where text reflows and changes width.

### Mount-once pattern for heavy assets
Always mount videos, 3D canvases, Spline embeds, and iframes ONCE and control visibility via opacity/display — never conditional rendering. Conditional mount/unmount causes re-loading on every toggle, producing a visible delay. Mount once, show/hide with CSS.

### Still frame selection protocol
When extracting a freeze frame from video for use as a poster, static background, or fallback:
1. Sample 5-6 frames across the video duration
2. Evaluate each for subject composition, negative space for text, visual energy, brand alignment
3. Show 2-3 best candidates to the user with brief notes on why each works
4. Never grab the first available frame — a poorly chosen freeze frame undermines the entire hero

### On-brand everything
Error pages, loading states, empty states, offline pages — ALL sell the brand. A generic "404 Not Found" breaks the spell. An animated 404 with witty copy and a redirect countdown says "we thought about everything." Test: screenshot ANY state of your site — does it look intentional?

---

## 3. The Completeness Audit

Before touching code, audit the existing site through eight phases. Score each 1-5. Anything below 4 gets a prescription.

### Phase 1: Hero Assessment

```
[ ] First impression timing — how fast does the hero hit? (target: < 3s to "wow")
[ ] Hero composition — is there depth? (foreground, midground, background layers)
[ ] Text treatment — split-text reveal or static?
[ ] Background — static image, gradient, video, or 3D scene?
[ ] CTA prominence — magnetic button? Spring animation? Cursor label?
```

**Prescriptions by score:**
- 1-2: Full hero rebuild. Add preloader -> split-text -> 3D/video background -> magnetic CTA
- 3: Add parallax layers, upgrade text animation, add cursor interaction
- 4: Polish timing, add micro-interactions, refine easing curves
- 5: Ship it

### Phase 2: Navigation Audit

```
[ ] Scroll response — does nav change on scroll? (shrink, blur, color shift)
[ ] Glass-morphism — backdrop-blur + transparency + subtle border?
[ ] Mobile treatment — sheet/drawer with stagger animation? Not just a hamburger slide?
[ ] Active state — animated indicator? Not just bold text?
[ ] Magnetic links — desktop nav items have magnetic hover pull?
```

**Prescriptions:**
- Add `backdrop-filter: blur(12px)` + `background: rgba(0,0,0,0.6)` + `border-bottom: 1px solid rgba(255,255,255,0.1)`
- Add scroll-driven height/padding transition (GSAP ScrollTrigger)
- Add magnetic hover to desktop nav items

### Phase 3: Content Flow

```
[ ] Map every section to a scroll moment (enter/hold/exit)
[ ] Identify pin candidates (stats, features, testimonials)
[ ] Mark parallax opportunities (any section with depth layers)
[ ] Check pacing — are there breathing sections between dense content?
[ ] Scroll progress indicator — global or per-section?
```

**Prescriptions:**
- Pin at least one section (feature showcase or stats counter)
- Add parallax depth to at least two sections
- Insert a full-viewport breathing section between the two densest blocks
- Add a subtle scroll progress bar (top of viewport, 2px, brand color)

### Phase 4: Interactive Element Catalog

```
For EVERY button, link, card, and form field:
[ ] Hover state — does it have one? Is it just color?
[ ] Focus state — visible, animated, brand-colored?
[ ] Active state — press feedback? Scale? Ripple?
[ ] Transition easing — linear? (Wrong.) Spring/elastic? (Right.)
[ ] Cursor interaction — does the cursor change context?
```

**Prescriptions:**
- Every button: magnetic pull + spring scale + cursor label
- Every card: tilt on hover (CSS perspective) + subtle shadow shift + cursor expand
- Every link: underline animation (width 0->100% from left)
- Every input: focus ring animation + label float

### Phase 5: Asset Quality

```
[ ] Images — cinematic quality or stock-looking?
[ ] Image treatment — raw or styled? (WebGL distortion, reveal animations, lazy blur-up)
[ ] 3D opportunities — any product/object that could be a rotating 3D model?
[ ] Video — any section that could be a looping background video?
[ ] Illustrations — custom or generic? Could be replaced with 3D/animated?
```

**Prescriptions:**
- Replace stock images with WebGL distortion hover effect (`hover-effect` library)
- Add scroll-triggered image reveals (clip-path or mask animation)
- Convert key product images to 3D models (.glb) if assets exist
- Use `next/image` with blur placeholder for all images

### Phase 6: Performance Baseline

```
[ ] Lighthouse score — Performance, Accessibility, Best Practices, SEO
[ ] Bundle size — gzipped JS total (target: < 300KB for 3D sites)
[ ] GPU headroom — open DevTools Performance, check GPU time per frame
[ ] LCP — < 2.5s? < 3.5s with preloader?
[ ] CLS — < 0.1? Font/image shifts?
[ ] Mobile frame rate — 30fps minimum acceptable, 60fps target
```

**Hard limits:**
- Lighthouse Performance: must stay > 85 after overkill treatment
- Main thread long tasks: < 50ms
- 3D canvas FPS: 60 desktop, 30 mobile (or fallback)
- Total JS: < 500KB gzipped (including Three.js)

### Phase 7: Edge Cases

```
[ ] 404 page — branded and designed, not default framework error?
[ ] Empty states — illustrated with personality, clear CTA to create first item?
[ ] Error boundary — animated recovery suggestions, not red text?
[ ] Offline page — cached brand experience with sync indicator?
[ ] Slow connection — skeleton screens pixel-identical to final layout?
[ ] JavaScript disabled — <noscript> with static fallback that still looks designed?
[ ] Loading states — branded skeletons, not generic spinners?
```

**Prescriptions:**
- 404: 3D scene or illustrated hero + witty copy + animated redirect countdown
- Empty: custom illustration + personality copy + primary CTA
- Error: recovery steps + retry button with spring animation
- Offline: cached brand assets + "back online" toast with confetti
- Skeleton: match final layout exactly, use brand shimmer color

### Phase 8: Brand Coherence

```
[ ] Are ALL surface colors derived from the brand palette? (backgrounds, overlays, subtle gradients)
[ ] Do glass effects use brand-tinted tones, not generic white/blue?
[ ] Is the typography consistent? (same font stack across all states, including animated text)
[ ] Do hover glows match the brand accent, not arbitrary colors?
[ ] Do error/success/warning states use brand-derived colors, not raw red/green/yellow?
[ ] Does the scrollbar thumb use brand accent?
[ ] Does the selection highlight (::selection) use brand colors?
[ ] Are cursor effects (glow, expand, label) on-brand?
```

**Test:** Walk through the entire site and screenshot 10 random states. If any screenshot uses a color not traceable to the brand palette, it's a coherence bug.

---

## 4. How to Apply Techniques On-Brand

### Deriving Surface Colors from a Brand Palette

Given a brand palette (e.g., primary: crimson #C62828, accent: gold #C9A84C, bg: near-black #0A0A0F):

| Surface | Derivation Method |
|---------|-------------------|
| Section backgrounds | Brand primary at 5-10% opacity over bg, or desaturated version |
| Card backgrounds | White at 4-8% opacity (glass), brand primary at 3-5% for tinted glass |
| Hover glows | Brand primary or accent at 30-50% opacity |
| Overlay gradients | Brand bg at 60-90% opacity, not pure black |
| Subtle borders | White at 8-15% opacity, or brand primary at 10% |
| Muted text | White at 50-70% opacity (dark themes), brand bg at 50-70% (light themes) |
| Error states | Brand primary shifted toward red (not raw red) |
| Success states | Brand accent shifted toward green (not raw green) |
| Scrollbar / selection | Brand accent at full or 70% opacity |

### Brand Personality -> Technique Mapping

Not every technique fits every brand. Match the personality:

**Bold / Industrial** (logistics, construction, heavy industry)
- DO: Clipped corners (polygon clip-path), dark grain texture, heavy display type (Bebas Neue, Oswald), subtle camera shake on scroll, angular section dividers, uppercase everything
- DON'T: Rounded pills, thin serif fonts, pastel gradients, gentle floats, soft shadows
- Easing: sharp `power4.out`, snappy transitions
- Colors: high contrast, dark base, single bold accent

**Elegant / Luxury** (fashion, jewelry, real estate, fine dining)
- DO: Thin serif type (Cormorant, Playfair), generous whitespace, slow animations (1.5s+), subtle glass with light borders, wide letter-spacing, horizontal rules, centered layouts
- DON'T: Neon colors, aggressive hover effects, dense grid layouts, monospace fonts, clipped corners
- Easing: smooth `expo.out`, long durations
- Colors: muted palette, gold/cream accents, deep darks

**Modern / SaaS** (tech products, platforms, dashboards)
- DO: Pill buttons, gradient glass panels, split-panel layouts, clean grid, Inter/DM Sans/Sora, subtle grid backgrounds, badge pills for features
- DON'T: Extreme animations, vintage typography, complex 3D scenes, film grain (unless dark mode dashboard)
- Easing: balanced `power2.out`, medium durations
- Colors: primary + neutral, blue-purple-green spectrum, clean whites

**Creative / Portfolio** (designers, agencies, artists, photographers)
- DO: Everything. Cursor mask reveals, distortion hovers, page transitions, film grain, split-text, scroll-driven video, sound design (opt-in), full preloader sequence
- DON'T: Hold back. This is where you use every technique that fits.
- Easing: expressive spring curves, playful bounces, dramatic reveals
- Colors: anything bold and deliberate

### Choosing 3D vs 2D Techniques

| Brand Signal | Recommendation |
|-------------|----------------|
| "We're innovative / cutting-edge" | Full 3D hero (R3F or Spline) |
| "We're reliable / trustworthy" | Subtle parallax + glass, no 3D |
| "We're playful / creative" | Physics interactions or particle fields |
| "We're premium / luxurious" | Slow camera dolly through minimal 3D scene |
| "We're fast / efficient" | Speed-focused animations, no heavy 3D |
| Product exists as physical object | 3D model viewer with orbit controls |
| Abstract concept / service | GLSL gradient noise background or particle atmosphere |

---

## 5. UX Obsession Principles

### Micro-Interaction Saturation
If you can hover/click/scroll/tab to it, it responds. Buttons pull magnetically. Cards tilt on hover. Links animate their underlines. Scroll reveals are staggered. Nothing sits dead on the page.

The cursor itself is a design element — on desktop, replace the default arrow with a mix-blend-mode: difference circle that changes size and shape based on what it hovers over. On CTAs, it expands and shows a label. On images, it shows "View." On drag areas, it shows arrows.

### Scroll Storytelling
Every scroll position is a directed frame. The user isn't just scrolling a page — they're advancing through a narrative. Pin sections for impact moments. Parallax layers create depth between foreground content and background atmosphere. Breathing sections (full-viewport with minimal content) create pacing between dense blocks.

Progress matters: a scroll indicator (subtle 2px bar at top, brand color) tells the user how deep they are. Sections that pin and play out on scroll give a cinematic feel — the user controls the pace.

### Typography as Art

| Normal | Overkill |
|--------|----------|
| Text fades in | Split-text stagger, per-character or per-word, with clip-mask reveal |
| Static font weight | Variable font weight shifts on scroll (wght axis 100->900) |
| Plain headings | Clip-mask text over video/gradient, animated gradient fills |
| Body text just sits there | Reading progress highlight — background-size animates on scroll |

Typography is 80% of web design. If you nail type, you can ship a beautiful site with zero images.

### Sound Design (User Opt-In)

| Normal | Overkill |
|--------|----------|
| Silent | Subtle ambient pad on opt-in, micro-sounds on interaction |
| No audio feedback | Click: soft tick. Hover: whisper whoosh. Success: chime |
| Music autoplays | Sound toggle in corner, muted by default, Web Audio API spatial |

**Rules:** Always behind user opt-in toggle. Use Howler.js for cross-browser. Keep files < 50KB each (MP3 CBR 64kbps). Sound is the single most underused lever in web design.

### Loading as Experience

| Normal | Overkill |
|--------|----------|
| Circular spinner | Brand animation — logo draws itself, morphs, or assembles |
| Progress bar | Counter with personality — percentage, asset names, witty messages |
| Blank then pop | Clip-path reveal, curtain wipe, or scale-from-center transition |

The preloader is Act 1 of a 3-act play. It sets the tone. Use the preloader template in `3d-immersive` as a starting point — extend it with brand mark animation, loaded asset counting, and an exit animation that becomes the hero entrance.

### Edge Case Polish

| Normal | Overkill |
|--------|----------|
| Generic "404 Not Found" | 3D scene with floating elements, witty copy, animated redirect countdown |
| Empty state: "No items" | Illustrated empty state with personality and clear CTA |
| Error: red text | Animated error boundary with recovery suggestions and retry |
| Offline: nothing | Offline page with cached brand experience and sync indicator |
| Slow connection | Skeleton screens pixel-identical to final layout, progressive image loading |

**Test:** If you can screenshot any state of your site and it looks intentional, you've reached overkill.

---

## 6. Performance Budget

Overkill does NOT mean slow. Every technique must earn its frame time.

### Core Web Vitals Targets

| Metric | Target | Hard Limit |
|--------|--------|------------|
| LCP | < 2.5s | < 3.5s (with preloader, LCP is the reveal) |
| FID / INP | < 100ms | < 200ms |
| CLS | < 0.05 | < 0.1 |
| FPS (desktop) | 60 | Never below 30 |
| FPS (mobile) | 30 | Fallback to static if below 20 |
| Lighthouse Performance | > 90 | > 80 |

### Bundle Budget

| Category | Budget (gzipped) |
|----------|-----------------|
| Three.js + R3F + drei | < 200KB |
| GSAP + plugins | < 30KB |
| Framer Motion | < 40KB |
| Application code | < 80KB |
| **Total 3D site** | **< 350KB** |
| **Total non-3D overkill** | **< 150KB** |

### When to Cut Effects (drop order)

If performance budget is exceeded, cut in this order (least valuable first):
1. Post-processing effects (ChromaticAberration, DepthOfField)
2. Particle count (reduce by 2x, then 4x)
3. Physics interactions
4. Custom cursor (replace with CSS cursor changes)
5. Film grain animation (replace with static noise texture)
6. Parallax layers (reduce to 2, then remove)
7. Split-text animation (simplify to word-level, then fade)
8. **NEVER cut:** Hover states, focus rings, responsive layout, accessibility

### Mobile Degradation Strategy

| Desktop | Mobile |
|---------|--------|
| Full 3D scene | Static hero image or CSS gradient |
| 2000 particles | 500 particles (or remove) |
| Post-processing stack | Remove entirely |
| `dpr={[1, 2]}` | `dpr={[1, 1.5]}` |
| Custom cursor | System cursor |
| Hover effects | Touch feedback (scale on press) |
| Film grain animated | Film grain static (single frame) |
| Parallax depth | Simplified or removed |

---

## 7. The Overkill Checklist

Pre-ship verification. Every item must be checked before claiming a site is "overkill."

### Interactions
```
[ ] Every button has hover + active + focus states (all three)
[ ] Magnetic buttons on CTAs (desktop)
[ ] Cursor context changes on interactive elements (desktop)
[ ] Click feedback on every clickable element (scale spring, ripple, or color)
[ ] All transitions use spring/elastic easing (never linear, never ease-in-out)
[ ] Link underlines animate (width 0->100% or slide)
[ ] Card hover has tilt or depth change
[ ] Form inputs have floating labels + animated focus ring
```

### Visual Polish
```
[ ] Film grain overlay on dark themes (opacity 0.03-0.06)
[ ] Split-text stagger on hero heading
[ ] Parallax depth on at least 2 sections
[ ] Custom preloader (not a spinner)
[ ] Designed 404 page (not default)
[ ] Designed empty states (not "No items found")
[ ] Scroll progress indicator
[ ] Consistent border-radius system (not random values)
[ ] Consistent spacing scale (4px base)
[ ] Color palette limited to 3-4 colors + neutrals
```

### Brand Coherence
```
[ ] ALL surface colors derive from brand palette (no arbitrary colors)
[ ] Glass effects use brand-tinted tones
[ ] Typography consistent across all states (including animated text)
[ ] Hover glows match brand accent
[ ] Error/success/warning states use brand-derived colors
[ ] Selection highlight (::selection) uses brand colors
[ ] Cursor effects are on-brand
```

### Performance
```
[ ] Lighthouse Performance > 85
[ ] 60fps scroll on desktop (check with DevTools Performance)
[ ] LCP < 3s (including preloader if used)
[ ] CLS < 0.1 (no layout shifts on load)
[ ] Total JS < 350KB gzipped (3D) or < 150KB (non-3D)
[ ] All 3D dynamically imported (not in main bundle)
[ ] Images use next/image with blur placeholder
[ ] Fonts use next/font with swap
```

### Accessibility
```
[ ] Screen reader tested (VoiceOver or NVDA walk-through)
[ ] Full keyboard navigation (Tab, Enter, Escape, Arrow keys)
[ ] Focus rings visible and beautiful (not browser default)
[ ] Focus-visible only (no focus ring on mouse click)
[ ] prefers-reduced-motion alternative (still looks premium)
[ ] prefers-color-scheme support (if applicable)
[ ] WCAG AA contrast on all text
[ ] All images have alt text (decorative = alt="")
[ ] ARIA labels on icon-only buttons
[ ] Skip-to-content link
```

### Mobile
```
[ ] No hover-dependent interactions (all work on touch)
[ ] No horizontal overflow (check all breakpoints)
[ ] Touch targets > 44px
[ ] 3D simplified or replaced with static fallback
[ ] Reduced particle count (4x less than desktop)
[ ] Tested on real device (not just DevTools)
[ ] Text readable without zooming (min 16px body)
```

### Edge Cases
```
[ ] 404 page is branded and designed
[ ] Empty states have personality and CTA
[ ] Error boundary has recovery path
[ ] Loading skeletons match final layout
[ ] JavaScript-disabled has <noscript> fallback
```

### The Wow Factor Test
```
[ ] Show someone who hasn't seen it -> they audibly react
[ ] They scroll back to the top to see the hero again
[ ] They try hovering on random elements to see what happens
[ ] They ask "how did you make this?"
```

If all four happen, it's overkill. If fewer than two, go back to the audit.

---

## 8. Archetypes — Complete Design Recipes

### The $50K Landing Page

**Component composition:** Preloader -> Hero (3D/video background + split-text + parallax CTAs) -> Glass nav (scroll-responsive) -> Pinned feature showcase -> Breathing section -> Parallax stats counter -> Testimonial carousel (blur transitions) -> CTA section (full-width, magnetic) -> Footer (parallax reveal + magnetic socials).

**Brand decisions:** Run full 8-phase audit first. Choose 3D vs video background based on brand personality (Section 4). Nav glass tint matches brand. All section backgrounds derived from palette. Typography scale matches background complexity per invariant.

**Integration gotchas:**
- Preloader must complete before Lenis smooth scroll initializes (prevents scroll-during-load)
- GSAP ScrollTrigger and Lenis must be synced (use `initGsapLenisSync` from `3d-immersive`)
- Do NOT use ScrollControls (drei) and Lenis together — they conflict
- Film grain SVG must be `position: fixed` with `pointer-events: none` and `z-index: 9999`
- All magnetic buttons need `data-cursor` attributes for custom cursor integration

**Common mistakes:**
- Forgetting nav button hover states (Phase 2 catches this)
- Using off-brand colors for section gradients (Phase 8 catches this)
- Preloader that blocks too long (keep under 3s)
- Pin sections without enough scroll distance for content to play out

### The Immersive Portfolio

**Component composition:** Preloader -> Project grid with WebGL distortion hover -> Custom cursor ("View" on cards) -> Page transitions (slideUp in template.tsx) -> Project detail: split-text title + cursor mask hero -> Film grain throughout.

**Brand decisions:** The portfolio IS the brand. Use every technique. Custom cursor is mandatory — it's the primary differentiator. Choose distortion images for the grid (not all projects, pick 6-8 hero shots). Page transition variant should match the portfolio's personality (fade for elegant, slideUp for modern, curtain for dramatic).

**Integration gotchas:**
- `hover-effect` library uses WebGL — needs `<Suspense>` wrapping on the grid
- Cursor mask requires desktop detection — mobile shows default layer only
- Page transitions go in `app/template.tsx` (NOT layout.tsx — layout doesn't remount)
- Film grain z-index must be above page content but below the cursor

**Common mistakes:**
- Using the same distortion effect on every project card (vary the intensity/direction)
- Custom cursor that blocks click targets (ensure `pointer-events: none`)
- Page transitions that feel slow (keep under 0.6s total)
- Missing mobile fallback for WebGL distortion grid (use CSS filter on touch devices)

### The Product Showcase

**Component composition:** Hero with product model (.glb) + orbit controls -> Scroll-driven rotation -> Feature callouts at rotation angles -> Material/color picker -> Specs with counter animation -> CTA section.

**Brand decisions:** The product IS the hero — no competing visual effects. Use Studio lighting for photorealistic render. Minimal post-processing (just bloom + vignette). Typography should be clean and informative, not dramatic. Background should be simple (gradient or solid) to keep focus on the model.

**Integration gotchas:**
- Always preload the .glb model (`useGLTF.preload`) — don't let users wait
- Draco compression pipeline: `npx @gltf-transform/cli optimize input.glb output.glb --compress draco`
- Orbit controls should constrain polar angle (prevent viewing the bottom)
- Material switches need smooth transitions (lerp material properties over 0.3s)

**Common mistakes:**
- 3D model too heavy (target < 2MB .glb after Draco)
- No loading skeleton for the Canvas (shows white flash)
- Feature callouts that block the model on mobile (stack below on small screens)
- Missing touch support for orbit controls (drei handles this, but verify)

---

## 9. Before / After Reference Table

Quick-reference for transforming common elements from normal to overkill.

| Element | Normal | Overkill |
|---------|--------|----------|
| **Hero** | Static image + text | 3D scene / video + split-text stagger + parallax layers + preloader entrance |
| **Buttons** | Color change on hover | Magnetic pull + cursor label + spring scale + optional micro-sound |
| **Cards** | Box shadow on hover | Tilt (CSS perspective) + WebGL distortion + cursor expand + shadow depth shift |
| **Navigation** | Solid background bar | Glass-morphism + scroll-responsive shrink + magnetic link items |
| **Page load** | Spinner or white flash | Branded counter + clip-path reveal + orchestrated content entrance |
| **Scroll** | Browser default | Lenis smooth + parallax layers + pinned sections + progress indicator |
| **Images** | Static `<img>` | WebGL distortion hover + scroll-triggered reveal (clip-path) + lazy blur-up |
| **Text** | Fade in | Split-text per-char stagger + clip-mask reveal + scroll-driven highlight |
| **Transitions** | Instant page swap | Exit choreography (curtain/zoom/morph) -> staggered enter |
| **Error page** | "404 Not Found" text | 3D scene + witty copy + animated redirect countdown |
| **Footer** | Static dark block | Parallax reveal from behind content + magnetic social icons + film grain |
| **Forms** | Standard inputs | Floating labels + animated focus rings + success micro-animation + validation shake |
| **Testimonials** | Card carousel | Pinned scroll section + blur transition between quotes + avatar parallax |
| **Stats/numbers** | Static text | Counter animation on scroll intersection + eased number roll |
| **Backgrounds** | Solid color | GLSL gradient noise + film grain overlay + subtle mouse reactivity |
| **Dividers** | `<hr>` or border | Animated line draw + gradient fade + scroll-triggered |

---


# 3D / Immersive Website Skill — The Complete Toolbox

Build stunning, performance-optimized 3D and immersive web experiences. Two tiers:
**Tier 1** (Spline + GSAP) for decorative 3D, **Tier 2** (React Three Fiber) for interactive 3D.

This skill is the **toolbox** — every technique, code template, and implementation pattern. For design philosophy, brand application, and audit checklists, see `overkill-web-design`.

---

## Non-Negotiables

1. **60fps desktop, graceful degradation mobile.** Never ship janky scroll or canvas.
2. **Visible loading skeleton for all 3D.** Never show a blank canvas — always `<Suspense fallback={<LoadingSkeleton />}>`.
3. **Mandatory mobile fallback.** CSS gradient or static image replaces 3D on mobile/low-end devices.
4. **`prefers-reduced-motion`** disables animations and 3D autoplay.
5. **3D components lazy-loaded** via `next/dynamic` or `React.lazy` — never block initial paint.
6. **Lenis smooth scroll** as the outermost wrapper for any scroll-driven site.
7. **All GSAP ScrollTriggers + Lenis cleaned up** in `useEffect` return — no leaked listeners.
8. **Film grain on dark themes.** Every dark-themed site gets an SVG noise overlay (opacity 0.03-0.06). Zero cost, instant premium.
9. **Split-text stagger on hero headings.** GSAP SplitText (free in 3.12+) with per-char or per-word reveal. The #1 Awwwards signature.
10. **Custom cursor on desktop.** Mix-blend-mode: difference circle, context-aware (changes on hover targets). Hidden on touch/mobile.
11. **Memory management.** Dispose geometries, materials, and textures in cleanup functions. Three.js does NOT garbage-collect GPU resources.
12. **Lenis + ScrollControls conflict.** NEVER use Lenis and drei's `<ScrollControls>` together — they fight over scroll ownership. Use one or the other.

---

## Decision Framework

| Signal | Approach |
|--------|----------|
| Landing page, portfolio, marketing site | **Tier 1** (Spline + GSAP) or **Tier 2** if interactive |
| Data visualization, configurator, interactive experience | **Tier 2** (React Three Fiber) |
| Game, simulation, physics | **Tier 2** + rapier |
| Decorative 3D background | **Tier 1** (Spline embed) or R3F gradient mesh |
| User interacts WITH 3D objects | **Tier 2** |
| Dashboard / data viz | Split text + page transitions only |
| Admin panel / CRUD | None of this |

**Spline limitation:** The builder cannot create Spline scenes — it can only embed existing ones via URL. When no Spline URL is available, default to building the scene in R3F code (Tier 2).

**Technique Selection Matrix:**

| Project Type | Tier 1 (mandatory) | Tier 2 (elevated) | Tier 3 (showcase) |
|---|---|---|---|
| Landing page | Split-text, grain, cursor, smooth scroll | Preloader, Magnetic, Parallax | Cursor mask |
| Portfolio | ALL | ALL | Distortion, Mask |
| Marketing site | ALL | Preloader, Parallax | Optional |
| Interactive experience | ALL | ALL | Camera dolly, PostProc |
| Product showcase | ALL | Magnetic, Parallax | Distortion |

---

## Pinned Package Versions

Always use these versions to prevent API hallucination:

```
@react-three/fiber: ^10.0.0
@react-three/drei: ^10.0.0
@react-three/postprocessing: ^3.0.0
@react-three/rapier: ^2.0.0
three: ^0.170.0
postprocessing: ^7.0.0
@splinetool/react-spline: ^4.0.0
gsap: ^3.12.0
lenis: ^1.1.0
framer-motion: ^11.0.0
r3f-perf: ^8.0.0
howler: ^2.2.4
```

> **Note:** GSAP SplitText is bundled free with `gsap@^3.12.0` — no separate install needed.
> **Note:** `hover-effect` (^1.0.0) is legacy and may need manual patching for ESM. Consider CSS-based distortion alternatives for new projects.

---

## Foundation Code Templates

### Lenis Smooth Scroll Provider

```tsx
// components/SmoothScroll.tsx
"use client";
import { ReactLenis } from "lenis/react";

export function SmoothScroll({ children }: { children: React.ReactNode }) {
  return (
    <ReactLenis
      root
      options={{
        lerp: 0.1,
        duration: 1.2,
        smoothWheel: true,
      }}
    >
      {children}
    </ReactLenis>
  );
}
```

### Lenis + GSAP Sync (CRITICAL)

```tsx
// lib/gsap-lenis-sync.ts
"use client";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

/**
 * Call once at app level (e.g., in layout or root component).
 * Syncs Lenis smooth scroll with GSAP ScrollTrigger.
 */
export function initGsapLenisSync(lenisInstance: any) {
  lenisInstance.on("scroll", ScrollTrigger.update);

  gsap.ticker.add((time) => {
    lenisInstance.raf(time * 1000);
  });
  gsap.ticker.lagSmoothing(0);
}
```

### Mobile Detection Hook

```tsx
// hooks/useIs3DCapable.ts
"use client";
import { useState, useEffect } from "react";

export function useIs3DCapable() {
  const [capable, setCapable] = useState(true);

  useEffect(() => {
    const isMobile = window.innerWidth < 768;
    const isLowEnd = navigator.hardwareConcurrency < 4;
    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;
    setCapable(!isMobile && !isLowEnd && !prefersReduced);
  }, []);

  return capable;
}
```

### Reduced-Motion Hook

```tsx
// hooks/useReducedMotion.ts
"use client";
import { useState, useEffect } from "react";

export function useReducedMotion() {
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReduced(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  return reduced;
}
```

**Reduced-motion strategy:**

| Full Animation | Reduced Alternative |
|---------------|---------------------|
| Split-text stagger (1.2s) | Instant opacity 0->1 (0.3s) |
| Parallax scroll layers | Static layered composition (still has depth via z-index + scale) |
| 3D rotating model | Static hero image with subtle CSS shadow |
| Scroll-pinned sections | Normal scroll, content visible immediately |
| Preloader animation | Brief fade-in (0.5s) |
| Magnetic buttons | Standard hover scale (CSS transform) |
| Custom cursor | System cursor (hidden entirely) |
| Film grain animation | Static noise texture (single frame) |

**Rule:** Reduced motion != reduced quality. The site should still look premium — just with opacity/color transitions instead of movement.

### Mouse-Tracking Parallax Hook

```tsx
// hooks/useMouseParallax.ts
"use client";
import { useState, useEffect } from "react";

export function useMouseParallax(intensity = 0.02) {
  const [position, setPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * intensity;
      const y = (e.clientY / window.innerHeight - 0.5) * intensity;
      setPosition({ x, y });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [intensity]);

  return position;
}
```

### Scroll Progress Hook

```tsx
// hooks/useScrollProgress.ts
"use client";
import { useState, useEffect } from "react";

export function useScrollProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(docHeight > 0 ? scrollTop / docHeight : 0);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return progress;
}
```

---

## Tier 1: Spline + GSAP Templates

### Spline Embed with Suspense

```tsx
// components/SplineScene.tsx
"use client";
import { Suspense, lazy } from "react";
import { useIs3DCapable } from "@/hooks/useIs3DCapable";

const Spline = lazy(() => import("@splinetool/react-spline"));

function LoadingSkeleton() {
  return (
    <div className="canvas-loading">
      <span className="sr-only">Loading 3D scene...</span>
    </div>
  );
}

function FallbackHero() {
  return <div className="hero-fallback" aria-label="Decorative background" />;
}

export function SplineScene({ url }: { url: string }) {
  const is3D = useIs3DCapable();

  if (!is3D) return <FallbackHero />;

  return (
    <div className="canvas-container">
      <Suspense fallback={<LoadingSkeleton />}>
        <Spline scene={url} />
      </Suspense>
    </div>
  );
}
```

### GSAP ScrollTrigger Reveal Hook

```tsx
// hooks/useScrollReveal.ts
"use client";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function useScrollReveal<T extends HTMLElement>(
  options: { y?: number; duration?: number; delay?: number } = {}
) {
  const ref = useRef<T>(null);
  const { y = 60, duration = 0.8, delay = 0 } = options;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;
    if (prefersReduced) return;

    const tween = gsap.from(el, {
      y,
      opacity: 0,
      duration,
      delay,
      ease: "power2.out",
      scrollTrigger: {
        trigger: el,
        start: "top 85%",
        toggleActions: "play none none none",
      },
    });

    return () => {
      tween.kill();
      ScrollTrigger.getAll().forEach((st) => {
        if (st.trigger === el) st.kill();
      });
    };
  }, [y, duration, delay]);

  return ref;
}
```

### GSAP Pin Section Hook

```tsx
// hooks/usePinSection.ts
"use client";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function usePinSection<T extends HTMLElement>(
  options: { endOffset?: string } = {}
) {
  const ref = useRef<T>(null);
  const { endOffset = "+=100%" } = options;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const st = ScrollTrigger.create({
      trigger: el,
      pin: true,
      start: "top top",
      end: endOffset,
      pinSpacing: true,
    });

    return () => st.kill();
  }, [endOffset]);

  return ref;
}
```

### Split-Text Reveal Hook

```tsx
// hooks/useSplitTextReveal.ts
"use client";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { SplitText } from "gsap/SplitText";

gsap.registerPlugin(ScrollTrigger, SplitText);

interface SplitTextOptions {
  type?: "chars" | "words" | "lines";
  stagger?: number;
  duration?: number;
  y?: number;
  clipMask?: boolean; // premium: overflow:hidden + slideUp per line
}

export function useSplitTextReveal<T extends HTMLElement>(
  options: SplitTextOptions = {}
) {
  const ref = useRef<T>(null);
  const {
    type = "words",
    stagger = 0.05,
    duration = 0.8,
    y = 40,
    clipMask = true,
  } = options;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    if (prefersReduced) {
      gsap.from(el, {
        opacity: 0,
        duration: 0.5,
        scrollTrigger: { trigger: el, start: "top 85%" },
      });
      return;
    }

    const split = new SplitText(el, { type });
    const targets =
      type === "chars" ? split.chars : type === "words" ? split.words : split.lines;

    if (clipMask) {
      targets.forEach((t: HTMLElement) => {
        t.style.overflow = "hidden";
        t.style.display = "inline-block";
      });
    }

    gsap.from(targets, {
      y,
      opacity: clipMask ? 1 : 0,
      duration,
      stagger,
      ease: "power3.out",
      scrollTrigger: {
        trigger: el,
        start: "top 85%",
        toggleActions: "play none none none",
      },
    });

    return () => {
      split.revert();
      ScrollTrigger.getAll().forEach((st) => {
        if (st.trigger === el) st.kill();
      });
    };
  }, [type, stagger, duration, y, clipMask]);

  return ref;
}
```

### Film Grain Overlay

```tsx
// components/FilmGrain.tsx
"use client";
import { useEffect, useRef } from "react";

export function FilmGrain({ opacity = 0.04 }: { opacity?: number }) {
  const seedRef = useRef(0);
  const baseRef = useRef<SVGFETurbulenceElement>(null);

  useEffect(() => {
    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;
    if (prefersReduced) return;

    let raf: number;
    const animate = () => {
      seedRef.current += 1;
      if (baseRef.current) {
        baseRef.current.setAttribute("seed", String(seedRef.current % 100));
      }
      raf = requestAnimationFrame(animate);
    };
    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <svg
      className="film-grain"
      style={{
        position: "fixed",
        inset: 0,
        width: "100%",
        height: "100%",
        zIndex: 9999,
        pointerEvents: "none",
        opacity,
        mixBlendMode: "overlay",
      }}
    >
      <filter id="grain-filter">
        <feTurbulence
          ref={baseRef}
          type="fractalNoise"
          baseFrequency="0.65"
          numOctaves="3"
          stitchTiles="stitch"
        />
      </filter>
      <rect width="100%" height="100%" filter="url(#grain-filter)" />
    </svg>
  );
}
```

### Custom Cursor

```tsx
// components/CustomCursor.tsx
"use client";
import { useEffect, useRef } from "react";
import gsap from "gsap";

export function CustomCursor() {
  const outerRef = useRef<HTMLDivElement>(null);
  const dotRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if ("ontouchstart" in window) return;

    const outer = outerRef.current;
    const dot = dotRef.current;
    if (!outer || !dot) return;

    const xOuter = gsap.quickTo(outer, "x", { duration: 0.35, ease: "power3" });
    const yOuter = gsap.quickTo(outer, "y", { duration: 0.35, ease: "power3" });
    const xDot = gsap.quickTo(dot, "x", { duration: 0.15, ease: "power3" });
    const yDot = gsap.quickTo(dot, "y", { duration: 0.15, ease: "power3" });

    const onMouseMove = (e: MouseEvent) => {
      xOuter(e.clientX - 20);
      yOuter(e.clientY - 20);
      xDot(e.clientX - 3);
      yDot(e.clientY - 3);
    };

    const onMouseOver = (e: MouseEvent) => {
      const target = (e.target as HTMLElement).closest("[data-cursor]");
      if (!target) return;
      const cursorType = target.getAttribute("data-cursor");
      if (cursorType === "expand") {
        gsap.to(outer, { width: 80, height: 80, x: "-=20", y: "-=20", duration: 0.3 });
      } else if (cursorType === "hide") {
        gsap.to(outer, { scale: 0, duration: 0.2 });
        gsap.to(dot, { scale: 0, duration: 0.2 });
      } else if (cursorType?.startsWith("text:")) {
        outer.textContent = cursorType.slice(5);
        gsap.to(outer, { width: 100, height: 100, x: "-=30", y: "-=30", fontSize: 14, duration: 0.3 });
      }
    };

    const onMouseOut = (e: MouseEvent) => {
      const target = (e.target as HTMLElement).closest("[data-cursor]");
      if (!target) return;
      outer.textContent = "";
      gsap.to(outer, { width: 40, height: 40, scale: 1, fontSize: 0, duration: 0.3 });
      gsap.to(dot, { scale: 1, duration: 0.2 });
    };

    window.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseover", onMouseOver);
    document.addEventListener("mouseout", onMouseOut);

    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseover", onMouseOver);
      document.removeEventListener("mouseout", onMouseOut);
    };
  }, []);

  return (
    <>
      <div
        ref={outerRef}
        className="custom-cursor custom-cursor__outer"
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: 40,
          height: 40,
          border: "1px solid white",
          borderRadius: "50%",
          zIndex: 10000,
          pointerEvents: "none",
          mixBlendMode: "difference",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "white",
          fontSize: 0,
        }}
      />
      <div
        ref={dotRef}
        className="custom-cursor"
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: 6,
          height: 6,
          background: "white",
          borderRadius: "50%",
          zIndex: 10000,
          pointerEvents: "none",
          mixBlendMode: "difference",
        }}
      />
    </>
  );
}
```

### Magnetic Button

```tsx
// components/MagneticButton.tsx
"use client";
import { useRef, useState, useCallback } from "react";

interface MagneticButtonProps {
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  onClick?: () => void;
  type?: "button" | "submit" | "reset";
  disabled?: boolean;
  /** Magnetic pull strength in px (default 12). Use 5 for pills, 8-10 for CTAs */
  strength?: number;
  /** Glow color on hover (default gold). Match to button's theme */
  glowColor?: string;
}

/**
 * Premium magnetic button with 5 interactive layers:
 * 1. Magnetic pull — follows cursor with elastic spring-back
 * 2. Radial shine — light follows cursor position inside the button
 * 3. Glow on hover — colored box-shadow matching the button's theme
 * 4. Scale boost — subtle 1.03x scale on hover
 * 5. Smooth easing — fast response on enter (0.15s), smooth elastic return (0.5s)
 */
export function MagneticButton({
  children,
  className = "",
  style,
  onClick,
  type = "button",
  disabled = false,
  strength = 12,
  glowColor = "rgba(201,168,76,0.4)",
}: MagneticButtonProps) {
  const ref = useRef<HTMLButtonElement>(null);
  const [transform, setTransform] = useState("translate(0px, 0px) scale(1)");
  const [glowPos, setGlowPos] = useState({ x: 50, y: 50 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = useCallback(
    (e: React.MouseEvent<HTMLButtonElement>) => {
      if (disabled) return;
      const el = ref.current;
      if (!el) return;

      const rect = el.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const deltaX = (e.clientX - centerX) / (rect.width / 2);
      const deltaY = (e.clientY - centerY) / (rect.height / 2);

      setTransform(
        `translate(${deltaX * strength}px, ${deltaY * strength}px) scale(1.03)`
      );
      setGlowPos({
        x: ((e.clientX - rect.left) / rect.width) * 100,
        y: ((e.clientY - rect.top) / rect.height) * 100,
      });
    },
    [disabled, strength]
  );

  const handleMouseLeave = useCallback(() => {
    setTransform("translate(0px, 0px) scale(1)");
    setIsHovered(false);
  }, []);

  const handleMouseEnter = useCallback(() => {
    if (!disabled) setIsHovered(true);
  }, [disabled]);

  return (
    <button
      ref={ref}
      type={type}
      disabled={disabled}
      onClick={onClick}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onMouseEnter={handleMouseEnter}
      className={`relative overflow-hidden ${className}`}
      style={{
        ...style,
        transform,
        transition: isHovered
          ? "transform 0.15s cubic-bezier(0.25, 0.46, 0.45, 0.94)"
          : "transform 0.5s cubic-bezier(0.16, 1, 0.3, 1)",
        boxShadow: isHovered
          ? `0 0 30px ${glowColor}, 0 4px 15px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1)`
          : (style?.boxShadow ?? "0 2px 8px rgba(0,0,0,0.3)"),
      }}
    >
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: isHovered
            ? `radial-gradient(circle at ${glowPos.x}% ${glowPos.y}%, rgba(255,255,255,0.2) 0%, transparent 60%)`
            : "none",
          transition: "background 0.2s ease",
        }}
      />
      <span className="relative z-10">{children}</span>
    </button>
  );
}
```

**Strength guidelines:**
| Element | Strength | Glow Color |
|---------|----------|------------|
| Hero CTA | 12px | Brand primary, 0.5 alpha |
| Standard CTA | 8-10px | Brand primary, 0.4 alpha |
| Feature pills / tags | 5px | Brand accent, 0.3 alpha |
| Nav links | 6px | White, 0.2 alpha |
| Icon buttons | 8px | Match icon color, 0.3 alpha |

### Parallax Layer Hook

```tsx
// hooks/useParallaxLayer.ts
"use client";
import { useEffect, type RefObject } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function useParallaxLayer(
  ref: RefObject<HTMLElement | null>,
  options: { speed?: number } = {}
) {
  const { speed = 0.5 } = options;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;
    if (prefersReduced) return;

    const tween = gsap.to(el, {
      y: () => speed * -100,
      ease: "none",
      scrollTrigger: {
        trigger: el,
        start: "top bottom",
        end: "bottom top",
        scrub: true,
      },
    });

    return () => {
      tween.kill();
      ScrollTrigger.getAll().forEach((st) => {
        if (st.trigger === el) st.kill();
      });
    };
  }, [ref, speed]);
}
```

### Page Transition Wrapper

```tsx
// components/PageTransition.tsx
"use client";
import { motion, AnimatePresence } from "framer-motion";
import { usePathname } from "next/navigation";
import { type ReactNode } from "react";

const variants = {
  fade: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 },
  },
  slideUp: {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 },
  },
  scaleDown: {
    initial: { opacity: 0, scale: 0.95 },
    animate: { opacity: 1, scale: 1 },
    exit: { opacity: 0, scale: 1.05 },
  },
};

interface PageTransitionProps {
  children: ReactNode;
  variant?: keyof typeof variants;
}

/**
 * For Next.js App Router: use in app/template.tsx (NOT layout.tsx).
 * Layout doesn't remount on navigation — template does.
 */
export function PageTransition({
  children,
  variant = "slideUp",
}: PageTransitionProps) {
  const pathname = usePathname();
  const v = variants[variant];

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={pathname}
        initial={v.initial}
        animate={v.animate}
        exit={v.exit}
        transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
```

### Curtain Wipe Page Transition

```tsx
// components/CurtainTransition.tsx
"use client";
import { motion, AnimatePresence } from "framer-motion";
import { usePathname } from "next/navigation";

const curtainVariants = {
  initial: { clipPath: "inset(0 0 100% 0)" },
  animate: {
    clipPath: ["inset(0 0 100% 0)", "inset(0 0 0 0)", "inset(100% 0 0 0)"],
    transition: {
      duration: 0.8,
      ease: [0.76, 0, 0.24, 1],
      times: [0, 0.4, 1],
      delay: 0.2,
    },
  },
  exit: {
    clipPath: "inset(0 0 0 0)",
    transition: {
      duration: 0.5,
      ease: [0.76, 0, 0.24, 1],
      delay: 0.2,
    },
  },
};

const contentVariants = {
  initial: { opacity: 0, y: 30 },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      delay: 0.5,
      ease: [0.22, 1, 0.36, 1],
    },
  },
  exit: {
    opacity: 0,
    y: -20,
    transition: { duration: 0.3 },
  },
};

export function CurtainTransition({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <AnimatePresence mode="wait">
      <motion.div key={pathname}>
        <motion.div
          className="fixed inset-0 z-[9999] bg-black pointer-events-none"
          variants={curtainVariants}
          initial="initial"
          animate="animate"
          exit="exit"
        />
        <motion.div
          variants={contentVariants}
          initial="initial"
          animate="animate"
          exit="exit"
        >
          {children}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
```

### Preloader

```tsx
// components/Preloader.tsx
"use client";
import { useEffect, useRef, useState } from "react";
import gsap from "gsap";

interface PreloaderProps {
  onComplete?: () => void;
}

export function Preloader({ onComplete }: PreloaderProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const counterRef = useRef<HTMLSpanElement>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    if (prefersReduced) {
      setDone(true);
      onComplete?.();
      return;
    }

    const tl = gsap.timeline({
      onComplete: () => {
        setDone(true);
        onComplete?.();
      },
    });

    tl.to(
      { val: 0 },
      {
        val: 100,
        duration: 2,
        ease: "power2.inOut",
        onUpdate: function () {
          if (counterRef.current) {
            counterRef.current.textContent = String(Math.round(this.targets()[0].val));
          }
        },
      }
    );

    tl.to(containerRef.current, {
      clipPath: "inset(0 0 100% 0)",
      duration: 0.8,
      ease: "power4.inOut",
    });

    return () => {
      tl.kill();
    };
  }, [onComplete]);

  if (done) return null;

  return (
    <div
      ref={containerRef}
      className="preloader"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 10001,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "var(--color-bg, #0a0a0f)",
        clipPath: "inset(0 0 0 0)",
      }}
    >
      <span
        ref={counterRef}
        style={{
          fontFamily: "var(--font-display, sans-serif)",
          fontSize: "clamp(3rem, 8vw, 6rem)",
          color: "var(--color-text, white)",
          fontWeight: 700,
        }}
      >
        0
      </span>
    </div>
  );
}
```

### Cursor Mask / Spotlight Reveal

```tsx
// components/CursorMask.tsx
"use client";
import { useEffect, useRef, type ReactNode } from "react";

interface CursorMaskProps {
  defaultContent: ReactNode;
  revealContent: ReactNode;
  radius?: number;
}

export function CursorMask({
  defaultContent,
  revealContent,
  radius = 120,
}: CursorMaskProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if ("ontouchstart" in window) return;

    const container = containerRef.current;
    if (!container) return;

    const onMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      container.style.setProperty("--mx", `${x}px`);
      container.style.setProperty("--my", `${y}px`);
    };

    container.addEventListener("mousemove", onMouseMove);
    return () => container.removeEventListener("mousemove", onMouseMove);
  }, []);

  return (
    <div
      ref={containerRef}
      style={{ position: "relative", overflow: "hidden" }}
    >
      <div style={{ position: "relative", zIndex: 1 }}>
        {defaultContent}
      </div>
      <div
        style={{
          position: "absolute",
          inset: 0,
          zIndex: 2,
          maskImage: `radial-gradient(circle ${radius}px at var(--mx, -200px) var(--my, -200px), black, transparent)`,
          WebkitMaskImage: `radial-gradient(circle ${radius}px at var(--mx, -200px) var(--my, -200px), black, transparent)`,
        }}
      >
        {revealContent}
      </div>
    </div>
  );
}
```

### Scroll-Driven Video Playback

```tsx
// hooks/useScrollVideo.ts
"use client";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function useScrollVideo<T extends HTMLElement>(
  videoRef: React.RefObject<HTMLVideoElement | null>,
  options: { start?: string; end?: string } = {}
) {
  const containerRef = useRef<T>(null);
  const { start = "top top", end = "bottom bottom" } = options;

  useEffect(() => {
    const video = videoRef.current;
    const container = containerRef.current;
    if (!video || !container) return;

    let st: globalThis.ScrollTrigger | null = null;

    const setup = () => {
      st = ScrollTrigger.create({
        trigger: container,
        start,
        end,
        scrub: true,
        onUpdate: (self) => {
          video.currentTime = self.progress * video.duration;
        },
      });
    };

    if (video.readyState >= 2) {
      setup();
    } else {
      video.addEventListener("loadeddata", setup, { once: true });
    }

    return () => {
      video.removeEventListener("loadeddata", setup);
      st?.kill();
    };
  }, [videoRef, start, end]);

  return containerRef;
}
```

### Beautiful Accessible Focus Rings

```css
/* globals.css — focus ring system */

:focus:not(:focus-visible) {
  outline: none;
}

:focus-visible {
  outline: none;
  box-shadow:
    0 0 0 2px var(--background),
    0 0 0 4px var(--ring-color, #6366f1);
  border-radius: inherit;
  transition: box-shadow 0.2s ease;
}

button:focus-visible,
a:focus-visible,
input:focus-visible,
select:focus-visible,
textarea:focus-visible {
  box-shadow:
    0 0 0 2px var(--background),
    0 0 0 4px var(--ring-color, #6366f1),
    0 0 20px -4px var(--ring-glow, rgba(99, 102, 241, 0.3));
  transition: box-shadow 0.3s cubic-bezier(0.22, 1, 0.36, 1);
}
```

---

## Word-Boundary Rule for Split Text

When splitting text into per-character spans for animation (outside of GSAP SplitText), ALWAYS group characters by word inside a `whitespace-nowrap` wrapper. Without this, the browser can line-break mid-word.

```tsx
// WRONG: characters can break mid-word
text.split("").map((c, i) => <span key={i} className="inline-block">{c}</span>)

// RIGHT: words stay together, spaces between words preserved
const words = text.split(" ");
words.map((word, wi) => (
  <span key={wi} className="inline-flex whitespace-nowrap">
    {word.split("").map((c, ci) => (
      <span key={ci} className="inline-block">{c}</span>
    ))}
    {wi < words.length - 1 && <span className="inline-block">&nbsp;</span>}
  </span>
))
```

This also applies to Framer Motion variants — any per-character animation must wrap characters in per-word containers.

### Font Consistency Rule

Animated text (scramble, typewriter, split-reveal) MUST use the same `font-family` as its final resting state. Never use a monospace font for scramble animation if the heading is a sans-serif. The font-swap creates a jarring visual jump.

### Video & Heavy Asset Mounting

Always mount videos and heavy assets ONCE and control visibility via opacity/display, not conditional rendering:

```tsx
// WRONG: remounts and reloads video on every toggle
{showVideo && <video src="..." autoPlay loop muted playsInline />}

// RIGHT: always mounted, toggle visibility — instant switching
<video
  src="..."
  autoPlay loop muted playsInline
  className="absolute inset-0 w-full h-full object-cover transition-opacity duration-500"
  style={{ opacity: showVideo ? 1 : 0, pointerEvents: showVideo ? "auto" : "none" }}
/>
```

This applies to any heavy asset: 3D canvases, iframes, Spline embeds. Mount once, show/hide with CSS.

---

## Tier 2: React Three Fiber Templates

### R3F Basic Scene

```tsx
// components/Scene3D.tsx
"use client";
import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import {
  Environment,
  Float,
  ContactShadows,
  OrbitControls,
} from "@react-three/drei";
import { EffectComposer, Bloom, Vignette } from "@react-three/postprocessing";
import { useIs3DCapable } from "@/hooks/useIs3DCapable";

function LoadingSkeleton() {
  return (
    <div className="canvas-loading">
      <span className="sr-only">Loading 3D scene...</span>
    </div>
  );
}

function FallbackHero() {
  return <div className="hero-fallback" aria-label="Decorative background" />;
}

function SceneContent() {
  return (
    <>
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 5, 5]} intensity={0.8} />
      <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
        <mesh>
          <sphereGeometry args={[1, 64, 64]} />
          <meshStandardMaterial color="#8b5cf6" metalness={0.8} roughness={0.2} />
        </mesh>
      </Float>
      <ContactShadows
        position={[0, -1.5, 0]}
        opacity={0.4}
        blur={2}
        far={4}
      />
      <Environment preset="city" />
      <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
      <EffectComposer>
        <Bloom intensity={0.3} luminanceThreshold={0.8} />
        <Vignette eskil={false} offset={0.1} darkness={0.5} />
      </EffectComposer>
    </>
  );
}

export function Scene3D() {
  const is3D = useIs3DCapable();

  if (!is3D) return <FallbackHero />;

  return (
    <div className="canvas-container">
      <Suspense fallback={<LoadingSkeleton />}>
        <Canvas
          camera={{ position: [0, 0, 5], fov: 45 }}
          dpr={[1, 2]}
        >
          <SceneContent />
        </Canvas>
      </Suspense>
    </div>
  );
}
```

### R3F Scroll-Driven Scene

**WARNING:** This uses drei's `<ScrollControls>`. Do NOT combine with Lenis — they conflict. Use one or the other.

```tsx
// components/ScrollScene.tsx
"use client";
import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { ScrollControls, Scroll, Float, Environment } from "@react-three/drei";
import { useIs3DCapable } from "@/hooks/useIs3DCapable";

function ScrollContent() {
  return (
    <ScrollControls pages={3} damping={0.25}>
      <Float speed={1.5} rotationIntensity={0.3}>
        <mesh position={[0, 0, 0]}>
          <torusKnotGeometry args={[1, 0.3, 128, 32]} />
          <meshStandardMaterial
            color="#6366f1"
            metalness={0.9}
            roughness={0.1}
          />
        </mesh>
      </Float>
      <Environment preset="sunset" />

      <Scroll html>
        <section className="h-screen flex items-center justify-center">
          <h1 className="text-display">Section One</h1>
        </section>
        <section className="h-screen flex items-center justify-center">
          <h2 className="text-heading">Section Two</h2>
        </section>
        <section className="h-screen flex items-center justify-center">
          <h2 className="text-heading">Section Three</h2>
        </section>
      </Scroll>
    </ScrollControls>
  );
}

export function ScrollScene() {
  const is3D = useIs3DCapable();

  if (!is3D) {
    return <div className="hero-fallback" aria-label="Decorative background" />;
  }

  return (
    <div style={{ height: "300vh" }}>
      <Canvas
        camera={{ position: [0, 0, 5], fov: 45 }}
        dpr={[1, 2]}
        style={{ position: "fixed", top: 0, left: 0 }}
      >
        <Suspense fallback={null}>
          <ScrollContent />
        </Suspense>
      </Canvas>
    </div>
  );
}
```

---

## Advanced R3F Techniques

### Custom GLSL Shaders — Animated Gradient Noise

A liquid, organic background that reacts to mouse movement. Use as hero background or full-page atmosphere.

```tsx
// components/GradientNoiseMesh.tsx
"use client";
import { useRef, useMemo } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";

const vertexShader = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const fragmentShader = /* glsl */ `
  uniform float uTime;
  uniform vec2 uMouse;
  uniform vec2 uResolution;
  uniform vec3 uColorA;
  uniform vec3 uColorB;
  uniform vec3 uColorC;
  varying vec2 vUv;

  float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
  }

  float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
      mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
      f.y
    );
  }

  float fbm(vec2 p) {
    float value = 0.0;
    float amplitude = 0.5;
    for (int i = 0; i < 6; i++) {
      value += amplitude * noise(p);
      p *= 2.0;
      amplitude *= 0.5;
    }
    return value;
  }

  void main() {
    vec2 uv = vUv;
    vec2 mouse = uMouse * 0.3;
    float n = fbm(uv * 3.0 + uTime * 0.15 + mouse);
    float n2 = fbm(uv * 2.0 - uTime * 0.1 + mouse * 0.5);
    vec3 color = mix(uColorA, uColorB, n);
    color = mix(color, uColorC, n2 * 0.6);
    float vignette = 1.0 - length(uv - 0.5) * 0.8;
    color *= vignette;
    gl_FragColor = vec4(color, 1.0);
  }
`;

interface GradientNoiseMeshProps {
  colorA?: string;
  colorB?: string;
  colorC?: string;
}

export function GradientNoiseMesh({
  colorA = "#0a0a2e",
  colorB = "#1a0a3e",
  colorC = "#0a1a4e",
}: GradientNoiseMeshProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const mouseRef = useRef(new THREE.Vector2(0, 0));
  const { viewport } = useThree();

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uMouse: { value: new THREE.Vector2(0, 0) },
      uResolution: { value: new THREE.Vector2(1, 1) },
      uColorA: { value: new THREE.Color(colorA) },
      uColorB: { value: new THREE.Color(colorB) },
      uColorC: { value: new THREE.Color(colorC) },
    }),
    [colorA, colorB, colorC]
  );

  useFrame(({ clock, pointer }) => {
    uniforms.uTime.value = clock.getElapsedTime();
    mouseRef.current.lerp(pointer, 0.05);
    uniforms.uMouse.value.copy(mouseRef.current);
  });

  return (
    <mesh ref={meshRef} scale={[viewport.width, viewport.height, 1]}>
      <planeGeometry args={[1, 1, 1, 1]} />
      <shaderMaterial
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
      />
    </mesh>
  );
}
```

### Water / Distortion Shader

Noise-based displacement for liquid, underwater, or heat-haze effects on any mesh.

```tsx
// components/DistortionMesh.tsx
"use client";
import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

const distortVert = /* glsl */ `
  uniform float uTime;
  uniform float uStrength;
  varying vec2 vUv;
  varying float vDisplacement;

  vec3 mod289(vec3 x) { return x - floor(x / 289.0) * 289.0; }
  vec4 mod289(vec4 x) { return x - floor(x / 289.0) * 289.0; }
  vec4 permute(vec4 x) { return mod289(((x * 34.0) + 1.0) * x); }
  vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }

  float snoise(vec3 v) {
    const vec2 C = vec2(1.0/6.0, 1.0/3.0);
    const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
    vec3 i = floor(v + dot(v, C.yyy));
    vec3 x0 = v - i + dot(i, C.xxx);
    vec3 g = step(x0.yzx, x0.xyz);
    vec3 l = 1.0 - g;
    vec3 i1 = min(g.xyz, l.zxy);
    vec3 i2 = max(g.xyz, l.zxy);
    vec3 x1 = x0 - i1 + C.xxx;
    vec3 x2 = x0 - i2 + C.yyy;
    vec3 x3 = x0 - D.yyy;
    i = mod289(i);
    vec4 p = permute(permute(permute(
      i.z + vec4(0.0, i1.z, i2.z, 1.0))
      + i.y + vec4(0.0, i1.y, i2.y, 1.0))
      + i.x + vec4(0.0, i1.x, i2.x, 1.0));
    float n_ = 0.142857142857;
    vec3 ns = n_ * D.wyz - D.xzx;
    vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
    vec4 x_ = floor(j * ns.z);
    vec4 y_ = floor(j - 7.0 * x_);
    vec4 x = x_ * ns.x + ns.yyyy;
    vec4 y = y_ * ns.x + ns.yyyy;
    vec4 h = 1.0 - abs(x) - abs(y);
    vec4 b0 = vec4(x.xy, y.xy);
    vec4 b1 = vec4(x.zw, y.zw);
    vec4 s0 = floor(b0) * 2.0 + 1.0;
    vec4 s1 = floor(b1) * 2.0 + 1.0;
    vec4 sh = -step(h, vec4(0.0));
    vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy;
    vec4 a1 = b1.xzyw + s1.xzyw * sh.zzww;
    vec3 p0 = vec3(a0.xy, h.x);
    vec3 p1 = vec3(a0.zw, h.y);
    vec3 p2 = vec3(a1.xy, h.z);
    vec3 p3 = vec3(a1.zw, h.w);
    vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
    p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
    vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
    m = m * m;
    return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
  }

  void main() {
    vUv = uv;
    float displacement = snoise(vec3(position.x * 2.0, position.y * 2.0, uTime * 0.3)) * uStrength;
    vDisplacement = displacement;
    vec3 newPosition = position + normal * displacement;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(newPosition, 1.0);
  }
`;

const distortFrag = /* glsl */ `
  uniform vec3 uColor;
  uniform float uOpacity;
  varying vec2 vUv;
  varying float vDisplacement;

  void main() {
    float intensity = 0.5 + vDisplacement * 2.0;
    vec3 color = uColor * intensity;
    gl_FragColor = vec4(color, uOpacity);
  }
`;

interface DistortionMeshProps {
  color?: string;
  strength?: number;
  opacity?: number;
  segments?: number;
}

export function DistortionMesh({
  color = "#4a00e0",
  strength = 0.3,
  opacity = 0.8,
  segments = 64,
}: DistortionMeshProps) {
  const meshRef = useRef<THREE.Mesh>(null);

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uStrength: { value: strength },
      uColor: { value: new THREE.Color(color) },
      uOpacity: { value: opacity },
    }),
    [color, strength, opacity]
  );

  useFrame(({ clock }) => {
    uniforms.uTime.value = clock.getElapsedTime();
  });

  return (
    <mesh ref={meshRef}>
      <sphereGeometry args={[1.5, segments, segments]} />
      <shaderMaterial
        vertexShader={distortVert}
        fragmentShader={distortFrag}
        uniforms={uniforms}
        transparent
      />
    </mesh>
  );
}
```

### Cinematic Post-Processing Stack

Complete EffectComposer with scroll-linked depth of field, chromatic aberration, noise, and color grading.

```tsx
// components/CinematicPostProcessing.tsx
"use client";
import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import {
  EffectComposer,
  ChromaticAberration,
  DepthOfField,
  Noise,
  Vignette,
  ToneMapping,
} from "@react-three/postprocessing";
import { BlendFunction, ToneMappingMode } from "postprocessing";
import { useScroll } from "@react-three/drei";
import * as THREE from "three";

export function CinematicPostProcessing() {
  const chromaRef = useRef<any>(null);
  const dofRef = useRef<any>(null);
  const scroll = useScroll();

  useFrame(() => {
    if (!scroll) return;
    const progress = scroll.offset;

    if (chromaRef.current) {
      const aberration = Math.sin(progress * Math.PI) * 0.003;
      chromaRef.current.offset = new THREE.Vector2(aberration, aberration);
    }

    if (dofRef.current) {
      dofRef.current.target = 3 + progress * 8;
    }
  });

  return (
    <EffectComposer multisampling={0}>
      <DepthOfField
        ref={dofRef}
        focusDistance={0}
        focalLength={0.05}
        bokehScale={4}
      />
      <ChromaticAberration
        ref={chromaRef}
        blendFunction={BlendFunction.NORMAL}
        offset={new THREE.Vector2(0.001, 0.001)}
      />
      <Noise
        blendFunction={BlendFunction.SOFT_LIGHT}
        opacity={0.15}
      />
      <Vignette
        darkness={0.5}
        offset={0.3}
      />
      <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
    </EffectComposer>
  );
}
```

### Physics Interactions with Rapier

Gravity-driven interactive objects. Use for playful hero sections or interactive backgrounds.

```tsx
// components/PhysicsScene.tsx
"use client";
import { Physics, RigidBody, CuboidCollider } from "@react-three/rapier";

function FallingBoxes({ count = 40 }: { count?: number }) {
  const boxes = Array.from({ length: count }, (_, i) => ({
    key: i,
    position: [
      (Math.random() - 0.5) * 8,
      Math.random() * 15 + 5,
      (Math.random() - 0.5) * 4,
    ] as [number, number, number],
    rotation: [
      Math.random() * Math.PI,
      Math.random() * Math.PI,
      Math.random() * Math.PI,
    ] as [number, number, number],
    scale: 0.2 + Math.random() * 0.4,
  }));

  return (
    <>
      {boxes.map(({ key, position, rotation, scale }) => (
        <RigidBody
          key={key}
          position={position}
          rotation={rotation}
          restitution={0.4}
          friction={0.8}
        >
          <mesh castShadow>
            <boxGeometry args={[scale, scale, scale]} />
            <meshStandardMaterial
              color={`hsl(${key * 9}, 60%, 50%)`}
              metalness={0.3}
              roughness={0.5}
            />
          </mesh>
        </RigidBody>
      ))}
    </>
  );
}

export function PhysicsScene() {
  return (
    <Physics gravity={[0, -9.81, 0]}>
      <RigidBody type="fixed">
        <CuboidCollider args={[10, 0.1, 10]} position={[0, -2, 0]} />
        <mesh receiveShadow position={[0, -2, 0]}>
          <boxGeometry args={[20, 0.2, 20]} />
          <meshStandardMaterial color="#1a1a2e" />
        </mesh>
      </RigidBody>
      <RigidBody type="fixed">
        <CuboidCollider args={[0.1, 10, 10]} position={[-5, 5, 0]} />
        <CuboidCollider args={[0.1, 10, 10]} position={[5, 5, 0]} />
      </RigidBody>
      <FallingBoxes />
    </Physics>
  );
}
```

### 3D Text

Two approaches: `Text3D` for hero moments, `<Text>` (SDF) for performant labels/body.

```tsx
// Hero moment — extruded 3D text
import { Text3D, Center, useMatcapTexture } from "@react-three/drei";

export function Hero3DText({ text = "OVERKILL" }: { text?: string }) {
  const [matcap] = useMatcapTexture("3E2335_D36A1B_8E4A2E_2842A5", 256);

  return (
    <Center>
      <Text3D
        font="/fonts/inter-bold.json"
        size={1.2}
        height={0.3}
        bevelEnabled
        bevelSize={0.02}
        bevelThickness={0.01}
        letterSpacing={0.05}
      >
        {text}
        <meshMatcapMaterial matcap={matcap} />
      </Text3D>
    </Center>
  );
}

// Performant SDF text — use for body text, labels, HUDs
import { Text } from "@react-three/drei";

export function SDFText({ children, ...props }: any) {
  return (
    <Text
      fontSize={0.5}
      color="#ffffff"
      anchorX="center"
      anchorY="middle"
      font="/fonts/inter-regular.woff"
      maxWidth={10}
      {...props}
    >
      {children}
    </Text>
  );
}
```

**When to use which:**
- `Text3D`: Hero titles, logo moments, anything needing depth and lighting
- `<Text>` (SDF): Everything else — labels, body text, HUD elements, many instances

### Model Loading — .glb Workflow

```tsx
// components/ProductModel.tsx
"use client";
import { Suspense } from "react";
import { useGLTF, OrbitControls, Stage, Preload } from "@react-three/drei";
import { Canvas } from "@react-three/fiber";

function Model({ url }: { url: string }) {
  const { scene } = useGLTF(url);
  return <primitive object={scene} />;
}

useGLTF.preload("/models/product.glb");

export function ProductViewer() {
  return (
    <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
      <Suspense fallback={null}>
        <Stage environment="city" intensity={0.5}>
          <Model url="/models/product.glb" />
        </Stage>
        <OrbitControls
          enableZoom={false}
          autoRotate
          autoRotateSpeed={1}
          minPolarAngle={Math.PI / 4}
          maxPolarAngle={Math.PI / 1.5}
        />
      </Suspense>
      <Preload all />
    </Canvas>
  );
}
```

**Draco compression pipeline:**
```bash
npx @gltf-transform/cli optimize input.glb output.glb --compress draco
npx gltfjsx input.glb --transform --types --output Model.tsx
```

### Scroll-Driven Camera Dolly

Camera moves along a spline path as the user scrolls. Cinematic storytelling.

```tsx
// components/CameraDolly.tsx
"use client";
import { useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import { useScroll } from "@react-three/drei";
import * as THREE from "three";

interface CameraDollyProps {
  points?: [number, number, number][];
  lookAt?: [number, number, number];
}

export function CameraDolly({
  points = [
    [0, 2, 10],
    [5, 3, 5],
    [8, 1, 0],
    [5, 2, -5],
    [0, 4, -8],
  ],
  lookAt = [0, 0, 0],
}: CameraDollyProps) {
  const scroll = useScroll();
  const lookAtVec = useMemo(() => new THREE.Vector3(...lookAt), [lookAt]);

  const curve = useMemo(() => {
    const curvePoints = points.map(
      (p) => new THREE.Vector3(p[0], p[1], p[2])
    );
    return new THREE.CatmullRomCurve3(curvePoints, false, "centripetal", 0.5);
  }, [points]);

  useFrame(({ camera }) => {
    const progress = scroll.offset;
    const point = curve.getPointAt(progress);
    camera.position.lerp(point, 0.1);
    camera.lookAt(lookAtVec);
  });

  return null;
}

// Usage in a ScrollControls scene:
// <ScrollControls pages={5}>
//   <CameraDolly points={[[0,2,10], [5,3,5], [8,1,0]]} />
//   <YourScene />
// </ScrollControls>
```

### Instanced Meshes — Particle Field

For particle fields, starfields, floating debris, or data visualization points.

```tsx
// components/ParticleField.tsx
"use client";
import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface ParticleFieldProps {
  count?: number;
  spread?: number;
  size?: number;
  color?: string;
}

export function ParticleField({
  count = 2000,
  spread = 20,
  size = 0.02,
  color = "#ffffff",
}: ParticleFieldProps) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const particles = useMemo(() => {
    return Array.from({ length: count }, () => ({
      position: new THREE.Vector3(
        (Math.random() - 0.5) * spread,
        (Math.random() - 0.5) * spread,
        (Math.random() - 0.5) * spread
      ),
      speed: 0.2 + Math.random() * 0.5,
      offset: Math.random() * Math.PI * 2,
    }));
  }, [count, spread]);

  useFrame(({ clock }) => {
    const mesh = meshRef.current;
    if (!mesh) return;
    const t = clock.getElapsedTime();

    for (let i = 0; i < count; i++) {
      const { position, speed, offset } = particles[i];
      dummy.position.set(
        position.x + Math.sin(t * speed + offset) * 0.5,
        position.y + Math.cos(t * speed * 0.7 + offset) * 0.3,
        position.z + Math.sin(t * speed * 0.5 + offset) * 0.4
      );
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[size, 6, 6]} />
      <meshBasicMaterial color={color} transparent opacity={0.6} />
    </instancedMesh>
  );
}
```

### Studio Lighting Setup

Three-point lighting for photorealistic product renders.

```tsx
// components/StudioLighting.tsx
"use client";

interface StudioLightingProps {
  intensity?: number;
  color?: string;
}

export function StudioLighting({
  intensity = 1,
  color = "#ffffff",
}: StudioLightingProps) {
  return (
    <>
      {/* Key light — main illumination, slight angle */}
      <directionalLight
        position={[5, 5, 5]}
        intensity={intensity * 1.2}
        color={color}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      {/* Fill light — softer, opposite side */}
      <directionalLight
        position={[-3, 3, -2]}
        intensity={intensity * 0.4}
        color="#e8e0ff"
      />
      {/* Rim light — edge definition from behind */}
      <directionalLight
        position={[0, 2, -5]}
        intensity={intensity * 0.6}
        color="#ffe0c0"
      />
      {/* Ambient — lift shadows */}
      <ambientLight intensity={intensity * 0.15} />
    </>
  );
}
```

### Variable Font Weight on Scroll

GSAP-driven variable font weight that shifts from light to bold as user scrolls.

```tsx
// hooks/useVariableFontScroll.ts
"use client";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function useVariableFontScroll<T extends HTMLElement>(
  options: { minWeight?: number; maxWeight?: number } = {}
) {
  const ref = useRef<T>(null);
  const { minWeight = 100, maxWeight = 900 } = options;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const prefersReduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;
    if (prefersReduced) return;

    const tween = gsap.to(el, {
      fontVariationSettings: `'wght' ${maxWeight}`,
      ease: "none",
      scrollTrigger: {
        trigger: el,
        start: "top 80%",
        end: "top 20%",
        scrub: true,
      },
    });

    // Set initial state
    el.style.fontVariationSettings = `'wght' ${minWeight}`;

    return () => {
      tween.kill();
      ScrollTrigger.getAll().forEach((st) => {
        if (st.trigger === el) st.kill();
      });
    };
  }, [minWeight, maxWeight]);

  return ref;
}
```

### Sound Toggle (Howler.js)

Minimal opt-in sound pattern for ambient background or micro-sounds.

```tsx
// hooks/useSound.ts
"use client";
import { useRef, useCallback, useState } from "react";
import { Howl } from "howler";

interface UseSoundOptions {
  src: string;
  volume?: number;
  loop?: boolean;
}

export function useSound({ src, volume = 0.3, loop = false }: UseSoundOptions) {
  const soundRef = useRef<Howl | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const play = useCallback(() => {
    if (!soundRef.current) {
      soundRef.current = new Howl({ src: [src], volume, loop });
    }
    soundRef.current.play();
    setIsPlaying(true);
  }, [src, volume, loop]);

  const stop = useCallback(() => {
    soundRef.current?.stop();
    setIsPlaying(false);
  }, []);

  const toggle = useCallback(() => {
    if (isPlaying) stop();
    else play();
  }, [isPlaying, play, stop]);

  return { play, stop, toggle, isPlaying };
}
```

### Scroll Text Highlight

Background-size animation on scroll — text highlights as user scrolls past.

```tsx
// hooks/useScrollHighlight.ts
"use client";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

/**
 * Highlights text with a background gradient as user scrolls past.
 * Apply to a text element. Set CSS:
 *   background: linear-gradient(to right, var(--color-primary) 50%, transparent 50%);
 *   background-size: 200% 100%;
 *   background-position: 100% 0;
 *   -webkit-background-clip: text;
 *   -webkit-text-fill-color: transparent;
 */
export function useScrollHighlight<T extends HTMLElement>() {
  const ref = useRef<T>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const tween = gsap.to(el, {
      backgroundPosition: "0% 0",
      ease: "none",
      scrollTrigger: {
        trigger: el,
        start: "top 80%",
        end: "top 30%",
        scrub: true,
      },
    });

    return () => {
      tween.kill();
      ScrollTrigger.getAll().forEach((st) => {
        if (st.trigger === el) st.kill();
      });
    };
  }, []);

  return ref;
}
```

### Adaptive Scene (Mobile/Desktop)

```tsx
// components/AdaptiveScene.tsx
"use client";
import { Canvas } from "@react-three/fiber";
import { useIs3DCapable } from "@/hooks/useIs3DCapable";

interface AdaptiveSceneProps {
  desktopScene: React.ReactNode;
  mobileScene?: React.ReactNode;
  mobileFallback?: React.ReactNode;
}

export function AdaptiveScene({
  desktopScene,
  mobileScene,
  mobileFallback,
}: AdaptiveSceneProps) {
  const is3D = useIs3DCapable();

  if (!is3D && mobileFallback) return <>{mobileFallback}</>;

  if (!is3D && mobileScene) {
    return (
      <Canvas dpr={[1, 1.5]} performance={{ min: 0.5 }}>
        {mobileScene}
      </Canvas>
    );
  }

  return (
    <Canvas dpr={[1, 2]} performance={{ min: 0.5 }}>
      {desktopScene}
    </Canvas>
  );
}
```

---

## Memory Management

Three.js does NOT garbage-collect GPU resources. Always dispose in cleanup:

```tsx
useEffect(() => {
  return () => {
    // Dispose geometry
    geometry.dispose();
    // Dispose material (and its maps)
    if (material.map) material.map.dispose();
    material.dispose();
    // Dispose render targets
    renderTarget?.dispose();
  };
}, []);

// For loaded models:
useEffect(() => {
  return () => {
    scene.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.geometry.dispose();
        if (Array.isArray(child.material)) {
          child.material.forEach((m) => m.dispose());
        } else {
          child.material.dispose();
        }
      }
    });
  };
}, [scene]);
```

**Rules:**
- Dispose everything you create: geometries, materials, textures, render targets
- For models loaded via `useGLTF`, drei handles cleanup on unmount
- For custom shaders, dispose the `ShaderMaterial` and any textures in uniforms
- Watch Chrome DevTools Memory tab for GPU memory leaks during development

---

## Mobile Performance Rules

| Desktop | Mobile |
|---------|--------|
| 2000 particles | 500 particles (`count / 4`) |
| `dpr={[1, 2]}` | `dpr={[1, 1.5]}` |
| Full post-processing | Remove post-processing entirely |
| 64-segment sphere | 32-segment sphere |
| Custom cursor | System cursor |
| Hover effects | Touch feedback (scale on tap) |
| Film grain animated | Static noise or remove |

**Hard numbers:**
- Mobile Canvas FPS target: 30fps minimum, fallback to static if below 20fps
- Mobile JS budget: < 200KB gzipped (defer 3D entirely if exceeded)
- Touch targets: > 44px
- Never depend on hover — all hover effects must have touch equivalents

---

## Performance Profiling

### GPU Profiling Tools

```tsx
// Add to any R3F scene during development
import { Stats } from "@react-three/drei";
import { Perf } from "r3f-perf";

// In your Canvas:
<Stats />
<Perf position="top-left" />
```

### Draw Call Budgets

| Site Complexity | Max Draw Calls | Max Triangles | Max Textures |
|----------------|---------------|---------------|--------------|
| Simple (landing) | < 50 | < 100K | < 10 |
| Medium (portfolio) | < 150 | < 500K | < 25 |
| Complex (experience) | < 300 | < 1M | < 50 |

**Reduce draw calls:**
- Use `<instancedMesh>` for repeated geometry (particles, grids)
- Merge static geometry with `<Merged>` from drei
- Use texture atlases instead of individual textures
- Avoid transparent materials where possible (extra draw calls)

### LOD (Level of Detail)

```tsx
import { Detailed } from "@react-three/drei";

<Detailed distances={[0, 25, 50, 100]}>
  <HighPolyModel />
  <MidPolyModel />
  <LowPolyModel />
  <BillboardSprite />
</Detailed>
```

### GPU Layer Promotion (CSS)

```css
.will-animate {
  will-change: transform, opacity;
  /* Remove after animation completes to free GPU memory */
}
/* Never put will-change on more than ~20 elements */
```

---

## Archetypes

### 1. Ambient Spline Background (Tier 1)
Full-screen Spline scene as background behind glass-morphism content cards.
- Spline scene fills viewport, `position: fixed`, `z-index: -1`
- Content floats above with `.glass` cards
- GSAP ScrollTrigger reveals cards on scroll
- Lenis provides smooth scroll feel
- Mobile: hide Spline, show `.hero-fallback` gradient

### 2. 3D Product Showcase (Tier 2)
Floating 3D model with orbit controls and glass info cards alongside.
- R3F Canvas with `<OrbitControls>` (constrain polar angle)
- `<Float>` wraps the model for gentle bob
- `<ContactShadows>` grounds the object
- Post-processing: subtle `<Bloom>` + `<Vignette>`
- Split layout: 3D on left, glass info cards on right
- Mobile: static product image replaces Canvas

### 3. Particle Hero (Tier 2)
Thousands of particles responding to mouse position and scroll progress.
- Custom `<Points>` geometry with `useFrame` animation
- Mouse position via `useMouseParallax` mapped to particle attraction
- Scroll progress via `useScroll` from drei shifts particle formation
- Post-processing glow with `<Bloom>`
- Mobile: CSS gradient with animated `background-position`

### 4. Scroll-Driven 3D Narrative (Either Tier)
Scene transforms as the user scrolls — camera moves, objects appear/disappear.
- **Tier 1 version:** Spline background + GSAP pin sections with content reveals
- **Tier 2 version:** `<ScrollControls>` from drei, camera lerps between positions
- Each scroll "page" triggers a scene state change
- Text sections overlay via `<Scroll html>` (Tier 2) or pinned divs (Tier 1)
- **Lenis:** Use with Tier 1 only. Tier 2 uses `<ScrollControls>` instead.

### 5. Award-Winning Landing Page (All Tiers)
Preloader -> split-text hero -> parallax depth -> magnetic CTAs -> film grain -> custom cursor -> smooth scroll with pin sections.
- `<Preloader />` runs first, counter 0->100, clip-path exit
- Hero heading uses `useSplitTextReveal` with clip-mask variant
- Background elements at different scroll speeds via `useParallaxLayer`
- All CTA buttons wrapped in `<MagneticButton>`
- `<FilmGrain />` in layout (dark theme)
- `<CustomCursor />` at app root, context-aware on CTAs
- Lenis smooth scroll with GSAP pin sections for content narrative

### 6. Interactive Portfolio (All Tiers, selective)
Preloader -> grid with WebGL hover distortion -> custom cursor showing "View" -> page transitions -> split-text on project titles -> cursor mask on featured hero.
- `<Preloader />` sets the tone
- Project grid cards use `hover-effect` library for WebGL distortion on hover
- `<CustomCursor />` with `data-cursor="text:View"` on project cards
- `<PageTransition variant="slideUp" />` in `app/template.tsx`
- Project detail titles use `useSplitTextReveal`
- Featured hero uses `<CursorMask>` for dark/light reveal
- `<FilmGrain />` throughout

### 7. Full Immersive Experience (All Tiers)
Preloader -> R3F scene with scroll-driven camera -> advanced post-processing -> split-text overlays -> film grain -> custom cursor -> full parallax depth layering.
- `<Preloader />` with branded animation
- R3F Canvas with `<ScrollControls>`, camera lerps between positions
- Post-processing: `<ChromaticAberration>`, `<DepthOfField>`, `<Noise>`, `<Bloom>`
- HTML overlay sections use `useSplitTextReveal` for text
- `<FilmGrain />` composited over everything
- `<CustomCursor />` with context changes (expand on 3D, text on links)
- Background elements at multiple parallax speeds

---

## Delivery Checklist

Before marking a 3D/immersive project complete, verify ALL:

- [ ] **Suspense wrapping** — every 3D component wrapped in `<Suspense>` with visible fallback
- [ ] **Mobile fallback** — Canvas/Spline hidden on mobile, CSS fallback shown
- [ ] **Reduced motion** — `prefers-reduced-motion` disables animations + 3D autoplay
- [ ] **Lenis sync** — Lenis smooth scroll active, synced with GSAP ScrollTrigger if used
- [ ] **No Lenis + ScrollControls** — never combined in the same page
- [ ] **Cleanup** — all ScrollTriggers, Lenis listeners, and animation frames killed in useEffect return
- [ ] **GPU memory** — geometries, materials, textures disposed in cleanup
- [ ] **DPR cap** — `dpr={[1, 2]}` on Canvas (retina without perf waste)
- [ ] **No layout shift** — 3D containers have explicit dimensions, no CLS on load
- [ ] **Lazy-loaded** — 3D components use `next/dynamic` or `React.lazy`, not blocking initial paint
- [ ] **60fps** — smooth animations on desktop, no jank on scroll
- [ ] **JS-disabled fallback** — `<noscript>` with static image or gradient
- [ ] **Split-text reveals** — hero heading uses SplitText stagger (not just fade)
- [ ] **Film grain** — dark themes have SVG noise overlay (opacity 0.03-0.06)
- [ ] **Custom cursor** — desktop shows custom cursor, hidden on touch devices
- [ ] **Magnetic interactions** — CTAs have magnetic pull effect on desktop
- [ ] **Parallax depth** — at least 2 elements at different scroll speeds
- [ ] **Page transitions** — route changes animated (if multi-page)
- [ ] **Preloader** — initial load has animated intro, not raw content flash
- [ ] **Spring easing** — interactive animations use elastic/spring, not linear
- [ ] **Generated assets** — all assets.md items exist in /public/, referenced in code, fallbacks present

---


# Video Hero — Video Background Landing Page Builder

Build stunning full-screen video background hero landing pages as **single self-contained HTML files** or **React/Next.js components**. No build step needed for HTML variant — just one `.html` file with inline CSS and JS.

## Non-Negotiables

1. **Single file** (HTML variant): One self-contained HTML file — inline CSS + JS, no external stylesheets or scripts
2. **Full-viewport hero**: `height: 100vh; height: 100dvh` on the hero section
3. **Video rules**: `autoplay loop muted playsinline` — always, no exceptions
4. **Distinctive design**: No generic Bootstrap/template look. Strong visual identity via typography, color, and glass effects
5. **Accessible**: `prefers-reduced-motion` hides video and shows solid background fallback
6. **Responsive**: Must work at 1920, 1280, 768, 375 widths
7. **CDN only** (HTML variant): Google Fonts + Lucide icons via CDN are the only external requests allowed
8. **Contrast**: All text over video must have sufficient contrast via overlay gradient (minimum rgba(0,0,0,0.3))
9. **Keyboard accessible**: All interactive elements reachable via Tab, Enter, Escape

## Workflow

### 1. Gather Inputs

Ask only what's needed (defaults in parens):

| Input | Default |
|-------|---------|
| Brand name | Required |
| Primary color | `#00E5A0` (electric green) |
| Background color | `#000000` (black) |
| Tagline / headline | Generate from brand |
| Subheadline | Generate from brand |
| CTA text + URL | "Get Started" / `#` |
| Font preference | bold/industrial |
| Layout archetype | full-width-left |
| Video source | Ask user or use `/higgsfield video` |

### 2. Choose Layout Archetype

See [Layout Archetypes](#layout-archetypes) below. Recommend based on brand personality:
- **full-width-left**: Bold, industrial, logistics/tech — content upper-third left
- **two-panel-split**: Modern SaaS, feature-rich — left hero + right feature cards
- **centered-hero**: Classic elegance, consumer/lifestyle — centered headline + dual CTAs

### 3. Obtain Video + Still Frame

Three paths for video:
1. **User provides URL**: Use directly as `<source src="URL">`
2. **User provides local file**: Use relative path
3. **Generate via HiggsField**: Use `/higgsfield video` skill with a prompt matching the brand mood

**Still Frame Selection** (when extracting a freeze frame for poster/fallback):

1. **Sample 5-6 frames** across the video duration (e.g., 0s, 3s, 5s, 7s, 9s, 12s)
2. **Evaluate each frame** for:
   - **Subject composition**: Is the main subject well-framed? 3/4 angle > head-on
   - **Negative space**: Is there room for text overlay without competing?
   - **Visual energy**: Motion blur, sparks, light trails add dynamism to a still
   - **Brand alignment**: Does the color temperature match the brand palette?
3. **Show options to the user** — never pick a single frame without evaluation. Present 2-3 best candidates with brief notes on why each works.
4. **Extract with ffmpeg**: `ffmpeg -ss {time} -i video.mp4 -vframes 1 -update 1 -q:v 2 output.jpg`

Never grab the first available frame. A poorly chosen freeze frame undermines the entire hero.

### 4. Assemble the Page

1. Set CSS custom properties from design system template
2. Add video background boilerplate (with poster from step 3 if available)
3. Build layout from chosen archetype
4. Apply liquid glass effects to cards/panels
5. Add button styles matching archetype
6. Add responsive breakpoints + reduced-motion rules
7. Add SEO meta tags

### 5. Deliver

1. Save to current working directory as `{brand-name}-landing.html`
2. Open with `start "" {filename}` (Windows)
3. Report file path and customization points

---

## Performance Budgets

| Metric | Target | Hard Limit |
|--------|--------|------------|
| Video file size | < 10MB | < 15MB |
| LCP | < 2.5s | < 3.5s |
| Total page weight (excl. video) | < 100KB | < 200KB |
| Time to hero visible | < 1.5s | < 2.5s |

**Video optimization:**
- Target 720p for background videos (1080p only if hero is the ONLY content)
- Use H.264 for max compatibility, H.265 for Safari with H.264 fallback
- Aim for 2-4 Mbps bitrate for backgrounds (detail is hidden by overlay)
- Keep duration 10-20s for clean loops

---

## Design System Template

Every page starts with these CSS custom properties. Replace values per brand:

```css
:root {
  /* Brand */
  --color-primary: #00E5A0;
  --color-bg: #000000;
  --color-text: #FFFFFF;
  --color-muted: rgba(255,255,255,0.6);
  --color-accent: #00E5A0;

  /* Typography */
  --font-display: 'Bebas Neue', Impact, sans-serif;
  --font-body: 'Inter', system-ui, sans-serif;
  --font-accent: 'Space Mono', monospace;

  /* Fluid sizing */
  --size-headline: clamp(3rem, 8vw, 7rem);
  --size-subhead: clamp(1rem, 2vw, 1.5rem);
  --size-body: clamp(0.875rem, 1.2vw, 1.125rem);

  /* Letter spacing */
  --ls-tight: -0.04em;
  --ls-wide: 0.08em;
  --ls-ultra: 0.2em;

  /* Glass */
  --glass-blur-light: 4px;
  --glass-blur-strong: 50px;
  --glass-bg-light: rgba(255,255,255,0.04);
  --glass-bg-strong: rgba(255,255,255,0.08);
  --glass-border-light: rgba(255,255,255,0.08);
  --glass-border-strong: rgba(255,255,255,0.15);

  /* Layout */
  --max-width: 1400px;
  --section-padding: clamp(2rem, 5vw, 6rem);
}
```

### Recommended Font Pairings

| Style | Display | Body | Accent |
|-------|---------|------|--------|
| Bold / Industrial | Bebas Neue | Inter | Space Mono |
| Elegant / Editorial | Playfair Display | Lora | — |
| Clean / Modern | Sora | DM Sans | JetBrains Mono |
| Luxury / Minimal | Cormorant Garamond | Nunito Sans | — |

Google Fonts link template:
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=FONT1&family=FONT2&display=swap" rel="stylesheet">
```

Lucide icons CDN:
```html
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
<!-- After DOM: --> <script>lucide.createIcons();</script>
```

---

## Video Background Boilerplate

```html
<div class="video-bg">
  <video autoplay loop muted playsinline poster="poster.jpg">
    <source src="VIDEO_URL" type="video/mp4">
  </video>
  <div class="video-overlay"></div>
</div>
```

```css
.video-bg {
  position: fixed;
  inset: 0;
  z-index: 0;
  overflow: hidden;
}
.video-bg video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.video-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(
    180deg,
    rgba(0,0,0,0.3) 0%,
    rgba(0,0,0,0.1) 40%,
    rgba(0,0,0,0.6) 100%
  );
}
```

Notes:
- `poster` attribute prevents white flash before video loads — use a still frame from the video (see step 3)
- Mobile Safari requires `playsinline` for autoplay
- The overlay gradient ensures text readability over any video content

---

## Layout Archetypes

### Full-Width Left-Aligned (Targo-style)

Content positioned upper-third left. Glass card anchored bottom-left. Best for bold industrial brands.

```html
<section class="hero">
  <div class="hero-content">
    <p class="hero-kicker">KICKER TEXT</p>
    <h1 class="hero-headline">HEADLINE</h1>
    <p class="hero-sub">Subheadline text here.</p>
    <div class="hero-ctas">
      <a href="#" class="btn-clipped">GET STARTED</a>
      <a href="#" class="btn-ghost">LEARN MORE</a>
    </div>
  </div>
  <div class="hero-glass-card">
    <div class="glass-stat">
      <span class="stat-value">99.8%</span>
      <span class="stat-label">Uptime</span>
    </div>
    <div class="glass-stat">
      <span class="stat-value">24/7</span>
      <span class="stat-label">Support</span>
    </div>
  </div>
</section>
```

```css
.hero {
  position: relative;
  z-index: 1;
  height: 100vh;
  height: 100dvh;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: var(--section-padding);
}
.hero-content {
  max-width: 640px;
  padding-top: 15vh;
}
.hero-kicker {
  font-family: var(--font-accent);
  font-size: var(--size-body);
  letter-spacing: var(--ls-ultra);
  color: var(--color-primary);
  text-transform: uppercase;
  margin-bottom: 1rem;
}
.hero-headline {
  font-family: var(--font-display);
  font-size: var(--size-headline);
  letter-spacing: var(--ls-tight);
  line-height: 0.95;
  color: var(--color-text);
  margin: 0 0 1.5rem;
}
.hero-sub {
  font-family: var(--font-body);
  font-size: var(--size-subhead);
  color: var(--color-muted);
  max-width: 480px;
  line-height: 1.6;
  margin-bottom: 2rem;
}
.hero-glass-card {
  display: flex;
  gap: 2rem;
  padding: 1.5rem 2rem;
  max-width: 400px;
}
```

### Two-Panel Split (Bloom-style)

Left 52% for hero + CTA, right 48% for feature cards in a glass panel. Stacks vertically on mobile.

```html
<section class="hero hero-split">
  <div class="hero-left">
    <h1 class="hero-headline">HEADLINE</h1>
    <p class="hero-sub">Subheadline here.</p>
    <div class="hero-ctas">
      <a href="#" class="btn-pill">Get Started Free</a>
      <a href="#" class="btn-pill btn-pill-outline">Watch Demo</a>
    </div>
  </div>
  <div class="hero-right">
    <div class="feature-card liquid-glass-strong">
      <i data-lucide="zap"></i>
      <h3>Feature One</h3>
      <p>Description text.</p>
    </div>
    <div class="feature-card liquid-glass-strong">
      <i data-lucide="shield"></i>
      <h3>Feature Two</h3>
      <p>Description text.</p>
    </div>
    <div class="feature-card liquid-glass-strong">
      <i data-lucide="trending-up"></i>
      <h3>Feature Three</h3>
      <p>Description text.</p>
    </div>
  </div>
</section>
```

```css
.hero-split {
  display: grid;
  grid-template-columns: 52% 48%;
  align-items: center;
  gap: 2rem;
}
.hero-left { padding-right: 2rem; }
.hero-right {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.feature-card {
  padding: 1.5rem;
  border-radius: 16px;
}
.feature-card i {
  width: 24px;
  height: 24px;
  color: var(--color-primary);
  margin-bottom: 0.75rem;
}
.feature-card h3 {
  font-family: var(--font-body);
  font-size: 1.1rem;
  font-weight: 600;
  color: var(--color-text);
  margin: 0 0 0.5rem;
}
.feature-card p {
  font-size: var(--size-body);
  color: var(--color-muted);
  margin: 0;
  line-height: 1.5;
}

@media (max-width: 1024px) {
  .hero-split {
    grid-template-columns: 1fr;
    text-align: center;
  }
  .hero-left { padding-right: 0; }
  .hero-right {
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
  }
  .feature-card { flex: 1 1 280px; max-width: 320px; }
}
```

### Centered Hero (Classic)

Centered headline with dual CTAs. Best for consumer/lifestyle brands.

```html
<section class="hero hero-centered">
  <div class="hero-content-center">
    <p class="hero-kicker">KICKER</p>
    <h1 class="hero-headline">HEADLINE</h1>
    <p class="hero-sub">Subheadline centered.</p>
    <div class="hero-ctas">
      <a href="#" class="btn-pill">Primary CTA</a>
      <a href="#" class="btn-pill btn-pill-outline">Secondary CTA</a>
    </div>
  </div>
</section>
```

```css
.hero-centered {
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
}
.hero-content-center {
  max-width: 800px;
}
.hero-content-center .hero-sub {
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
}
.hero-ctas {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}
.hero-centered .hero-ctas {
  justify-content: center;
}
```

---

## Liquid Glass CSS

### Light Glass (`.liquid-glass`)

Subtle, transparent. Use for stat cards, nav bars, secondary panels.

```css
.liquid-glass {
  background: var(--glass-bg-light);
  backdrop-filter: blur(var(--glass-blur-light)) saturate(120%);
  -webkit-backdrop-filter: blur(var(--glass-blur-light)) saturate(120%);
  border: 1px solid var(--glass-border-light);
  border-radius: 16px;
  position: relative;
}
.liquid-glass::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  padding: 1px;
  background: linear-gradient(
    135deg,
    rgba(255,255,255,0.12) 0%,
    rgba(255,255,255,0) 50%,
    rgba(255,255,255,0.06) 100%
  );
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  pointer-events: none;
}
```

### Strong Glass (`.liquid-glass-strong`)

Deep blur, prominent borders. Use for hero cards, CTAs, feature panels.

```css
.liquid-glass-strong {
  background: var(--glass-bg-strong);
  backdrop-filter: blur(var(--glass-blur-strong)) saturate(180%);
  -webkit-backdrop-filter: blur(var(--glass-blur-strong)) saturate(180%);
  border: 1px solid var(--glass-border-strong);
  border-radius: 20px;
  box-shadow:
    0 8px 32px rgba(0,0,0,0.3),
    inset 0 1px 0 rgba(255,255,255,0.05);
  position: relative;
  overflow: hidden;
}
.liquid-glass-strong::after {
  content: '';
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: linear-gradient(
    45deg,
    transparent 40%,
    rgba(255,255,255,0.03) 50%,
    transparent 60%
  );
  pointer-events: none;
}
```

---

## Button Styles

### Clipped Corner (Industrial)

```css
.btn-clipped {
  display: inline-block;
  padding: 1rem 2.5rem;
  background: var(--color-primary);
  color: var(--color-bg);
  font-family: var(--font-display);
  font-size: 1rem;
  letter-spacing: var(--ls-wide);
  text-transform: uppercase;
  text-decoration: none;
  clip-path: polygon(12px 0, 100% 0, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0 100%, 0 12px);
  transition: transform 0.2s, opacity 0.2s;
}
.btn-clipped:hover { transform: translateY(-2px); opacity: 0.9; }
.btn-clipped:focus-visible {
  outline: 2px solid var(--color-primary);
  outline-offset: 4px;
}
```

### Ghost Button

```css
.btn-ghost {
  display: inline-block;
  padding: 1rem 2.5rem;
  background: transparent;
  color: var(--color-text);
  font-family: var(--font-display);
  font-size: 1rem;
  letter-spacing: var(--ls-wide);
  text-transform: uppercase;
  text-decoration: none;
  border: 1px solid rgba(255,255,255,0.2);
  clip-path: polygon(12px 0, 100% 0, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0 100%, 0 12px);
  transition: border-color 0.2s;
}
.btn-ghost:hover { border-color: var(--color-primary); }
.btn-ghost:focus-visible {
  outline: 2px solid var(--color-primary);
  outline-offset: 4px;
}
```

### Glass Pill (Modern/SaaS)

```css
.btn-pill {
  display: inline-block;
  padding: 0.875rem 2rem;
  background: var(--color-primary);
  color: var(--color-bg);
  font-family: var(--font-body);
  font-weight: 600;
  font-size: 1rem;
  text-decoration: none;
  border-radius: 100px;
  border: none;
  transition: transform 0.2s, box-shadow 0.2s;
}
.btn-pill:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}
.btn-pill:focus-visible {
  outline: 2px solid var(--color-primary);
  outline-offset: 4px;
}
.btn-pill-outline {
  background: var(--glass-bg-light);
  color: var(--color-text);
  border: 1px solid var(--glass-border-strong);
  backdrop-filter: blur(var(--glass-blur-light));
  -webkit-backdrop-filter: blur(var(--glass-blur-light));
}
```

---

## Responsive Breakpoints

Always include at the end of the `<style>` block:

```css
@media (max-width: 1024px) {
  .hero-split { grid-template-columns: 1fr; }
  .hero-content { padding-top: 10vh; }
  :root { --size-headline: clamp(2.5rem, 6vw, 4.5rem); }
}

@media (max-width: 640px) {
  .hero { padding: 1.5rem; }
  .hero-ctas { flex-direction: column; }
  .btn-clipped, .btn-ghost, .btn-pill { width: 100%; text-align: center; }
  .hero-glass-card { flex-direction: column; gap: 1rem; }
}

@media (prefers-reduced-motion: reduce) {
  .video-bg video { display: none; }
  .video-bg { background: var(--color-bg); }
  .video-overlay { background: var(--color-bg); }
  *, *::before, *::after {
    animation-duration: 0s !important;
    transition-duration: 0s !important;
  }
}
```

---

## HiggsField Video Integration

Use `/higgsfield video` to generate a background video. Map the brand feel to the best model:

| Brand Feel | Model | Prompt Tips |
|------------|-------|-------------|
| Cinematic / dramatic | Kling 3.0 | "Slow cinematic pan across...", "dramatic lighting" |
| Abstract / artistic | WAN 2.6 | "Abstract flowing particles", "liquid motion" |
| Realistic / product | Veo 3.1 | "Photorealistic aerial shot", "product showcase" |
| Fast / energetic | MiniMax Hailuo | "Dynamic motion", "fast-paced transitions" |
| Dreamy / atmospheric | Sora 2 | "Ethereal atmosphere", "soft focus bokeh" |

Good background video prompts:
- Keep motion slow and looping — avoid sudden cuts
- Dark/moody works best (text readability)
- Abstract > literal for hero backgrounds
- "Seamless loop" in prompt helps some models

---

## Complete HTML Skeleton

Use this as the starting template. Fill in design system vars, chosen archetype, and glass styles:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BRAND_NAME</title>
  <meta name="description" content="BRAND_DESCRIPTION">
  <meta property="og:title" content="BRAND_NAME">
  <meta property="og:description" content="BRAND_DESCRIPTION">
  <meta property="og:type" content="website">
  <meta name="theme-color" content="#000000">

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=FONT1&family=FONT2&display=swap" rel="stylesheet">

  <style>
    /* === Reset === */
    *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body {
      font-family: var(--font-body);
      background: var(--color-bg);
      color: var(--color-text);
      overflow-x: hidden;
    }

    /* === Design System (replace per brand) === */
    :root {
      /* PASTE design system vars HERE */
    }

    /* === Video Background === */
    .video-bg { position: fixed; inset: 0; z-index: 0; overflow: hidden; }
    .video-bg video { width: 100%; height: 100%; object-fit: cover; }
    .video-overlay {
      position: absolute; inset: 0;
      background: linear-gradient(180deg, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.1) 40%, rgba(0,0,0,0.6) 100%);
    }

    /* === Glass Effects === */
    /* PASTE liquid-glass and liquid-glass-strong HERE */

    /* === Hero === */
    .hero {
      position: relative;
      z-index: 1;
      height: 100vh;
      height: 100dvh;
      padding: var(--section-padding);
    }

    /* === ARCHETYPE CSS HERE === */

    /* === Buttons === */
    /* PASTE chosen button style HERE */

    /* === Accessibility === */
    .sr-only {
      position: absolute; width: 1px; height: 1px;
      padding: 0; margin: -1px; overflow: hidden;
      clip: rect(0,0,0,0); white-space: nowrap; border: 0;
    }
    a:focus-visible, button:focus-visible {
      outline: 2px solid var(--color-primary);
      outline-offset: 4px;
    }

    /* === Responsive === */
    /* PASTE responsive breakpoints HERE */
  </style>
</head>
<body>

  <!-- Skip to content -->
  <a href="#hero" class="sr-only" style="position:fixed;top:0;left:0;z-index:10000;padding:1rem;background:var(--color-primary);color:var(--color-bg);">Skip to content</a>

  <!-- Video Background -->
  <div class="video-bg" aria-hidden="true">
    <video autoplay loop muted playsinline poster="poster.jpg">
      <source src="VIDEO_URL" type="video/mp4">
    </video>
    <div class="video-overlay"></div>
  </div>

  <!-- ARCHETYPE HTML HERE (add id="hero") -->

  <!-- Icons (optional) -->
  <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
  <script>lucide.createIcons();</script>
</body>
</html>
```

---

## React / Next.js Variant

For projects using React/Next.js instead of a single HTML file:

```tsx
// components/VideoHero.tsx
"use client";
import { useRef, useEffect, useState } from "react";

interface VideoHeroProps {
  videoSrc: string;
  posterSrc?: string;
  headline: string;
  subheadline?: string;
  kicker?: string;
  ctaPrimary?: { text: string; href: string };
  ctaSecondary?: { text: string; href: string };
  /** "left" | "center" | "split" */
  layout?: "left" | "center" | "split";
  brandColor?: string;
  children?: React.ReactNode;
}

export function VideoHero({
  videoSrc,
  posterSrc,
  headline,
  subheadline,
  kicker,
  ctaPrimary,
  ctaSecondary,
  layout = "left",
  brandColor = "#00E5A0",
  children,
}: VideoHeroProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isReduced, setIsReduced] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setIsReduced(mq.matches);
    const handler = (e: MediaQueryListEvent) => setIsReduced(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  return (
    <section
      id="hero"
      className="relative z-10 flex min-h-dvh"
      style={
        layout === "center"
          ? { alignItems: "center", justifyContent: "center", textAlign: "center" }
          : { flexDirection: "column", justifyContent: "space-between" }
      }
    >
      {/* Video Background */}
      <div className="fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        {!isReduced && (
          <video
            ref={videoRef}
            autoPlay
            loop
            muted
            playsInline
            poster={posterSrc}
            className="w-full h-full object-cover"
          >
            <source src={videoSrc} type="video/mp4" />
          </video>
        )}
        <div
          className="absolute inset-0"
          style={{
            background: isReduced
              ? "var(--color-bg, #000)"
              : "linear-gradient(180deg, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.1) 40%, rgba(0,0,0,0.6) 100%)",
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 p-[clamp(2rem,5vw,6rem)]">
        <div className={layout === "center" ? "max-w-[800px] mx-auto" : "max-w-[640px] pt-[15vh]"}>
          {kicker && (
            <p
              className="text-sm uppercase tracking-[0.2em] mb-4"
              style={{ color: brandColor }}
            >
              {kicker}
            </p>
          )}

          <h1 className="text-[clamp(3rem,8vw,7rem)] font-bold leading-[0.95] tracking-tight mb-6 text-white">
            {headline}
          </h1>

          {subheadline && (
            <p className="text-[clamp(1rem,2vw,1.5rem)] text-white/60 max-w-[480px] leading-relaxed mb-8">
              {subheadline}
            </p>
          )}

          {(ctaPrimary || ctaSecondary) && (
            <div className={`flex gap-4 flex-wrap ${layout === "center" ? "justify-center" : ""}`}>
              {ctaPrimary && (
                <a
                  href={ctaPrimary.href}
                  className="inline-block px-8 py-3.5 rounded-xl font-semibold text-black transition-transform hover:scale-105"
                  style={{ background: brandColor }}
                >
                  {ctaPrimary.text}
                </a>
              )}
              {ctaSecondary && (
                <a
                  href={ctaSecondary.href}
                  className="inline-block px-8 py-3.5 rounded-xl font-semibold text-white border border-white/20 backdrop-blur-sm transition-colors hover:border-white/40"
                >
                  {ctaSecondary.text}
                </a>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Optional children (glass cards, stats, etc.) */}
      {children && (
        <div className="relative z-10 p-[clamp(2rem,5vw,6rem)]">
          {children}
        </div>
      )}
    </section>
  );
}
```

**Usage:**
```tsx
<VideoHero
  videoSrc="/videos/hero.mp4"
  posterSrc="/images/hero-poster.jpg"
  headline="MOVE FASTER"
  subheadline="Enterprise logistics platform built for speed."
  kicker="TARGO LOGISTICS"
  ctaPrimary={{ text: "Get Started", href: "/signup" }}
  ctaSecondary={{ text: "Watch Demo", href: "/demo" }}
  layout="left"
  brandColor="#C62828"
>
  {/* Glass stat cards */}
  <div className="flex gap-8 max-w-[400px]">
    <div className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-2xl p-4">
      <span className="text-2xl font-bold text-white">99.8%</span>
      <span className="text-sm text-white/50 block">Uptime</span>
    </div>
  </div>
</VideoHero>
```

---

## Delivery Checklist

Before handing off, verify:

- [ ] Video has `autoplay loop muted playsinline`
- [ ] Video has poster fallback (still frame, not first frame)
- [ ] Hero is `100dvh`
- [ ] Responsive at 1920, 1280, 768, 375
- [ ] `prefers-reduced-motion` hides video, disables animations
- [ ] Glass effects have `-webkit-` prefixes for Safari
- [ ] All text passes WCAG AA contrast over video overlay
- [ ] All buttons/links have `:focus-visible` styles
- [ ] Skip-to-content link present
- [ ] `aria-hidden="true"` on decorative video background
- [ ] SEO meta tags (title, description, og:title, og:description, theme-color)
- [ ] Video file < 15MB (target < 10MB)
- [ ] LCP < 3.5s
- [ ] File opened in browser via `start "" filename.html` (HTML variant)
- [ ] File path and easy customization points reported to user

## Related Skills

- `higgsfield` — generate video backgrounds via HiggsField AI
- `overkill-web-design` — design philosophy for taking it to the next level
- `3d-immersive` — code templates for 3D effects, animations, and interactions

---


# Landing Page Generator

Generate high-converting landing pages from a product description. Output complete Next.js/React components with multiple section variants, proven copy frameworks, SEO optimization, and performance-first patterns. Not lorem ipsum — actual copy that converts.

**Target:** LCP < 1s · CLS < 0.1 · FID < 100ms  
**Output:** TSX components + Tailwind styles + SEO meta + copy variants

---

## Core Capabilities

- 5 hero section variants (centered, split, gradient, video-bg, minimal)
- Feature sections (grid, alternating, cards with icons)
- Pricing tables (2–4 tiers with feature lists and toggle)
- FAQ accordion with schema markup
- Testimonials (grid, carousel, single-quote)
- CTA sections (banner, full-page, inline)
- Footer (simple, mega, minimal)
- 4 design styles with Tailwind class sets

---

## Generation Workflow

Follow these steps in order for every landing page request:

1. **Gather inputs** — collect product name, tagline, audience, pain point, key benefit, pricing tiers, design style, and copy framework using the trigger format below. Ask only for missing fields.
2. **Analyze brand voice** (recommended) — if the user has existing brand content (website copy, blog posts, marketing materials), run it through `marketing-skill/content-production/scripts/brand_voice_analyzer.py` to get a voice profile (formality, tone, perspective). Use the profile to inform design style and copy framework selection:
   - formal + professional → **enterprise** style, **AIDA** framework
   - casual + friendly → **bold-startup** style, **BAB** framework
   - professional + authoritative → **dark-saas** style, **PAS** framework
   - casual + conversational → **clean-minimal** style, **BAB** framework
3. **Select design style** — map the user's choice (or infer from brand voice analysis) to one of the four Tailwind class sets in the Design Style Reference.
4. **Apply copy framework** — write all headline and body copy using the chosen framework (PAS / AIDA / BAB) before generating components. Match the voice profile's formality and tone throughout.
5. **Generate sections in order** — Hero → Features → Pricing → FAQ → Testimonials → CTA → Footer. Skip sections not relevant to the product.
6. **Validate against SEO checklist** — run through every item in the SEO Checklist before outputting final code. Fix any gaps inline.
7. **Output final components** — deliver complete, copy-paste-ready TSX files with all Tailwind classes, SEO meta, and structured data included.

---

## Triggering This Skill

```
Product: [name]
Tagline: [one sentence value prop]
Target audience: [who they are]
Key pain point: [what problem you solve]
Key benefit: [primary outcome]
Pricing tiers: [free/pro/enterprise or describe]
Design style: dark-saas | clean-minimal | bold-startup | enterprise
Copy framework: PAS | AIDA | BAB
```

---

## Design Style Reference

| Style | Background | Accent | Cards | CTA Button |
|---|---|---|---|---|
| **Dark SaaS** | `bg-gray-950 text-white` | `violet-500/400` | `bg-gray-900 border border-gray-800` | `bg-violet-600 hover:bg-violet-500` |
| **Clean Minimal** | `bg-white text-gray-900` | `blue-600` | `bg-gray-50 border border-gray-200 rounded-2xl` | `bg-blue-600 hover:bg-blue-700` |
| **Bold Startup** | `bg-white text-gray-900` | `orange-500` | `shadow-xl rounded-3xl` | `bg-orange-500 hover:bg-orange-600 text-white` |
| **Enterprise** | `bg-slate-50 text-slate-900` | `slate-700` | `bg-white border border-slate-200 shadow-sm` | `bg-slate-900 hover:bg-slate-800 text-white` |

> **Bold Startup** headings: add `font-black tracking-tight` to all `<h1>`/`<h2>` elements.

---

## Copy Frameworks

**PAS (Problem → Agitate → Solution)**
- H1: Painful state they're in
- Sub: What happens if they don't fix it
- CTA: What you offer
- *Example — H1:* "Your team wastes 3 hours a day on manual reporting" / *Sub:* "Every hour spent on spreadsheets is an hour not closing deals. Your competitors are already automated." / *CTA:* "Automate your reports in 10 minutes →"

**AIDA (Attention → Interest → Desire → Action)**
- H1: Bold attention-grabbing statement → Sub: Interesting fact or benefit → Features: Desire-building proof points → CTA: Clear action

**BAB (Before → After → Bridge)**
- H1: "[Before state] → [After state]" → Sub: "Here's how [product] bridges the gap" → Features: How it works (the bridge)

---

## Representative Component: Hero (Centered Gradient — Dark SaaS)

Use this as the structural template for all hero variants. Swap layout classes, gradient direction, and image placement for split, video-bg, and minimal variants.

```tsx
export function HeroCentered() {
  return (
    <section className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-gray-950 px-4 text-center">
      <div className="absolute inset-0 bg-gradient-to-b from-violet-900/20 to-transparent" />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[600px] w-[600px] -translate-x-1/2 rounded-full bg-violet-600/20 blur-3xl" />
      <div className="relative z-10 max-w-4xl">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-violet-500/30 bg-violet-500/10 px-4 py-1.5 text-sm text-violet-300">
          <span className="h-1.5 w-1.5 rounded-full bg-violet-400" />
          Now in public beta
        </div>
        <h1 className="mb-6 text-5xl font-bold tracking-tight text-white md:text-7xl">
          Ship faster.<br />
          <span className="bg-gradient-to-r from-violet-400 to-pink-400 bg-clip-text text-transparent">
            Break less.
          </span>
        </h1>
        <p className="mx-auto mb-10 max-w-2xl text-xl text-gray-400">
          The deployment platform that catches errors before your users do.
          Zero config. Instant rollbacks. Real-time monitoring.
        </p>
        <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
          <Button size="lg" className="bg-violet-600 text-white hover:bg-violet-500 px-8">
            Start free trial
          </Button>
          <Button size="lg" variant="outline" className="border-gray-700 text-gray-300">
            See how it works →
          </Button>
        </div>
        <p className="mt-4 text-sm text-gray-500">No credit card required · 14-day free trial</p>
      </div>
    </section>
  )
}
```

---

## Other Section Patterns

### Feature Section (Alternating)

Map over a `features` array with `{ title, description, image, badge }`. Toggle layout direction with `i % 2 === 1 ? "lg:flex-row-reverse" : ""`. Use `<Image>` with explicit `width`/`height` and `rounded-2xl shadow-xl`. Wrap in `<section className="py-24">` with `max-w-6xl` container.

### Pricing Table

Map over a `plans` array with `{ name, price, description, features[], cta, highlighted }`. Highlighted plan gets `border-2 border-violet-500 bg-violet-950/50 ring-4 ring-violet-500/20`; others get `border border-gray-800 bg-gray-900`. Render `null` price as "Custom". Use `<Check>` icon per feature row. Layout: `grid gap-8 lg:grid-cols-3`.

### FAQ with Schema Markup

Inject `FAQPage` JSON-LD via `<script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />` inside the section. Map FAQs with `{ q, a }` into shadcn `<Accordion>` with `type="single" collapsible`. Container: `max-w-3xl`.

### Testimonials, CTA, Footer

- **Testimonials:** Grid (`grid-cols-1 md:grid-cols-3`) or single-quote hero block with avatar, name, role, and quote text.
- **CTA Banner:** Full-width section with headline, subhead, and two buttons (primary + ghost). Add trust signals (money-back guarantee, logo strip) immediately below.
- **Footer:** Logo + nav columns + social links + legal. Use `border-t border-gray-800` separator.

---

## SEO Checklist

- [ ] `<title>` tag: primary keyword + brand (50–60 chars)
- [ ] Meta description: benefit + CTA (150–160 chars)
- [ ] OG image: 1200×630px with product name and tagline
- [ ] H1: one per page, includes primary keyword
- [ ] Structured data: FAQPage, Product, or Organization schema
- [ ] Canonical URL set
- [ ] Image alt text on all `<Image>` components
- [ ] robots.txt and sitemap.xml configured
- [ ] Core Web Vitals: LCP < 1s, CLS < 0.1
- [ ] Mobile viewport meta tag present
- [ ] Internal linking to pricing and docs

> **Validation step:** Before outputting final code, verify every checklist item above is satisfied. Fix any gaps inline — do not skip items.

---

## Performance Targets

| Metric | Target | Technique |
|---|---|---|
| LCP | < 1s | Preload hero image, use `priority` on Next/Image |
| CLS | < 0.1 | Set explicit width/height on all images |
| FID/INP | < 100ms | Defer non-critical JS, use `loading="lazy"` |
| TTFB | < 200ms | Use ISR or static generation for landing pages |
| Bundle | < 100KB JS | Audit with `@next/bundle-analyzer` |

---

## Common Pitfalls

- Hero image not preloaded — add `priority` prop to first `<Image>`
- Missing mobile breakpoints — always design mobile-first with `sm:` prefixes
- CTA copy too vague — "Get started" beats "Learn more"; "Start free trial" beats "Sign up"
- Pricing page missing trust signals — add money-back guarantee and testimonials near CTA
- No above-the-fold CTA on mobile — ensure button is visible without scrolling on 375px viewport

---

## Related Skills

- **Brand Voice Analyzer** (`marketing-skill/content-production/scripts/brand_voice_analyzer.py`) — Run before generation to establish voice profile and ensure copy consistency
- **UI Design System** (`product-team/ui-design-system/`) — Generate design tokens from brand color before building the page
- **Competitive Teardown** (`product-team/competitive-teardown/`) — Competitive positioning informs landing page messaging and differentiation
